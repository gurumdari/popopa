$content$.popup.project.import = {
	resize: function() {
		var windowWidth = window.innerWidth;

		if (windowWidth > 687) {
			$controller$.popup.resize(648);
		} else {
			$controller$.popup.widthP(100);
		}
	},

	service: function() {
		window.addEventListener("resize", this.resize, false);
		this.resize();

		var params       = this.dataset.import_data;
		var useOrg       = $content$.article.project.create.dataset.use_org;
		var nextStep     = $content$.article.project.create.dataset.next_step_of_creating_project;
		var memberRow    = document.querySelector("aside.popup article > div.popup > form > table.form > tbody > tr.member");
		var memberButton = document.querySelector("aside.popup article > div.popup > form > table.form > tbody > tr.member > th > button");
		var memberTable  = memberRow.querySelector("tr.member > td > table");
		var memberTbody  = memberTable.lastElementChild;
		var leaderCell   = memberTable.querySelector("table > thead > tr > td:last-child");
		var okButton     = document.querySelector("aside.popup article > div.popup > form > ul.submit > li:last-child > button");

		delete params.worker_list;

		leaderCell.style.width = (leaderCell.offsetWidth - 4) + "px";
		memberTable.style.tableLayout = "fixed";

		// worker
		var workerRow   = memberRow.nextElementSibling;
		var workerTbody = workerRow.querySelector("td > table > tbody");
		var memberList  = $content$.article.project.create.getMemberList();

		var workerSelects = workerTbody.querySelectorAll("tbody > tr > td > select");

		var firstOldWorkerTh = workerTbody.querySelector("tbody > tr > th");
		if (firstOldWorkerTh) {
			if (firstOldWorkerTh.offsetWidth > 259) {
				workerTbody.parentNode.setAttribute("class", "block");
			}
		}

		memberButton.addEventListener("click", function(event) {
			var winupContentId = "/member/user";
			if (useOrg)  winupContentId = "/member/org";

			$jnode$.requireContent("winup", winupContentId, {
				useLoading: true,
				icon:       true,
				title:      i18n.label_select_member,
				width:      705,
				height:     360,
				unload:     true
			});
		}, false);

		$jnode$.storage.eventhandler4import = {
			open: function() {
				var memberList  = [];
				var memberCells = memberTbody.querySelectorAll("tbody > tr > td:first-child");

				for (var i = 0; i < memberCells.length; i++) {
					var memberData = {
						user_id:       memberCells[i].parentNode.getAttribute("id"),
						user_name:     memberCells[i].querySelector("td > span:first-of-type").firstChild.nodeValue,
						position_name: memberCells[i].querySelector("td > span:nth-of-type(3)").firstChild.nodeValue,
						position_id:   memberCells[i].querySelector("td > font:first-of-type").firstChild.nodeValue
					};

					if (useOrg) {
						memberData.org_name = memberCells[i].querySelector("td > span:last-of-type").firstChild.nodeValue;
						memberData.org_id   = memberCells[i].querySelector("td > font:last-of-type").firstChild.nodeValue;
					}

					memberList.push(memberData);
				}

				return memberList;
			},

			ok: function(datas, close) {
				var checkedValue = null;
				var checkedInput = memberTbody.querySelector("tbody > tr > td > input:checked");
				var dataCount    = datas.length;

				if (checkedInput) {
					checkedValue = checkedInput.value;
				}

				memberTbody.innerHTML = "";

				for (var j = 0; j < workerSelects.length; j++) {
					workerSelects[j].innerHTML = "";
					workerSelects[j].options.add(new Option(i18n.label_specify_worker, "", false, false));
				}

				for (var i = 0; i < datas.length; i++) {
					var userId = datas[i].user_id;
					var isRetiree = (userId.search(/^[$][{].+[}]$/) == 0);
					var row = document.createElement("tr");
					row.setAttribute("id", userId);
					memberTbody.appendChild(row);

					var orgInfo    = "";
					var orgOptInfo = "";

					if (useOrg) {
						orgInfo    = " @ <SPAN>" + $jnode$.escapeXML(datas[i].org_name) + "</SPAN><FONT>" + datas[i].org_id + "</FONT>";
						orgOptInfo = " @ " + $jnode$.escapeXML(datas[i].org_name);
					}

					var memberCell = row.insertCell(0);
					memberCell.innerHTML = (isRetiree ? i18n.label_retiree + ": " : "") + "<SPAN>" + $jnode$.escapeXML(datas[i].user_name) + "</SPAN> (<SPAN>" + $jnode$.escapeXML(isRetiree ? userId.substring(13, userId.length - 1) : userId) + "</SPAN> / <SPAN>" + $jnode$.escapeXML(datas[i].position_name) + "</SPAN><FONT>" + datas[i].position_id + "</FONT>)" + orgInfo;

					if (isRetiree)  memberCell.setAttribute("class", "retiree");

					var managerInput = document.createElement("input");
					managerInput.setAttribute("type", "radio");
					managerInput.setAttribute("name", "manager");
					managerInput.value = userId;

					if (datas[i].member_type == "manager")  managerInput.checked = true;

					var managerCell = row.insertCell(1);
					managerCell.appendChild(managerInput);

					for (var j = 0; j < workerSelects.length; j++) {
						workerSelects[j].options.add(new Option((isRetiree ? i18n.label_retiree + ": " : "") + $jnode$.escapeXML(datas[i].user_name) + " (" + $jnode$.escapeXML(isRetiree ? userId.substring(13, userId.length - 1) : userId) + " / " + $jnode$.escapeXML(datas[i].position_name) + ")" + orgOptInfo, userId, false, false));
					}
				}

				if (checkedValue) {
					var checkedMember = memberTbody.querySelector("tbody > tr > td > input[value='" + checkedValue + "']");
					if (checkedMember)  checkedMember.checked = true;
				}

				if (close)  close();
			}
		};

		$jnode$.storage.eventhandler4import.ok(memberList);

		if (memberList.length > 0) {
			var checkedInput = document.querySelector("article > div.article > form > table.form > tbody > tr.member > td > table > tbody > tr > td > input:checked");
			if (checkedInput) {
				var checkedMember = memberTbody.querySelector("tbody > tr > td > input[value='" + checkedInput.value + "']");
				if (checkedMember)  checkedMember.checked = true;
			}
		}

		okButton.addEventListener("click", function(event) {
			var alertMessage = null;

			params.project_info.project_name = document.importForm.project_name.value.trim();

			if (params.project_info.project_name == "") {
				alertMessage = i18n.alert_input_project_name;
				document.importForm.project_name.focus();
			} else {
				var memberIds  = [];
				var memberRows = memberTbody.querySelectorAll("tbody > tr");

				for (var i = 0; i < memberRows.length; i++) {
					memberIds.push(memberRows[i].getAttribute("id"));
				}

				if (memberIds.length == 0) {
					alertMessage = i18n.alert_select_project_member;
					memberButton.focus();
				} else {
					params.user_id = memberIds;

					if (memberIds.length == 1) {
						params.manager = memberIds[0];
					} else {
						var checkedInput = memberTbody.querySelector("tbody > tr > td > input:checked");
						if (checkedInput)  params.manager = checkedInput.value;
						else               alertMessage = i18n.alert_select_project_manager;
					}
				}

				if (alertMessage == null) {
					var replacedUsers = [];

					for (var i = 0; i < workerSelects.length; i++) {
						var userId    = workerSelects[i].getAttribute("name");
						var newUserId = workerSelects[i].value;

						if (newUserId) {
							if (userId != newUserId) {
								replacedUsers.push({
									user_id:     userId,
									new_user_id: newUserId
								});
							}
						} else {
							alertMessage = "지정 안된 일감 작업자가 있습니다.";
							workerSelects[i].focus();
							break;
						}
					}

					params.replacedUsers = replacedUsers;
				}
			}

			if (alertMessage) {
				this.parentNode.previousElementSibling.innerHTML = alertMessage;
			} else {
				$controller$.loading.show();

				$jnode$.ajax.service({
					"url":      "/project/import.json",
					"method":   "POST",
					"datatype": "json",
					"headers": {
						"Content-Type": "application/json",
						"Accept":       "application/json"
					},
					"params":  params,
					"success": function(response) {
						$controller$.popup.close();
						var projectId = response.project_id;

						if (projectId == 0) {
							// 다시 생성하는 화면으로...
							document.querySelector("body > section > div.section > nav > fieldset > ul > li > div > ul > li:first-child > ul > li:first-child > button:first-child").click();
						} else {
							startId = response.start_id;
							alert_precondition_required = null;


							if (nextStep == "project") {
								var projectInfo = params.project_info;
								projectInfo.project_id = projectId;

								$content$.section.project.appendProject(projectInfo, null, true);
							} else {
								document.querySelector("body > nav > ul > li > label > input[name='section_menu'][value='/gantt']").click();
							}
						}
					},
					"error": function(error) {
						$jnode$.ajax.alertError(error);
						$controller$.loading.hide();
					}
				});
			}
		}, false);
	},

	unload: function() {
		delete $jnode$.storage.eventhandler4import;
		window.removeEventListener("resize", this.resize, false);
	}
}