$content$.winup.gantt.download = {
	service: function() {
		var compressionRatioContainer = document.querySelector("aside.winup article > div.winup > form > table.form > tbody > tr:last-child");
		document.imageForm.mime_type.addEventListener("change", function(event) {
			if (this.value == "image/jpeg") {
				compressionRatioContainer.removeAttribute("style");
				$controller$.winup.resize(480, 211);
			} else {
				compressionRatioContainer.style.display = "none";
				$controller$.winup.resize(480, 180);
			}
		}, false);

		document.imageForm.querySelector("form > ul > li:last-child > button").addEventListener("click", function(event) {
			var fileName  = document.imageForm.file_name.value.trim();
			var mimeType  = document.imageForm.mime_type.value;
			var extension = mimeType.substring(6);  // image/webp
			var extIndex  = fileName.lastIndexOf(".");

			if (extIndex > -1) {
				var extFromName = fileName.toLowerCase().substring(extIndex + 1);

				if (extension == extFromName || (extension == "jpeg" && ["jpg", "jpe"].indexOf(extFromName) > -1)) {
					fileName = fileName.substring(0, extIndex);
					extension = extFromName;
				}
			}

			if (fileName == "") {
				this.parentNode.previousElementSibling.innerHTML = i18n.alert_input_file_name;
				document.imageForm.file_name.select();
			} else {
				$controller$.loading.show();
				$controller$.winup.close();

				var downloadContainer = document.querySelector("body > section > div.section > div.download");

				var downloadGantt = document.createElement("ul");
				downloadGantt.setAttribute("id", "gantt");
				downloadContainer.appendChild(downloadGantt);

				downloadGantt.innerHTML = document.querySelector("body > section > div.section > ul#gantt").innerHTML;

				downloadGantt.querySelector("ul#gantt > li:first-child > ul > li:last-child > div > div").removeAttribute("style");
				downloadGantt.querySelector("ul#gantt > li:last-child > ul > li:last-child").removeAttribute("style");
				downloadGantt.querySelector("ul#gantt > li:last-child > ul > li:last-child > div").removeAttribute("style");
				downloadGantt.querySelector("ul#gantt > li:last-child > ul > li:first-child > ul > li:first-child > div").removeAttribute("style");

				html2canvas(downloadGantt, {
					scale: parseInt(document.imageForm.scale.value, 10)
				}).then(function(canvas) {
					var dataName = fileName + "." + extension;
					var dataURL  = null;

					if (mimeType == "image/jpeg")  dataURL = canvas.toDataURL(mimeType, parseFloat(document.imageForm.compression_ratio.value));
					else                           dataURL = canvas.toDataURL(mimeType);

					// \ / => ·
					// :   => =
					// "   => '
					// <   => [
					// >   => ]
					dataName = dataName.replace(/\\/g, "·").replace(/\//g, "·").replace(/:/g, "=").replace(/\"/g, "'").replace(/</g, "[").replace(/>/g, "]");

					document.downForm.data_name.value = dataName;
					document.downForm.data_url.value  = dataURL;
					document.downForm.submit();

					/*
					// IE와 EdgeHTML 엔진을 사용하는 Edge에서 작동 안 됨
					var downLink = document.createElement("a");
					downLink.download = dataName;
					downLink.href     = dataURL;
					downLink.dataset.downloadurl = ["image/png", downLink.download, downLink.href].join(":");

					downloadContainer.appendChild(downLink);
					downLink.click();
					downloadContainer.removeChild(downLink);
					*/

					downloadContainer.removeChild(downloadGantt);
					$controller$.loading.hide();
				});
			}
		}, false);
	}
};