/*
DROP TABLE setting;
DROP TABLE code;
DROP TABLE usr;
DROP TABLE pos;
DROP TABLE org;
DROP TABLE team;
DROP TABLE project;
DROP TABLE member;
DROP TABLE task;
DROP TABLE note;
DROP TABLE history;
DROP TABLE version;

DROP SEQUENCE pos_seq;
DROP SEQUENCE org_seq;
DROP SEQUENCE project_seq;
DROP SEQUENCE task_seq;
DROP SEQUENCE note_seq;
DROP SEQUENCE history_seq;
DROP SEQUENCE version_seq;
*/

-- -----------------------------------------------------
-- Table: setting
-- -----------------------------------------------------
CREATE TABLE setting (
  user_id        VARCHAR(30 BYTE) DEFAULT '-' NOT NULL,
  setting_key    VARCHAR(30 BYTE)             NOT NULL,
  setting_value  VARCHAR(30 BYTE)             NOT NULL,
  CONSTRAINT pk_setting PRIMARY KEY (user_id, setting_key)
)
TABLESPACE popopa;

-- -----------------------------------------------------
-- Table: code
-- -----------------------------------------------------
CREATE TABLE code (
  code_group  VARCHAR(30 BYTE) DEFAULT '-' NOT NULL,
  code_id     VARCHAR(30 BYTE)             NOT NULL,
  code_name   VARCHAR(50 CHAR)             NOT NULL,
  code_sort   NUMBER (22,   0) DEFAULT 0   NOT NULL,
  CONSTRAINT pk_code PRIMARY KEY (code_group, code_id)
)
TABLESPACE popopa;

CREATE INDEX idx_code ON code(code_sort);

-- -----------------------------------------------------
-- Table: usr
-- -----------------------------------------------------
CREATE TABLE usr (
  user_id        VARCHAR(45 BYTE) NOT NULL,
  user_name      VARCHAR(50 CHAR) NOT NULL,
  user_password  VARCHAR(50 BYTE) NOT NULL,
  user_level     VARCHAR(3  BYTE) NOT NULL,
  user_changed   VARCHAR(20 BYTE) NOT NULL,  /* YYYY-MM-ddTHH:mm:ss */
  user_retired   VARCHAR(20 BYTE)     NULL,
  position_id    NUMBER (22,   0)     NULL,
  org_id         NUMBER (22,   0)     NULL,
  CONSTRAINT pk_usr PRIMARY KEY (user_id)
)
TABLESPACE popopa;

CREATE INDEX idx_usr ON usr(user_name, user_retired, position_id, org_id);

-- -----------------------------------------------------
-- Table: pos
-- -----------------------------------------------------
CREATE TABLE pos (
  position_id    NUMBER (22,   0)           NOT NULL,
  position_name  VARCHAR(50 CHAR)           NOT NULL,
  position_sort  NUMBER (22,   0) DEFAULT 0 NOT NULL,
  CONSTRAINT pk_pos PRIMARY KEY(position_id)
)
TABLESPACE popopa;

CREATE INDEX idx_pos ON pos(position_sort);

CREATE SEQUENCE pos_seq
  INCREMENT BY 1
  NOMAXVALUE
  NOCYCLE
  NOCACHE;

-- -----------------------------------------------------
-- Table: org
-- -----------------------------------------------------
CREATE TABLE org (
  org_id      NUMBER (22,   0)           NOT NULL,
  org_name    VARCHAR(50 CHAR)           NOT NULL,
  org_parent  NUMBER (22,   0) DEFAULT 0 NOT NULL,
  org_sort    NUMBER (22,   0) DEFAULT 0 NOT NULL,
  CONSTRAINT pk_org PRIMARY KEY (org_id)
)
TABLESPACE popopa;

CREATE INDEX idx_org ON org(org_sort);

CREATE SEQUENCE org_seq
  INCREMENT BY 1
  NOMAXVALUE
  NOCYCLE
  NOCACHE;

-- -----------------------------------------------------
-- Table: team
-- -----------------------------------------------------
CREATE TABLE team (
  team_manager     VARCHAR(45 BYTE)                    NOT NULL,
  team_engineer    VARCHAR(45 BYTE)                    NOT NULL,
  team_createdate  VARCHAR(20 BYTE)                    NOT NULL,
  member_status    VARCHAR(10 BYTE) DEFAULT 'reserved' NOT NULL,
  CONSTRAINT pk_team PRIMARY KEY (team_manager, team_engineer)
)
TABLESPACE popopa;

CREATE INDEX idx_team ON team(member_status);

-- -----------------------------------------------------
-- Table: project
-- -----------------------------------------------------
CREATE TABLE project (
  project_id    NUMBER (22,     0)           NOT NULL,
  project_name  VARCHAR(100  CHAR)           NOT NULL,
  dayoff        NUMBER (1,      0) DEFAULT 2 NOT NULL,
  startdate     VARCHAR(20   BYTE)           NOT NULL,
  enddate       VARCHAR(20   BYTE)           NOT NULL,
  project_desc  VARCHAR(4000 BYTE)               NULL,
  completion    VARCHAR(20   BYTE)               NULL,
  project_sort  NUMBER (22,     0) DEFAULT 0 NOT NULL,
  CONSTRAINT pk_project PRIMARY KEY (project_id)
)
TABLESPACE popopa;

CREATE INDEX idx_project ON project(project_name);

CREATE SEQUENCE project_seq
  INCREMENT BY 1
  NOMAXVALUE
  NOCYCLE
  NOCACHE;

-- -----------------------------------------------------
-- Table: member
-- -----------------------------------------------------
CREATE TABLE member (
  group_type   VARCHAR(10 BYTE)           NOT NULL,
  group_id     NUMBER (22,   0)           NOT NULL,
  user_id      VARCHAR(45 BYTE)           NOT NULL,
  member_type  VARCHAR(30 BYTE)           NOT NULL,
  member_sort  NUMBER (22,   0) DEFAULT 0 NOT NULL,
  group_sort   NUMBER (22,   0) DEFAULT 0 NOT NULL,
  CONSTRAINT pk_member PRIMARY KEY (group_type, group_id, user_id)
)
TABLESPACE popopa;

-- -----------------------------------------------------
-- Table: task
-- -----------------------------------------------------
CREATE TABLE task (
  project_id   NUMBER (22,    0)           NOT NULL,
  task_id      NUMBER (22,    0)           NOT NULL,
  task_name    VARCHAR(100 CHAR)           NOT NULL,
  user_id      VARCHAR(45  BYTE)               NULL,
  startdate    VARCHAR(20  BYTE)               NULL,
  enddate      VARCHAR(20  BYTE)               NULL,
  progress     NUMBER (22,    0)               NULL,
  task_parent  NUMBER (22,    0) DEFAULT 0 NOT NULL,
  task_sort    NUMBER (22,    0) DEFAULT 0 NOT NULL,
  ref_task     NUMBER (22,    0)               NULL,
  CONSTRAINT pk_task PRIMARY KEY (task_id)
)
TABLESPACE popopa;

CREATE INDEX idx_task ON task(project_id, user_id, startdate, enddate, task_parent, task_sort);
CREATE INDEX idx_ref_task ON task(project_id, task_parent, task_id);

CREATE SEQUENCE task_seq
  INCREMENT BY 1
  NOMAXVALUE
  NOCYCLE
  NOCACHE;

-- -----------------------------------------------------
-- Table: note
-- -----------------------------------------------------
CREATE TABLE note (
  project_id  NUMBER (22,     0) NOT NULL,
  task_id     NUMBER (22,     0) NOT NULL,
  note_id     NUMBER (22,     0) NOT NULL,
  note_name   VARCHAR(100  CHAR) NOT NULL,
  note_type   VARCHAR(10   BYTE) NOT NULL,
  note_desc   VARCHAR(4000 BYTE) NOT NULL,
  action      VARCHAR(4000 BYTE)     NULL,
  completion  VARCHAR(20   BYTE)     NULL,
  CONSTRAINT pk_note PRIMARY KEY (note_id)
)
TABLESPACE popopa;

CREATE INDEX idx_note ON note(project_id, task_id);

CREATE SEQUENCE note_seq
  INCREMENT BY 1
  NOMAXVALUE
  NOCYCLE
  NOCACHE;

-- -----------------------------------------------------
-- Table: history
-- -----------------------------------------------------
CREATE TABLE history (
  history_id    NUMBER (22,   0)                 NOT NULL,
  project_id    NUMBER (22,   0)                 NOT NULL,
  user_id       VARCHAR(45 BYTE)                 NOT NULL,
  history_date  TIMESTAMP        DEFAULT SYSDATE NOT NULL,
  history_type  VARCHAR(30 BYTE)                 NOT NULL,
  target_id     VARCHAR(30 BYTE)                 NOT NULL,
  target_name   VARCHAR(50 CHAR)                 NOT NULL,
  target_crud   VARCHAR(1  BYTE)                 NOT NULL,
  CONSTRAINT pk_history PRIMARY KEY (history_id)
)
TABLESPACE popopa;

CREATE INDEX idx_history ON history(project_id, history_type);

CREATE SEQUENCE history_seq
  INCREMENT BY 1
  NOMAXVALUE
  NOCYCLE
  NOCACHE;

-- -----------------------------------------------------
-- Table: version
-- -----------------------------------------------------
CREATE TABLE version (
  version_id    NUMBER (22,   0)             NOT NULL,
  version_name  VARCHAR(20 BYTE)             NOT NULL,
  user_id       VARCHAR(45 BYTE)             NOT NULL,
  released      VARCHAR(20 BYTE)             NOT NULL,
  updated       VARCHAR(20 BYTE) DEFAULT '0' NOT NULL,  /* 0: start upgrade, 1: continue after rebooting, YYYY-MM-ddTHH:mm:ss: upgraded date */
  CONSTRAINT pk_version PRIMARY KEY (version_id)
)
TABLESPACE popopa;

CREATE SEQUENCE version_seq
  INCREMENT BY 1
  NOMAXVALUE
  NOCYCLE
  NOCACHE;

/**********************************/
/* auth_level                     */
/**********************************/                              /* code_group  , code_id     , code_name  , code_sort */
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('-'         , 'auth_level', 'Auth level', 0);
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('auth_level', 'high'      , 'High'      , 0); /* Do not notify invalid field. */
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('auth_level', 'low'       , 'Low'       , 1); /* Notify invalid field. (ID/Password) */

/**********************************/
/* user_level                     */
/**********************************/                              /* code_group  , code_id     , code_name         , code_sort */
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('-'         , 'user_level', 'User level'      , 0);
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('user_level', '9'         , 'PoPoPa Admin'    , 0); /* admin         */
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('user_level', '1'         , 'Project Engineer', 2); /* pe            */
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('user_level', '0'         , 'Admin Creator'   , 3); /* admin_creator */

/**********************************/
/* group_type                     */
/**********************************/                              /* code_group  , code_id     , code_name      , code_sort */
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('-'         , 'group_type', 'Group type'   , 0);
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('group_type', 'project'   , 'Project group', 0);
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('group_type', 'team'      , 'Team group'   , 1);

/**********************************/
/* member_type                    */
/**********************************/                              /* code_group   , code_id      , code_name    , code_sort */
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('-'          , 'member_type', 'Member type', 0);
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('member_type', 'manager'    , 'Manager'    , 0);
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('member_type', 'engineer'   , 'Engineer'   , 1);

/**********************************/
/* team_status                    */
/**********************************/                              /* code_group     , code_id        , code_name      , code_sort */
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('-'            , 'member_status', 'Member status', 0);
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('member_status', 'reserved'     , 'Reserved'     , 0);
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('member_status', 'included'     , 'Included'     , 1);
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('member_status', 'excluded'     , 'Excluded'     , 2);

/**********************************/
/* note_type                      */
/**********************************/                              /* code_group , code_id    , code_name  , code_sort */
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('-'        , 'note_type', 'Note type', 0);
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('note_type', 'memo'     , 'Memo'     , 0);
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('note_type', 'issue'    , 'Issue'    , 1);

/**********************************/
/* anchor_week                    */
/**********************************/                              /* code_group   , code_id      , code_name      , code_sort */
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('-'          , 'anchor_week', 'Base week'    , 0);
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('anchor_week', 'prev'       , 'Previous week', 0);
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('anchor_week', 'curr'       , 'Current week' , 1);
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('anchor_week', 'auto'       , 'Auto'         , 2);

/**********************************/
/* anchor_month                   */
/**********************************/                              /* code_group    , code_id       , code_name       , code_sort */
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('-'           , 'anchor_month', 'Base month'    , 0);
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('anchor_month', 'prev'        , 'Previous month', 0);
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('anchor_month', 'curr'        , 'Current month' , 1);
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('anchor_month', 'auto'        , 'Auto'          , 2);

/**********************************/
/* report_user                   */
/**********************************/                              /* code_group   , code_id      , code_name                     , code_sort */
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('-'          , 'report_user', 'Task of team members'        , 0);
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('report_user', 'member'     , 'Include task of team members', 0);
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('report_user', 'alone'      , 'Exclude task of team members', 1);

/**********************************/
/* history_type                   */
/**********************************/                              /* code_group    , code_id       , code_name     , code_sort */
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('-'           , 'history_type', 'History type', 0);
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('history_type', 'user'        , 'User'        , 0);
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('history_type', 'project'     , 'Project'     , 1);
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('history_type', 'task'        , 'Task'        , 2);
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('history_type', 'weekly'      , 'Weekly'      , 3);
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('history_type', 'monthly'     , 'Monthly'     , 4);

/**********************************/
/* Initial Setting Value          */
/**********************************/                          /*  user_id, setting_key                    , setting_value */
INSERT INTO setting (user_id, setting_key, setting_value) VALUES ('-'    , 'lang'                         , 'auto'   );
INSERT INTO setting (user_id, setting_key, setting_value) VALUES ('-'    , 'theme'                        , 'light'  );
INSERT INTO setting (user_id, setting_key, setting_value) VALUES ('-'    , 'use_init_admin'               , 'true'   );
INSERT INTO setting (user_id, setting_key, setting_value) VALUES ('-'    , 'update_account'               , 'false'  );
INSERT INTO setting (user_id, setting_key, setting_value) VALUES ('-'    , 'sync_setting'                 , 'false'  );
INSERT INTO setting (user_id, setting_key, setting_value) VALUES ('-'    , 'dayoff'                       , '2'      );
INSERT INTO setting (user_id, setting_key, setting_value) VALUES ('-'    , 'use_org'                      , 'false'  );
INSERT INTO setting (user_id, setting_key, setting_value) VALUES ('-'    , 'exclude_admin'                , 'true'   );
INSERT INTO setting (user_id, setting_key, setting_value) VALUES ('-'    , 'auth_level'                   , 'high'   );
INSERT INTO setting (user_id, setting_key, setting_value) VALUES ('-'    , 'anchor_week'                  , 'auto'   );
INSERT INTO setting (user_id, setting_key, setting_value) VALUES ('-'    , 'anchor_month'                 , 'auto'   );
INSERT INTO setting (user_id, setting_key, setting_value) VALUES ('-'    , 'report_user'                  , 'member' );
INSERT INTO setting (user_id, setting_key, setting_value) VALUES ('-'    , 'display_user'                 , 'false'  );
INSERT INTO setting (user_id, setting_key, setting_value) VALUES ('-'    , 'start_page'                   , 'gantt'  );
INSERT INTO setting (user_id, setting_key, setting_value) VALUES ('-'    , 'next_step_of_creating_project', 'project');

/****************************************************************************/
/* The initial account information for createing administrator only         */
/* -- Important: DO NOT EDIT THIS ACCOUNT --                                */
/****************************************************************************/                                        /* user_id   , user_name        , user_password, user_level, user_changed                              , user_retired, position_id, org_id */
INSERT INTO usr (user_id, user_name, user_password, user_level, user_changed, user_retired, position_id, org_id) values ('${admin}', 'PoPoPa Customer', '${admin}'   , '0'       , TO_CHAR(SYSDATE,'YYYY-MM-DD"T"HH24:MI:SS'), NULL        , NULL       , NULL);

exit;