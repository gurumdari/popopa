document.querySelector("body > header > ul > li:first-child > h1").addEventListener("click", function(event) {
	$controller$.loading.show();
	document.location.reload();
}, false);

var refreshButton = document.querySelector("body > section > div.section > article > div.article > ul > li > ul.error > li:last-child > div.button > button");
if (refreshButton) {
	refreshButton.addEventListener("click", function(event) {
		$controller$.loading.show();
		document.location.reload();
	}, false);

	window.setTimeout(function() {
		refreshButton.click();
	}, 12000);  // 12초 후에 재로딩
}