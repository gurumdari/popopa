var i18n = {};
var alert_precondition_required = i18n.alert_precondition_required;
var sectionNavSlideSize = {
	shrink: "shrink",
	expand: "expand"
};

var isMobile = $jnode$.device.type != "desktop";
var isPhone  = $jnode$.device.type == "phone";

function linkArticle(articleId) {
	var sectionId = "/" + articleId.split("/")[1];
	var sectionMenu = document.querySelector("body > nav > ul > li > label > input[name='section_menu'][value='" + sectionId + "']");

	if (sectionMenu) {
		sectionMenu.checked = true;
		document.querySelector("body > nav > ul > li:last-child > div").innerHTML = sectionMenu.nextElementSibling.lastElementChild.innerHTML;
	}

	var articleMenu = document.querySelector("body > section > div.section > nav > div:last-child > fieldset > div > ul > li > label > input[name='article_menu'][value='" + articleId +"']");
	if (articleMenu) {
		if (!articleMenu.checked) {
			articleMenu.click();
			window.scrollTo(0, 0);
		}
	} else {
		$jnode$.requireContent("section", sectionId, {useLoading:true, articleId:articleId});
	}
}

function setUserSettingMenu(use_org) {
	window.useOrg = use_org;

	var userOrgArticleMenu = document.querySelector("body > section > div.section > nav > div:last-child > fieldset > div > ul > li > label > input[name='article_menu'][value='/setting/user']");
	if (userOrgArticleMenu == null)  userOrgArticleMenu = document.querySelector("body > section > div.section > nav > div:last-child > fieldset > div > ul > li > label > input[name='article_menu'][value='/setting/org']");

	if (userOrgArticleMenu) {
		var userOrgArticleId = "/setting/user";
		
		if (useOrg)   userOrgArticleId = "/setting/org";
		if (startId && startId.indexOf("/setting/") == 0)  startId = userOrgArticleId;

		userOrgArticleMenu.value = userOrgArticleId;
	}
}

function setSectionTitle(sectionId, sectionName) {
	var sectionTitle = document.querySelector("body > section > div.section > header.title");

	if (sectionTitle) {
		var checkedSectionInput = document.querySelector("body > nav > ul > li > label > input[name='section_menu'][value='" + sectionId + "']");
		var checkedSectionName  = checkedSectionInput.nextElementSibling.lastElementChild.innerHTML;
		checkedSectionInput.checked = true;

		document.querySelector("body > nav > ul > li:last-child > div").innerHTML = checkedSectionName;

		if (sectionName)  sectionTitle.firstElementChild.innerHTML = sectionName;
		else              sectionTitle.innerHTML = checkedSectionName;
	}
}

function linkStartId() {
	if (startId.split("/").length == 2) {
		document.querySelector("body > nav > ul > li > label > input[name='section_menu'][value='" + startId + "']").click();
	} else {
		$controller$.prompt.alert(alert_precondition_required, function(close) {
			linkArticle(startId);
			close();
		}, true);
	}
}

function setSectionMenus(hash) {
	var sectionMenus = document.querySelectorAll("body > nav > ul > li > label > input[name='section_menu']");

	for (var i = 0; i < sectionMenus.length; i++) {
		sectionMenus[i].addEventListener("click", function(event) {
			if ((startId.split("/").length > 2) && !(this.value == "/setting" || startId.indexOf(this.value) == 0)) {
				linkStartId();
			} else {
				$jnode$.requireContent("section", this.value, {useLoading:true});
				document.querySelector("body > nav > ul > li:last-child > div").innerHTML = this.nextElementSibling.lastElementChild.innerHTML;
				window.scrollTo(0, 0);
			}
		}, false);

		if (!isPhone) {
			sectionMenus[i].parentNode.addEventListener("mouseover", function(event) {
				document.querySelector("body > nav > ul > li:last-child > div").innerHTML = this.lastElementChild.lastElementChild.innerHTML;
			}, false);

			sectionMenus[i].parentNode.addEventListener("mouseout", function(event) {
				document.querySelector("body > nav > ul > li:last-child > div").innerHTML = document.querySelector("body > nav > ul > li > label > input[name='section_menu']:checked + span > font:last-child").innerHTML;
			}, false);
		}
	}

	if (startId.split("/").length == 2) {
		if (hash)  handleHash(hash);
		else       document.querySelector("body > nav > ul > li > label > input[name='section_menu'][value='" + startId + "']").click();
	} else {
		linkArticle(startId);
	}
}

// 모바일을 위해 section > nav를 접었을 때 사이즈에 따라 펼쳐졌다 접히는 증상을 없애기 위해 별도 처리
function shrinkSectionNavSlide(sectionNav) {
	sectionNav.setAttribute("class", sectionNavSlideSize.shrink);

	window.setTimeout(function() {
		sectionNav.removeAttribute("class");
	}, 500);
}

function setArticleMenus(newSectionNavSlideSize, articleId, requirePrecondition) {
	sectionNavSlideSize = newSectionNavSlideSize;

	var articleTitle = document.querySelector("body > section > div.section > nav > div:first-child");
	if (articleTitle) {
		articleTitle.addEventListener("click", function(event) {
			var sectionNav = this.parentNode;

			if (sectionNav.getAttribute("class") == sectionNavSlideSize.expand) {
				shrinkSectionNavSlide(sectionNav);
			} else {
				sectionNav.setAttribute("class", sectionNavSlideSize.expand);
			}
		}, false);
	}

	var articleMenus = document.querySelectorAll("body > section > div.section > nav > div:last-child > fieldset > div > ul > li > label > input[name='article_menu']");
	var articleMenu  = null;

	if (articleMenus.length > 0) {
		for (var i = 0; i < articleMenus.length; i++) {
			articleMenus[i].addEventListener("click", function(event) {
				if (requirePrecondition && startId != this.value) {
					linkStartId();
					articleMenus[0].checked = true;
				} else {
					if (this.value == "/setting/about") {
						$jnode$.requireContent("article", this.value, {blang: "auto"});
					} else {
						$jnode$.requireContent("article", this.value);
					}

					articleTitle.innerHTML = this.nextElementSibling.innerHTML;
				}

				if (articleTitle.parentNode.getAttribute("class") == sectionNavSlideSize.expand) {
					shrinkSectionNavSlide(articleTitle.parentNode);
				}
			}, false);
			
			if (articleId == articleMenus[i].value)  articleMenu = articleMenus[i];
		}

		if (articleMenu == null)  articleMenu = articleMenus[0];

		var sectionId = "/" + articleMenu.value.split("/")[1];
		document.querySelector("body > nav > ul > li > label > input[name='section_menu'][value='" + sectionId + "']").checked = true;

		articleMenu.click();
	}

	window.scrollTo(0, 0);
}

setSectionMenus(document.location.hash);

document.querySelector("body > header > ul > li:first-child > h1").addEventListener("click", function(event) {
	linkStartId();
}, false);

document.querySelector("body > header > ul > li:last-child > ul > li.account").addEventListener("click", function(event) {
	linkArticle("/setting/account");
}, false);

document.querySelector("body > header > ul > li:last-child > ul > li.setting").addEventListener("click", function(event) {
	document.querySelector("body > nav > ul > li > label > input[name='section_menu'][value='/setting']").click();
}, false);

document.querySelector("body > header > ul > li:last-child > ul > li.help").addEventListener("click", function(event) {
	var helpWin = window.open("https://popopa.gurumdari.com", "popopa_help");
	helpWin.focus();
}, false);

document.querySelector("body > header > ul > li:last-child > ul > li.logout").addEventListener("click", function(event) {
	$controller$.loading.show();
	document.logoutForm.submit();
}, false);

function getMonthLocalePatterns(mediumPattern) {
	var patternCell1 = "M";
	var patternCell2 = "M";
	var yearMonth    = "yyyy-MM";

	if (mediumPattern.search(/dd$/) == mediumPattern.length - 2) {
		yearMonth = mediumPattern.substring(0, mediumPattern.length - 3);
	} else if (mediumPattern.search(/d$/) == mediumPattern.length - 1) {
		yearMonth = mediumPattern.substring(0, mediumPattern.length - 2);
	} else if (mediumPattern.search(/^dd/) == 0) {
		yearMonth = mediumPattern.substring(3);
	} else if (mediumPattern.search(/^d/) == 0) {
		yearMonth = mediumPattern.substring(2);
	} else {
		var dIndex = mediumPattern.indexOf("d");
		if (dIndex > 0) {
			if (mediumPattern.indexOf("dd") > 0 && mediumPattern.indexOf("dd") < mediumPattern.length - 3) {
				yearMonth = mediumPattern.substring(0, dIndex - 1) + mediumPattern.substring(dIndex + 2);
			} else if (dIndex < mediumPattern.length - 2) {
				yearMonth = mediumPattern.substring(0, dIndex - 1) + mediumPattern.substring(dIndex + 1);
			}
		}
	}

	if (yearMonth.indexOf("MMM") > -1) {
		patternCell2 = "MMM";
	} else if (yearMonth.indexOf("MM") > -1) {
		patternCell1 = "MM";
		patternCell2 = "MM";
	}

	/*
	var patternYearMonth = yearMonth.replace(new RegExp(patternCell2), "%s");
	// patternYearMonth.replace(/yyyy/, "2015").replace(/\%s/, "W23")
	*/

	return {
		"cell1":     patternCell1,
		"cell2":     patternCell2,
		"yearMonth": yearMonth
	}
}



var dateUtil = $module$.date.Utils;

function displayCalendar(date, mode, periodDom, container, currDateTextValue, callback) {
	var yearMonthPattern = "yyyy-MM";
	
	if (mode == "month") {
		yearMonthPattern = getMonthLocalePatterns(dateFormatter.DateStyle.MEDIUM).yearMonth;
	}

	function pad(val, len) {
		val = String(val);
		len = len || 2;
		while (val.length < len) {
			val = "0" + val;
		}
		return val;
	}

	function setDate(node, date, periodDom, monthIndex) {
		node.addEventListener("click", function(event) {
			if (mode == "week") {
				var yearWeeks = dateUtil.parseYearWeeks(date);
				var basicDate = yearWeeks[0];
				var selectedDateTextValue = null;
				var basicMonthIndex = basicDate.getMonth();

				if ((basicMonthIndex < monthIndex) || (basicMonthIndex == 11 && monthIndex == 0)) {
					basicDate = yearWeeks[1];
				}

				if (Object.prototype.toString.call(periodDom) != "[object Array]")  periodDom = [periodDom];

				if (periodDom[0])  periodDom[0].innerHTML = dateFormatter.format(yearWeeks[1], "yyyy-'W'ww");
				if (periodDom[1])  periodDom[1].innerHTML = dateFormatter.format(yearWeeks[0], dateFormatter.DateStyle.MEDIUM) + "<FONT>" + dateUtil.format(yearWeeks[0]) + "</FONT>";
				if (periodDom[2])  periodDom[2].innerHTML = dateFormatter.format(yearWeeks[1], dateFormatter.DateStyle.MEDIUM) + "<FONT>" + dateUtil.format(yearWeeks[1]) + "</FONT>";

				if (callback)  callback(date);
				displayCalendar(basicDate, mode, periodDom, container, dateUtil.format(yearWeeks[1]), callback);
			} else if (mode == "date"){
				periodDom.innerHTML = dateFormatter.format(dateUtil.parse(date), dateFormatter.DateStyle.LONG) + "<FONT>" + date + "</FONT>";

				if (callback)  callback(date);
				displayCalendar(date, mode, periodDom, container, date, callback);
			} else {
				var fristDateISO = date.substring(0, date.length - 2) + "01";
				var firstDate    = dateUtil.parse(fristDateISO);
				var lastDate     = dateUtil.parse(date);

				if (Object.prototype.toString.call(periodDom) != "[object Array]")  periodDom = [periodDom];

				if (periodDom[0])  periodDom[0].innerHTML = dateFormatter.format(firstDate, yearMonthPattern);
				if (periodDom[1])  periodDom[1].innerHTML = dateFormatter.format(firstDate, dateFormatter.DateStyle.MEDIUM) + "<FONT>" + fristDateISO + "</FONT>";
				if (periodDom[2])  periodDom[2].innerHTML = dateFormatter.format(lastDate, dateFormatter.DateStyle.MEDIUM) + "<FONT>" + date + "</FONT>";

				if (callback)  callback(date);
				displayCalendar(date, mode, periodDom, container, date, callback);
			}
		}, false);
	}

	var calendarDate = null;

	if (Object.prototype.toString.call(date) == "[object Date]") {
		calendarDate = date;
	} else {
		calendarDate = dateUtil.parse(date);
	}

	var year = calendarDate.getFullYear();

	if (mode == "month") {
		container.innerHTML = "";

		var yearUl = document.createElement("ul");
		yearUl.setAttribute("class", "month");
		container.appendChild(yearUl);

		var prevYearLink = document.createElement("span");
		prevYearLink.innerHTML = year - 1;

		var prevYearLi = document.createElement("li");
		prevYearLi.setAttribute("class", "prev");
		prevYearLi.appendChild(prevYearLink);
		yearUl.appendChild(prevYearLi);

		var currYearLi = document.createElement("li");
		currYearLi.setAttribute("class", "current");
		currYearLi.innerHTML = year;
		yearUl.appendChild(currYearLi);

		var nextYearLink = document.createElement("span");
		nextYearLink.innerHTML = year + 1;

		var nextYearLi = document.createElement("li");
		nextYearLi.setAttribute("class", "next");
		nextYearLi.appendChild(nextYearLink);
		yearUl.appendChild(nextYearLi);

		prevYearLink.addEventListener("click", function() {
			displayCalendar(new Date(year - 1, 0, 1), mode, periodDom, container, currDateTextValue, callback);  // .format("yyyy-MM-dd")
		}, false);

		nextYearLink.addEventListener("click", function() {
			displayCalendar(new Date(year + 1, 0, 1), mode, periodDom, container, currDateTextValue, callback);  // .format("yyyy-MM-dd")
		}, false);

		var currMonthValue     = dateFormatter.format(dateUtil.parse(currDateTextValue), yearMonthPattern);
		var separatedCurrDates = currDateTextValue.split("-");
		var currYear           = parseInt(separatedCurrDates[0], 10);
		var currMonth          = parseInt(separatedCurrDates[1], 10);
		var currMonthIndex     = currMonth - 1;
		var monthNames         = dateFormatter.Symbols.MonthNames;
		var monthIndex         = 0;

		var table = document.createElement("table");
		table.setAttribute("class", "month");
		container.appendChild(table);

		for (var i = 0; i < 4; i++) {
			var row = table.insertRow(i);

			for (var j = 0; j < 3; j++) {
				monthIndex = (i * 3) + j;

				var lastDayOfMonth = new Date(year, monthIndex + 1, 0).getDate();
				var monthName = monthNames[monthIndex];

				var cell = row.insertCell(j);
				cell.setAttribute("class", "month");

				if (currMonthIndex == monthIndex) {
					monthName = "<B>" + monthName + "</B>";

					if (currYear == year) {
						cell.setAttribute("class", "month selected");
					}
				}

				cell.innerHTML = "<DIV>" + monthName + "</DIV><DIV>(1 ~ " + lastDayOfMonth + ")</DIV>";

				setDate(cell, year + "-" + pad(monthIndex + 1) + "-" + lastDayOfMonth, periodDom);
			}
		}

		var currDateDiv = document.createElement("div");
		currDateDiv.appendChild(document.createTextNode(currMonthValue));

		currDateDiv.addEventListener("click", function() {
			displayCalendar(currDateTextValue, mode, periodDom, container, currDateTextValue, callback);
		}, false);

		container.appendChild(currDateDiv);
	} else {
		var monthIndex = calendarDate.getMonth();
		var arr2Day    = dateUtil.getCalendarMatrix(year, monthIndex);

		container.innerHTML = "";

		var yearUl = document.createElement("ul");
		container.appendChild(yearUl);

		var prevYearLink = document.createElement("span");
		prevYearLink.innerHTML = year - 1;

		var prevYearLi = document.createElement("li");
		prevYearLi.setAttribute("class", "prev");
		prevYearLi.appendChild(prevYearLink);
		yearUl.appendChild(prevYearLi);

		var currYearLi = document.createElement("li");
		currYearLi.setAttribute("class", "current");
		currYearLi.innerHTML = year;
		yearUl.appendChild(currYearLi);

		var nextYearLink = document.createElement("span");
		nextYearLink.innerHTML = year + 1;

		var nextYearLi = document.createElement("li");
		nextYearLi.setAttribute("class", "next");
		nextYearLi.appendChild(nextYearLink);
		yearUl.appendChild(nextYearLi);

		var monthUl = document.createElement("ul");
		container.appendChild(monthUl);

		var monthNames = dateFormatter.Symbols.MonthNames;

		var prevMonthLink = document.createElement("span");
		prevMonthLink.innerHTML = (monthIndex == 0 ? monthNames[11] : monthNames[monthIndex - 1]);

		var prevMonthLi = document.createElement("li");
		prevMonthLi.setAttribute("class", "prev");
		prevMonthLi.appendChild(prevMonthLink);
		monthUl.appendChild(prevMonthLi);

		var currMonthLi = document.createElement("li");
		currMonthLi.setAttribute("class", "current");
		currMonthLi.innerHTML = monthNames[monthIndex];
		monthUl.appendChild(currMonthLi);

		var nextMonthLink = document.createElement("span");
		nextMonthLink.innerHTML = (monthIndex == 11 ? monthNames[0] : monthNames[monthIndex + 1]);

		var nextMonthLi = document.createElement("li");
		nextMonthLi.setAttribute("class", "next");
		nextMonthLi.appendChild(nextMonthLink);
		monthUl.appendChild(nextMonthLi);

		prevYearLink.addEventListener("click", function() {
			displayCalendar(new Date(year - 1, monthIndex, 1), mode, periodDom, container, currDateTextValue, callback);  // .format("yyyy-MM-dd")
		}, false);

		nextYearLink.addEventListener("click", function() {
			displayCalendar(new Date(year + 1, monthIndex, 1), mode, periodDom, container, currDateTextValue, callback);  // .format("yyyy-MM-dd")
		}, false);

		prevMonthLink.addEventListener("click", function() {
			displayCalendar(new Date(year, monthIndex - 1, 1), mode, periodDom, container, currDateTextValue, callback);  // .format("yyyy-MM-dd")
		}, false);

		nextMonthLink.addEventListener("click", function() {
			displayCalendar(new Date(year, monthIndex + 1, 1), mode, periodDom, container, currDateTextValue, callback);  // .format("yyyy-MM-dd")
		}, false);

		var table = document.createElement("table");
		table.setAttribute("class", mode);
		container.appendChild(table);

		var weekIndex    = 0;
		var cellRevision = 0;
		var row = table.insertRow(0);

		var separatedCurrDates = currDateTextValue.split("-");
		var currYear           = parseInt(separatedCurrDates[0], 10);
		var currMonth          = parseInt(separatedCurrDates[1], 10);
		var currDay            = parseInt(separatedCurrDates[2], 10);
		var currWeek           = 0;
		var currDateValue      = dateFormatter.format(dateUtil.parse(currDateTextValue), dateFormatter.DateStyle.LONG);

		if (mode == "week") {
			currDateValue = dateFormatter.format(dateUtil.parse(currDateTextValue), "yyyy-'W'ww");

			cellRevision = 1;
			row.insertCell(0);

			weekIndex = dateFormatter.format(new Date(year, monthIndex, 1), "w");
			currWeek  = parseInt(currDateValue.substring(currDateValue.indexOf("-") + 2), 10);
		}

		for (var i = 0; i < 7; i++) {
			var cell = row.insertCell(i + cellRevision);
			cell.setAttribute("class", "w" + i);
			cell.innerHTML = dateFormatter.Symbols.WeekdayNames[i];
		}

		for (var i = 0; i < arr2Day.length; i++) {
			var row = table.insertRow(i + 1);

			if (mode == "week") {
				var week = (monthIndex == 11 && arr2Day[i][0] > 25) ? 1 : weekIndex++;

				row.setAttribute("class", "week");

				if (monthIndex == 11 && week == 1)  setDate(row, (year + 1) + "-W" + pad(week), periodDom, monthIndex);
				else                                setDate(row, year + "-W" + pad(week), periodDom, monthIndex);

				var cell = row.insertCell(0);
				cell.innerHTML = week;

				if (currWeek == week || (currWeek == 53 && week == 1)) {
					if (currWeek == 53 && week == 1 && i == 0 && currYear + 1 == year) {
						row.setAttribute("class", "week selected");
					} else if ((currWeek == week || (currWeek == 53 && week == 1 && i > 0)) && currYear == year) {
						row.setAttribute("class", "week selected");
					} else if (currWeek == 1 && week == 1 && i > 0 && currYear == year + 1) {
						row.setAttribute("class", "week selected");
					}

					cell.setAttribute("class", "current");
				}
			}

			for (var j = 0; j < 7; j++) {
				var cell         = row.insertCell(j + cellRevision);
				var monthDay     = arr2Day[i][j];
				var monthDayHtml = monthDay;
				var className    = "w" + j;

				if (monthDay < 0) {
					monthDayHtml = (monthDay * -1);
					className    = "w9";
				} else {
					if (mode == "date") {
						className += " date";

						setDate(cell, year + "-" + pad(monthIndex + 1) + "-" + pad(monthDay), periodDom);

						if (currDay == monthDay) {
							className += " current";

							if (currYear == year && currMonth == monthIndex + 1) {
								className += " selected";
							}
						}
					}
				}

				cell.setAttribute("class", className);
				cell.innerHTML = monthDayHtml;
			}
		}

		var currDateDiv = document.createElement("div");
		currDateDiv.appendChild(document.createTextNode(currDateValue));

		currDateDiv.addEventListener("click", function() {
			displayCalendar(currDateTextValue, mode, periodDom, container, currDateTextValue, callback);
		}, false);

		container.appendChild(currDateDiv);
	}
}

function displaySimpleCalendar(date, container, selected) {
	function pad(val, len) {
		val = String(val);
		len = len || 2;
		while (val.length < len) {
			val = "0" + val;
		}
		return val;
	}

	var today = dateUtil.format(new Date());
	var yearMonthPattern = getMonthLocalePatterns(dateFormatter.DateStyle.MEDIUM).yearMonth;
	var calendarDate = null;

	if (Object.prototype.toString.call(date) == "[object Date]") {
		calendarDate = date;
	} else {
		calendarDate = dateUtil.parse(date);
	}

	var year       = calendarDate.getFullYear();
	var monthIndex = calendarDate.getMonth();
	var arr2Day    = dateUtil.getCalendarMatrix(year, monthIndex);
	var weekIndex  = dateFormatter.format(new Date(year, monthIndex, 1), "w");
	var currWeek   = dateFormatter.format(date, "w");

	container.innerHTML = "";

	var yearMonthDiv = document.createElement("div");
	yearMonthDiv.innerHTML = dateFormatter.format(calendarDate, yearMonthPattern);
	container.appendChild(yearMonthDiv);

	var table = document.createElement("table");
	table.setAttribute("class", "date");
	container.appendChild(table);

	var cellIndex = 0;
	var weekIndex = 0;
	var row = table.insertRow(0);

	if (selected) {
		cellIndex = 1;
		var weekCell = row.insertCell(0);
		weekIndex = dateFormatter.format(new Date(year, monthIndex, 1), "w");
	}

	for (var i = 0; i < 7; i++) {
		var cell = row.insertCell(cellIndex + i);
		cell.setAttribute("class", "w" + i);
		cell.innerHTML = dateFormatter.Symbols.WeekdayNames[i];
	}

	for (var i = 0; i < arr2Day.length; i++) {
		var row = table.insertRow(i + 1);
		row.setAttribute("class", "week");

		if (selected) {
			var week = (monthIndex == 11 && arr2Day[i][0] > 25) ? 1 : weekIndex++;

			if ((currWeek == week) || (currWeek == 53 && week == 1)) {
				row.setAttribute("class", "week selected");
			}

			var weekCell = row.insertCell(0);
			weekCell.innerHTML = week;
		}

		for (var j = 0; j < 7; j++) {
			var cell         = row.insertCell(cellIndex + j);
			var monthDay     = arr2Day[i][j];
			var monthDayHtml = monthDay;
			var className    = "w" + j;

			if (monthDay < 0) {
				monthDayHtml = (monthDay * -1);
				className    = "w9";
			}

			if (today == year + "-" + pad(monthIndex + 1) + "-" + pad(monthDayHtml)) {
				className = className + " today";
			}

			cell.setAttribute("class", className);
			cell.innerHTML = monthDayHtml;
		}
	}
}

function getProgressStatus(progress, startdate, enddate, today) {
	if (today == null)  today = dateFormatter.format(new Date(), "yyyy-MM-dd");

	if (Object.prototype.toString.call(progress) == "[object Boolean]") {
		if (progress)                progress = 100;
		else if (today < startdate)  progress = 0;
		else                         progress = 50;
	}

	if (progress == 100) {
		return "completed";
	} else if (progress == 0) {
		if (today > enddate)  return "delayed0";
		else                  return "ready";
	} else {
		if (today > enddate)  return "delayed";
		else                  return "ongoing";
	}
}

function isOutboundProgress(projectStartdate, projectEnddate, startdate, enddate) {
	if      (projectStartdate > startdate)  return true;
	else if (projectEnddate < enddate)      return true;
	else                                    return false;
}

var refreshTimeoutId = null;
var alertOvertime    = "Upgrade processing has been forcefully terminated due to processing timeout.";

function getDiffPeriod(oldDate, newDate, dayoff) {
	var diffPeriod = (newDate.getTime() - oldDate.getTime()) / 86400000;
	var oldWeek    = oldDate.getDay();
	var newWeek    = newDate.getDay();

	if ((diffPeriod == 0) || (Math.abs(diffPeriod) % 7 == 0)) {
		return diffPeriod;
	} else if (diffPeriod < 0) {
		if (oldWeek == 0) {
			if (dayoff == 2) {
				diffPeriod += 2;
				oldWeek = 5;
			} else {
				diffPeriod += 1;
				oldWeek = 6;
			}
		} else if ((oldWeek == 6) && (dayoff == 2)) {
			diffPeriod += 1;
			oldWeek = 5;
		}

		if (newWeek == 0) {
			diffPeriod += 1;
			newWeek = 1;
		} else if ((newWeek == 6) && (dayoff == 2)) {
			diffPeriod += 2;
			newWeek = 1;
		}

		if (newWeek > oldWeek) {
			diffPeriod += dayoff;
		}
	} else {
		if (oldWeek == 0) {
			diffPeriod -= 1;
			oldWeek = 1;
		} else if ((oldWeek == 6) && (dayoff == 2)) {
			diffPeriod -= 2;
			oldWeek = 1;
		}

		if (newWeek == 0) {
			if (dayoff == 2) {
				diffPeriod -= 2;
				newWeek = 5;
			} else {
				diffPeriod -= 1;
				newWeek = 6;
			}
		} else if ((newWeek == 6) && (dayoff == 2)) {
			diffPeriod -= 1;
			newWeek = 5;
		}

		if (newWeek < oldWeek) {
			diffPeriod -= dayoff;
		}
	}

	return diffPeriod;
}