$content$.winup.setting.upgrade = {
	service: function() {
		document.querySelector("aside.winup article > div.winup > form > ul > li:last-child > button").addEventListener("click", function(event) {
			var formData = new FormData(document.upgradeForm);

			if (formData.get("puz").name.search(/\.puz$/i) < 0) {
				this.parentNode.previousElementSibling.innerHTML = i18n.alert_select_puz_file;
			} else {
				$controller$.loading.show();

				$jnode$.ajax.service({
					"url":      "/ajax/upgrade.json",
					"method":   "POST",
					"datatype": "json",
					"headers":  {
						"Accept": "application/json"
					},
					"params":  formData,
					"success": function(response) {
						handleHash("#article:/setting/about");
						$controller$.winup.close();
					},
					"error": function(error) {
						$jnode$.ajax.alertError(error);
						$controller$.loading.hide();
					}
				});
			}
		}, false);
	}
};