$content$.winup.project.upload = {
	service: function() {
		document.querySelector("aside.winup article > div.winup > form > ul > li:last-child > button").addEventListener("click", function(event) {
			var formData = new FormData(document.uploadForm);

			if (formData.get("pdz").name.search(/\.pdz$/i) < 0) {
				this.parentNode.previousElementSibling.innerHTML = i18n.alert_select_pdz_file;
			} else {
				$controller$.loading.show();

				$jnode$.ajax.service({
					"url":      "/project/upload.json",
					"method":   "POST",
					"datatype": "json",
					"headers":  {
						"Accept": "application/json"
					},
					"params":  formData,
					"success": function(response) {
						$controller$.winup.close();

						$jnode$.requireContent("popup", "/project/import", {
							unload:      true,
							heightP:     100,
							import_data: response
						});
					},
					"error": function(error) {
						$jnode$.ajax.alertError(error);
						$controller$.loading.hide();
					}
				});
			}
		}, false);

		/*
		var copyButton = document.querySelector("aside.winup article > div.winup > form > ul > li:last-child > button");

		copyButton.addEventListener("click", function(event) {
			var copiedText = document.querySelector("aside.winup article > div.winup > form + input").value;
			localStorage.setItem("appclipboard", copiedText);
		}, false);

		copyButton.nextElementSibling.addEventListener("click", function(event) {
			document.querySelector("aside.winup article > div.winup > form + input").value = localStorage.getItem("appclipboard");
		}, false);
		*/
	}
};