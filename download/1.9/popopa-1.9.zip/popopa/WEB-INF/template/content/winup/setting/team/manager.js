$content$.winup.setting.team.manager = {
	resize: function() {
		var windowWidth  = window.innerWidth;
		var windowHeight = window.innerHeight;
		var controllerHeight = 268;

		if (windowWidth < 737) {
			if (windowHeight < 388) {
				controllerHeight = windowHeight * 0.8 - 42;
			}
		}

		if ($content$.winup.setting.team.manager.dataset.use_org) {
			$controller$.tree.resize(null, controllerHeight);
		} else {
			$controller$["grid#user"].resize(null, controllerHeight);
		}
	},

	service: function() {
		var that           = this;
		var worker         = this.dataset.worker;
		var managerList    = this.dataset.managerList;
		var disabedManager = {};

		disabedManager[worker] = true;

		for (var i = 0; i < managerList.length; i++) {
			disabedManager[managerList[i].manager_id] = true;
		}

		var okButton = document.querySelector("aside.winup article > div.winup > ul.submit > li:last-child > button");
		okButton.parentNode.style.width = okButton.offsetWidth + "px";

		okButton.disabled = true;

		var managerNameDiv = document.querySelector("aside.winup article > div.winup > ul.submit > li:first-child");
		var managerInfo    = null;

		if (this.dataset.use_org) {
			$jnode$.node.addClass(document.querySelector("aside.winup article > div.winup"), (isMobile ? "mobile" : "desktop"));

			$jnode$.requireController("tree", {caller:that.conf}).on(function() {
				function setTreeText(entrySet) {
					var textDiv = document.createElement("div");
					textDiv.setAttribute("class", entrySet.type);

					var textSpan = document.createElement("span");
					textSpan.appendChild(document.createTextNode(entrySet.name));
					textDiv.appendChild(textSpan);

					if (entrySet.type == "user") {
						if (disabedManager[entrySet.id])  textDiv.setAttribute("class", "user disabled");

						textDiv.appendChild(document.createTextNode(" ("));

						userIdSpan = document.createElement("span");
						userIdSpan.appendChild(document.createTextNode(entrySet.id));
						textDiv.appendChild(userIdSpan);

						textDiv.appendChild(document.createTextNode(" / "));

						positionNameSpan = document.createElement("span");
						positionNameSpan.appendChild(document.createTextNode(entrySet.position_name));
						textDiv.appendChild(positionNameSpan);
						textDiv.appendChild(document.createTextNode(")"));
					} else {
						textDiv.appendChild(document.createTextNode(" "));

						var orgSpan = document.createElement("span");
						orgSpan.setAttribute("class", "count");
						orgSpan.appendChild(document.createTextNode("(" + entrySet.org_count + ", " + entrySet.user_count + ")"));
						textDiv.appendChild(orgSpan);
					}

					return textDiv;
				}

				function setTreeList(entrySet) {
					if (entrySet.org_count + entrySet.user_count == 0)  return null;
					else                                                return [];
				}

				function addTreeClickListener(textNode, entrySet) {
					if (textNode.firstElementChild.getAttribute("class") == "user") {
						var selectedUser = document.querySelector("aside.winup article > div.winup > aside.tree.org ul > li:last-child > span.checked");
						if (selectedUser)  selectedUser.removeAttribute("class");

						textNode.setAttribute("class", "checked");

						managerNameDiv.innerHTML = $jnode$.escapeXML(entrySet.name) + " (" + entrySet.id + " / " + entrySet.position_name + ") @ " + entrySet.org_name;
						managerInfo = {
							manager_id:    entrySet.id,
							manager_name:  entrySet.name,
							position_id:   entrySet.position_id,
							position_name: entrySet.position_name,
							org_id:        entrySet.org_id,
							org_name:      entrySet.org_name
						};

						okButton.disabled = false;
					} else {
						$controller$.tree.toggle(entrySet.id);
					}
				}

				$controller$.tree.service({
					height: 268,
					datas:  that.dataset.orgDatas,
					text:   setTreeText,
					list:   setTreeList,
					click:  addTreeClickListener,
					retrieve: {
						url: "/ajax/org.json",
						method: "POST",
						params: {
							command: "getOrgUserList"
						},
						loading: {
							show: $controller$.loading.show,
							hide: $controller$.loading.hide
						}
					},
				});

				window.addEventListener("resize", that.resize, false);
				that.resize();
			});
		} else {
			$jnode$.requireController("grid#user", {caller:that.conf}).on(function() {
				$controller$["grid#user"].service({height:268, sortable:true});

				var userTbody = document.querySelector("aside.winup article > div.winup > aside.grid > div > table > tbody");

				function addClickHandler(row, userData) {
					row.addEventListener("click", function(event) {
						if (this.getAttribute("class") != "disabled") {
							var selectedRow = document.querySelector("aside.winup article > div.winup > aside.grid > div > table > tbody > tr.selected");
							if (selectedRow)  selectedRow.removeAttribute("class");

							this.setAttribute("class", "selected");
							managerNameDiv.innerHTML = $jnode$.escapeXML(userData.user_name) + " (" + userData.user_id + " / " + userData.position_name + ")";
							managerInfo = {
								manager_id:    userData.user_id,
								manager_name:  userData.user_name,
								position_id:   userData.position_id,
								position_name: userData.position_name
							};

							okButton.disabled = false;
						}
					}, false);
				}

				for (var i = 0; i < that.dataset.userList.length; i++) {
					var userData = that.dataset.userList[i];
					var row = document.createElement("tr");
					row.setAttribute("id", userData.user_id);
					userTbody.appendChild(row);

					if (disabedManager[userData.user_id])  row.setAttribute("class", "disabled");

					var nameCell = row.insertCell(0);
					nameCell.appendChild(document.createTextNode(userData.user_name));

					var idCell = row.insertCell(1);
					idCell.appendChild(document.createTextNode(userData.user_id));

					var positionCell = row.insertCell(2);
					positionCell.appendChild(document.createTextNode(userData.position_name));
					positionCell.setAttribute("id", userData.position_id);
					positionCell.setAttribute("sid", $content$.article.setting.team.posSortMap[userData.position_id.toString()]);

					addClickHandler(row, userData);
				}

				window.addEventListener("resize", that.resize, false);
				that.resize();
			});
		}

		okButton.addEventListener("click", function(event) {
			$controller$.loading.show();

			$jnode$.ajax.service({
				"url":      "/ajax/team.json",
				"method":   "POST",
				"datatype": "json",
				"headers": {
					"Content-Type": "application/json",
					"Accept":       "application/json"
				},
				"params":  {
					command:       "reserveMember",
					team_manager:  managerInfo.manager_id,
					team_engineer: worker,
					member_status: "reserved"
				},
				"success": function(response) {
					managerInfo.team_createdate = response.team_createdate;
					managerInfo.member_status = "reserved";

					$content$.article.setting.team.appendMyManager(managerInfo);
					$controller$.winup.close();
					$controller$.loading.hide();
				},
				"error": function(error) {
					$jnode$.ajax.alertError(error);
					$controller$.loading.hide();
				}
			});
		}, false);
	},

	unload: function() {
		window.removeEventListener("resize", this.resize, false);
	}
};