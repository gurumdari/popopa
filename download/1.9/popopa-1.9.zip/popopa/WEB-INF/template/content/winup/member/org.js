$content$.winup.member.org = {
	resize: function() {
		var windowWidth  = window.innerWidth;
		var windowHeight = window.innerHeight;
		var selectorHeight = 278;

		if (windowWidth < 737) {
			if (windowHeight < 452) {
				selectorHeight = windowHeight * 0.8 - 104;
			} else {
				selectorHeight = 278;
			}

			var bodyWidth     = document.body.offsetWidth;
			var selectorWidth = 458;

			if (bodyWidth < 520) {
				selectorWidth = bodyWidth - 62;
			}
			$controller$["tree#source"].resize(selectorWidth, selectorHeight);
		} else {
			selectorHeight = 278;
			$controller$["tree#source"].resize(320, selectorHeight);
		}

		document.querySelector("aside.winup article > div.winup > ul:nth-child(2) > li:last-child > div#target").style.height = selectorHeight + "px";
	},

	service: function() {
		var that = this;

		var sourceUserAside = document.querySelector("aside.winup article > div.winup > ul:nth-child(2) > li:first-child > aside.tree.org");
		var targetUserUl    = document.querySelector("aside.winup article > div.winup > ul:nth-child(2) > li:last-child > div#target > ul");
		var addButton1      = document.querySelector("aside.winup article > div.winup > ul:nth-child(2) > li:nth-child(2) > button:first-child");
		var removeButton1   = document.querySelector("aside.winup article > div.winup > ul:nth-child(2) > li:nth-child(2) > button:last-child");
		var addButton2      = document.querySelector("aside.winup article > div.winup > ul:last-child > li > button:first-child");
		var removeButton2   = document.querySelector("aside.winup article > div.winup > ul:last-child > li > button:nth-child(2)");
		var okButton        = document.querySelector("aside.winup article > div.winup > ul:last-child > li > button:last-child");

		addButton1.disabled    = true;
		addButton2.disabled    = true;
		removeButton1.disabled = true;
		removeButton2.disabled = true;

		var memberEvent = $jnode$.storage.eventhandler4member;

		if ($jnode$.storage.eventhandler4import) {
			memberEvent = $jnode$.storage.eventhandler4import;
		}

		function appendUserList(userData, disabled) {
			var userId = userData.user_id;
			var isRetiree = (userId.search(/^[$][{].+[}]$/) == 0);
			var targetUserLi = document.createElement("li");
			targetUserLi.setAttribute("id", userId);
			targetUserLi.innerHTML = (isRetiree ? i18n.label_retiree + ": " : "") + "<SPAN>" + $jnode$.escapeXML(userData.user_name) + "</SPAN> (<SPAN>" + $jnode$.escapeXML(isRetiree ? userId.substring(13, userId.length - 1) : userId) + "</SPAN> / <SPAN>" + $jnode$.escapeXML(userData.position_name) + "</SPAN><FONT>" + userData.position_id + "</FONT>)" + " @ <SPAN>" + $jnode$.escapeXML(userData.org_name) + "</SPAN><FONT>" + userData.org_id + "</FONT>";
			targetUserUl.appendChild(targetUserLi);

			if (disabled) {
				targetUserLi.setAttribute("class", "disabled");
			} else {
				targetUserLi.addEventListener("click", function(event) {
					if ($jnode$.node.hasClass(this, "checked")) {
						$jnode$.node.removeClass(this, "checked");

						if (targetUserUl.querySelectorAll("ul > li.checked").length == 0) {
							removeButton1.disabled = true;
							removeButton2.disabled = true;
						}
					} else {
						$jnode$.node.addClass(this, "checked");

						removeButton1.disabled = false;
						removeButton2.disabled = false;
					}
				}, false);
			}

			if (isRetiree) {
				$jnode$.node.addClass(targetUserLi, "retiree");
			}
		}

		$jnode$.requireController("tree#source", {caller:that.conf}).on(function() {
			function setTreeText(entrySet) {
				var textDiv = document.createElement("div");
				textDiv.setAttribute("class", entrySet.type);

				var textSpan = document.createElement("span");
				textSpan.appendChild(document.createTextNode(entrySet.name));
				textDiv.appendChild(textSpan);

				if (entrySet.type == "user") {
					textDiv.appendChild(document.createTextNode(" ("));

					userIdSpan = document.createElement("span");
					userIdSpan.appendChild(document.createTextNode(entrySet.id));
					textDiv.appendChild(userIdSpan);

					textDiv.appendChild(document.createTextNode(" / "));

					positionNameSpan = document.createElement("span");
					positionNameSpan.appendChild(document.createTextNode(entrySet.position_name));
					textDiv.appendChild(positionNameSpan);

					positionIdFont = document.createElement("font");
					positionIdFont.appendChild(document.createTextNode(entrySet.position_id));
					textDiv.appendChild(positionIdFont);

					textDiv.appendChild(document.createTextNode(")"));

					orgNameFont = document.createElement("font");
					orgNameFont.appendChild(document.createTextNode(entrySet.org_name));
					textDiv.appendChild(orgNameFont);

					orgIdFont = document.createElement("font");
					orgIdFont.appendChild(document.createTextNode(entrySet.org_id));
					textDiv.appendChild(orgIdFont);
				} else {
					textDiv.appendChild(document.createTextNode(" "));

					var orgSpan = document.createElement("span");
					orgSpan.setAttribute("class", "count");
					orgSpan.appendChild(document.createTextNode("(" + entrySet.org_count + ", " + entrySet.user_count + ")"));
					textDiv.appendChild(orgSpan);
				}

				return textDiv;
			}

			function setTreeList(entrySet) {
				if (entrySet.org_count + entrySet.user_count == 0)  return null;
				else                                                return [];
			}

			function addTreeClickListener(textNode, entrySet) {
				if (entrySet.type == "user") {
					if (textNode.getAttribute("class") == "checked") {
						textNode.removeAttribute("class");

						if (sourceUserAside.querySelectorAll("aside ul > li:last-child > span.checked").length == 0) {
							addButton1.disabled = true;
							addButton2.disabled = true;
						}
					} else {
						textNode.setAttribute("class", "checked");

						addButton1.disabled = false;
						addButton2.disabled = false;
					}
				} else {
					$controller$["tree#source"].toggle(entrySet.id);
				}
			}

			$controller$["tree#source"].service({
				datas: that.dataset.orgDatas,
				text:  setTreeText,
				list:  setTreeList,
				click: addTreeClickListener,
				retrieve: {
					url: "/ajax/org.json",
					method: "POST",
					params: {
						command: "getOrgUserList"
					},
					loading: {
						show: $controller$.loading.show,
						hide: $controller$.loading.hide
					}
				},
			});

			function appendTargetUserList(targetUserList) {
				var addedUserIds = [];
				var addedUserLis = targetUserUl.querySelectorAll("ul > li");

				for (var i = 0; i < addedUserLis.length; i++) {
					addedUserIds.push(addedUserLis[i].getAttribute("id"));
				}

				for (var i = 0; i < targetUserList.length; i++) {
					if (addedUserIds.indexOf(targetUserList[i].user_id) < 0) {
						appendUserList(targetUserList[i]);
					}
				}
			}

			function addButtonHandler(event) {
				var addedUserList = [];
				var selectedUsers = sourceUserAside.querySelectorAll("aside ul > li:last-child > span.checked > div");

				for (var i = 0; i < selectedUsers.length; i++) {
					addedUserList.push({
						user_name:     selectedUsers[i].querySelector("div > span:first-of-type").firstChild.nodeValue,
						user_id:       selectedUsers[i].querySelector("div > span:nth-of-type(2)").firstChild.nodeValue,
						position_name: selectedUsers[i].querySelector("div > span:nth-of-type(3)").firstChild.nodeValue,
						position_id:   selectedUsers[i].querySelector("div > font:first-of-type").firstChild.nodeValue,
						org_name:      selectedUsers[i].querySelector("div > font:nth-of-type(2)").firstChild.nodeValue,
						org_id:        selectedUsers[i].querySelector("div > font:last-of-type").firstChild.nodeValue
					});

					selectedUsers[i].parentNode.removeAttribute("class");
				}

				addButton1.disabled = true;
				addButton2.disabled = true;
				appendTargetUserList(addedUserList);
			}

			addButton1.addEventListener("click", addButtonHandler, false);
			addButton2.addEventListener("click", addButtonHandler, false);

			function removeButtonHandler(event) {
				var selectedUserLi  = targetUserUl.querySelectorAll("ul > li.checked");

				for (var i = selectedUserLi.length - 1; i >= 0; i--) {
					targetUserUl.removeChild(selectedUserLi[i]);
				}

				removeButton1.disabled = true;
				removeButton2.disabled = true;
			}

			removeButton1.addEventListener("click", removeButtonHandler, false);
			removeButton2.addEventListener("click", removeButtonHandler, false);

			okButton.addEventListener("click", function(event) {
				var targetUserList = [];
				var targetUserLi   = targetUserUl.querySelectorAll("ul > li");

				for (var i = 0; i < targetUserLi.length; i++) {
					targetUserList.push({
						user_id:       targetUserLi[i].getAttribute("id"),
						user_name:     targetUserLi[i].querySelector("li > span:first-of-type").firstChild.nodeValue,
						position_name: targetUserLi[i].querySelector("li > span:nth-of-type(3)").firstChild.nodeValue,
						position_id:   targetUserLi[i].querySelector("li > font:first-of-type").firstChild.nodeValue,
						org_name:      targetUserLi[i].querySelector("li > span:last-of-type").firstChild.nodeValue,
						org_id:        targetUserLi[i].querySelector("li > font:last-of-type").firstChild.nodeValue
					});
				}

				memberEvent.ok(targetUserList, $controller$.winup.close);
			}, false);

			var tabInputs = document.querySelectorAll("aside.winup article > div.winup > ul:first-child > li > label > input");

			for (var i = 0; i < tabInputs.length; i++) {
				tabInputs[i].addEventListener("click", function(event) {
					var sourceTab = document.querySelector("aside.winup article > div.winup > ul:nth-child(2) > li:first-child");
					var targetTab = document.querySelector("aside.winup article > div.winup > ul:nth-child(2) > li:last-child");

					if (this.value == "source") {
						$jnode$.node.removeClass(sourceTab, "hidden");
						$jnode$.node.addClass(targetTab, "hidden");

						addButton2.removeAttribute("class");
						removeButton2.setAttribute("class", "hidden");
					} else {
						$jnode$.node.addClass(sourceTab, "hidden");
						$jnode$.node.removeClass(targetTab, "hidden");

						addButton2.setAttribute("class", "hidden");
						removeButton2.removeAttribute("class");
					}

					that.resize();
				}, false);
			}

			tabInputs[0].click();

			var targetUserList = memberEvent.open();
			var workerInfo     = that.dataset.workerInfo;
			var disabledUserId = null;

			if (memberEvent.disableWorker) {
				appendUserList(workerInfo, true);
				disabledUserId = workerInfo.user_id;
			}

			for (var i = 0; i < targetUserList.length; i++) {
				if (targetUserList[i].user_id != disabledUserId) {
					appendUserList(targetUserList[i]);
				}
			}

			window.addEventListener("resize", that.resize, false);
		});

		// 프로젝트 대상 멤버들간의 정렬 이벤트
		if (memberEvent.disableWorker == null || memberEvent.disableWorker == false) {
			$jnode$.requireModule("tap", that.conf).on(function() {
				shiftableEventHandler = new $jnode$.module.tap.ShiftableEventHandler(targetUserUl, "ul > li", null, null,
				{
					/* style: "background-color: #FFA666;",*/
					scrollableNode: targetUserUl.parentNode
				});

				shiftableEventHandler.addShiftableEvent();
			});
		}
	},

	unload: function() {
		window.removeEventListener("resize", this.resize, false);
	}
};