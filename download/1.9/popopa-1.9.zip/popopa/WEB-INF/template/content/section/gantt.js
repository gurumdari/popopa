$content$.section.gantt = {
	itemScrollbarWidth: -1,
	progressScrollbarWidth: 17,
	progressScrollbarHeight: 17,
	progressDayList: [],
	progressStartDate: null,
	userMap: {},

	resizeProjectPeriod: function() {
		var projectProgressbarContainer        = document.querySelector("body > header > ul > li:nth-child(2) > div");
		var projectProgressbarCurrentContainer = projectProgressbarContainer.firstElementChild;
		var containerWidth = projectProgressbarContainer.clientWidth;
		var currentWidth   = projectProgressbarCurrentContainer.clientWidth;

		if (currentWidth < 81) {
			projectProgressbarCurrentContainer.setAttribute("class", "display right");
		} else if ((containerWidth - currentWidth) < 81) {
			projectProgressbarCurrentContainer.setAttribute("class", "display left");
		} else {
			projectProgressbarCurrentContainer.removeAttribute("class");
		}
	},

	resizeGantt: function() {
		var ganttLayoutUl     = document.querySelector("body > section > div.section > ul#gantt");
		var progressScrollDiv = ganttLayoutUl.querySelector("ul#gantt > li:last-child > ul > li:last-child > div");
		var ganttDateDiv      = ganttLayoutUl.querySelector("ul#gantt > li:last-child > ul > li:first-child > ul > li:first-child > div");
		var itemTaskDiv       = ganttLayoutUl.querySelector("ul#gantt > li:first-child > ul > li:last-child > div > div");
		var windowWidth       = window.innerWidth;
		var windowHeight      = window.innerHeight;

		if (windowWidth > 736) {
			progressScrollDiv.scrollTop = itemTaskDiv.scrollTop;

			function setScrollbarWidth() {
				var itemTaskClientWidth = itemTaskDiv.clientWidth;

				if (itemTaskClientWidth == 0) {
					// IE는 Rendering 중에는 clientWidth를 제대로 가져오지 못하는 현상이 발생하므로 보정
					$content$.section.gantt.progressScrollbarWidth  = 17;
					$content$.section.gantt.progressScrollbarHeight = 17;

					// IE9는 -ms-overflow-style이 안 먹어 스크롤이 생김.
					if (navigator.userAgent.indexOf(" MSIE 9.") < 0) {
						$content$.section.gantt.itemScrollbarWidth = 0;
					} else {
						$content$.section.gantt.itemScrollbarWidth = 17;
					}
				} else {
					$content$.section.gantt.itemScrollbarWidth      = itemTaskDiv.offsetWidth - itemTaskClientWidth;
					$content$.section.gantt.progressScrollbarWidth  = progressScrollDiv.offsetWidth  - progressScrollDiv.clientWidth;
					$content$.section.gantt.progressScrollbarHeight = progressScrollDiv.offsetHeight - progressScrollDiv.clientHeight;
				}
			}

			if ($content$.section.gantt.itemScrollbarWidth == -1) {
				setScrollbarWidth();
			}

			// for FireFox and IE9 Only: for hiding scrollbar.
			if ($content$.section.gantt.itemScrollbarWidth > 0) {
				itemTaskDiv.style.width = (600 + $content$.section.gantt.itemScrollbarWidth) + "px";
			}

			ganttLayoutUl.style.height     = (windowHeight - 43) + "px";
			progressScrollDiv.style.width  = (windowWidth - 620 + $content$.section.gantt.progressScrollbarWidth) + "px";
			progressScrollDiv.style.height = (windowHeight - 114 + $content$.section.gantt.progressScrollbarHeight) + "px";
			ganttDateDiv.style.width       = (windowWidth - 620) + "px";
			progressScrollDiv.parentNode.style.height = (windowHeight - 97) + "px";

			// IE의 경우 itemTaskDiv 하단에 3px 정도 빈 공간이 생김.
			if (navigator.userAgent.indexOf("Trident") < 0) {
				itemTaskDiv.style.height = (windowHeight - 114) + "px";
			} else {
				itemTaskDiv.style.height = (windowHeight - 111) + "px";
			}
		} else {
			ganttLayoutUl.removeAttribute("style");
			itemTaskDiv.removeAttribute("style");
		}
	},

	drawPeriodHeader: function(startdate, enddate, currentdate, insertBefore) {
		var monthDisplayRow       = document.querySelector("body > section > div.section > ul#gantt > li:last-child > ul > li:first-child > ul > li:first-child > div > table > thead > tr:first-child");
		var dayDisplayRow         = monthDisplayRow.nextElementSibling;
		var monthLocalePatterns   = getMonthLocalePatterns(dateFormatter.DateStyle.MEDIUM);
		var monthDisplayCellCount = monthDisplayRow.querySelectorAll("tr > td").length;
		var dayDisplayCellCount   = dayDisplayRow.querySelectorAll("tr > td").length;

		var displayStartDate  = dateUtil.parse(startdate);
		var displayEndDate    = dateUtil.parse(enddate);
		var displayYear       = displayStartDate.getFullYear();
		var displayMonth      = displayStartDate.getMonth();
		var displayDay        = displayStartDate.getDate();
		var monthIntervals    = (displayEndDate.getFullYear() - displayYear) * 12 + displayEndDate.getMonth() - displayMonth + 1;
		var dateIntervals     = (displayEndDate.getTime() - displayStartDate.getTime()) / 86400000 + 1;
		var displayWeekday    = "w0";
		var lastDay           = 0;
		var displayMonthIndex = 0;
		var displayMonthList  = [];
		var displayDayList    = [];
		var dayId             = "";

		var monthDisplayFirstCell = monthDisplayRow.firstElementChild;
		var dayDisplayFirstCell   = dayDisplayRow.firstElementChild;

		function pad(val, len) {
			val = String(val);
			len = len || 2;
			while (val.length < len) {
				val = "0" + val;
			}
			return val;
		}

		for (var i = 0; i < dateIntervals; i++) {
			if (i == 0 || displayDay == 2) {
				lastDay = dateUtil.getLastMonthDate(displayYear, displayMonth);
			}

			if (displayDay > lastDay) {
				displayMonth++;
				displayDay = 1;

				displayMonthList.push({
					id:    (displayYear + "-" + pad(displayMonth)),
					index: displayMonthIndex
				});

				displayMonthIndex = 0;
			}

			displayMonthIndex++;

			if (displayMonth == 12) {
				displayYear++;
				displayMonth = 0;
			}

			displayWeekday = "w" + (i % 7);

			dayId = displayYear + "-" + pad(displayMonth + 1) + "-" + pad(displayDay);

			var dayDisplayCell = null;

			if (insertBefore) {
				dayDisplayCell = document.createElement("td");
				dayDisplayRow.insertBefore(dayDisplayCell, dayDisplayFirstCell);
			} else {
				var dayDisplayCell = dayDisplayRow.insertCell(dayDisplayCellCount + i);
			}

			dayDisplayCell.setAttribute("id"   , dayId);
			dayDisplayCell.setAttribute("class", displayWeekday);
			dayDisplayCell.appendChild(document.createTextNode(displayDay));

			if (currentdate == dayId)  $jnode$.node.addClass(dayDisplayCell, "today");

			displayDayList.push({
				date: dayId,
				week: (displayWeekday + (currentdate == dayId ? " today" : ""))
			});

			displayDay++;
		}

		if (monthIntervals > displayMonthList.length) {
			displayMonthList.push({
				id:    (displayYear + "-" + pad(displayMonth + 1)),
				index: displayMonthIndex
			});
		}

		if (insertBefore) {
			var mergedCount   = 0;

			if (monthDisplayCellCount > 0 && monthIntervals > 0) {
				if (monthDisplayFirstCell.getAttribute("id") == displayMonthList[monthIntervals - 1].id) {
					mergedCount = monthDisplayFirstCell.colSpan + displayMonthList[monthIntervals - 1].index;
				}
			}

			for (var i = 0; i < monthIntervals; i++) {
				var monthLocalePattern = monthLocalePatterns.yearMonth;

				if (i == monthIntervals - 1 && mergedCount > 0) {
					monthDisplayFirstCell.colSpan = mergedCount;

					if (mergedCount == 2)  monthLocalePattern = monthLocalePatterns.cell2;

					monthDisplayFirstCell.firstChild.nodeValue = dateFormatter.format(dateUtil.parse(displayMonthList[i].id + "-01"), monthLocalePattern);
				} else {
					var monthDisplayCell = document.createElement("td");
					monthDisplayRow.insertBefore(monthDisplayCell, monthDisplayFirstCell);

					monthDisplayCell.colSpan = displayMonthList[i].index;
					monthDisplayCell.setAttribute("id", displayMonthList[i].id);

					if      (displayMonthList[i].index == 1)  monthLocalePattern = monthLocalePatterns.cell1;
					else if (displayMonthList[i].index == 2)  monthLocalePattern = monthLocalePatterns.cell2;

					monthDisplayCell.appendChild(document.createTextNode(dateFormatter.format(dateUtil.parse(displayMonthList[i].id + "-01"), monthLocalePattern)));
				}
			}

			$content$.section.gantt.progressDayList = displayDayList.concat($content$.section.gantt.progressDayList);
		} else {
			var mergedCount          = 0;
			var monthDisplayLastCell = null;

			if (monthDisplayCellCount > 0 && monthIntervals > 0) {
				monthDisplayLastCell = monthDisplayRow.querySelector("tr > td:last-child");
				if (monthDisplayLastCell.getAttribute("id") == displayMonthList[0].id) {
					mergedCount = monthDisplayLastCell.colSpan + displayMonthList[0].index;
				}
			}

			for (var i = 0; i < monthIntervals; i++) {
				var monthLocalePattern = monthLocalePatterns.yearMonth;

				if (i == 0 && mergedCount > 0) {
					monthDisplayLastCell.colSpan = mergedCount;

					monthDisplayLastCell.firstChild.nodeValue = dateFormatter.format(dateUtil.parse(displayMonthList[i].id + "-01"), monthLocalePattern);
					monthDisplayCellCount--;
				} else {
					var monthDisplayCell = monthDisplayRow.insertCell(monthDisplayCellCount + i);
					monthDisplayCell.colSpan = displayMonthList[i].index;
					monthDisplayCell.setAttribute("id", displayMonthList[i].id);

					if      (displayMonthList[i].index == 1)  monthLocalePattern = monthLocalePatterns.cell1;
					else if (displayMonthList[i].index == 2)  monthLocalePattern = monthLocalePatterns.cell2;

					monthDisplayCell.appendChild(document.createTextNode(dateFormatter.format(dateUtil.parse(displayMonthList[i].id + "-01"), monthLocalePattern)));
				}
			}

			$content$.section.gantt.progressDayList = $content$.section.gantt.progressDayList.concat(displayDayList);
		}

		// 간트챠트 시작일 설정
		if ($content$.section.gantt.progressDayList.length > 0) {
			$content$.section.gantt.progressStartDate = dateUtil.parse($content$.section.gantt.progressDayList[0].date);
		}
	},

	addProgressArea: function(index, insertBefore) {
		var progressDayList = $content$.section.gantt.progressDayList;
		var progressRulers  = document.querySelectorAll("body > section > div.section > ul#gantt > li:last-child > ul > li:last-child > div > label > input + div > ul");
		var scrollLeft      = index * 20;

		for (var i = 0; i < progressRulers.length; i++) {
			if (insertBefore) {
				var progressDayFirstLi = progressRulers[i].firstElementChild;

				for (var j = 0; j < index; j++) {
					var progressDayLi = document.createElement("li");
					progressDayLi.setAttribute("id", progressDayList[j].date);
					progressDayLi.setAttribute("class", progressDayList[j].week);
					progressRulers[i].insertBefore(progressDayLi, progressDayFirstLi);
				}

				if (progressRulers[i].getAttribute("class") == null) {
					var progressBar = progressRulers[i].nextElementSibling;
					progressBar.style.left = (parseInt(progressBar.style.left, 10) + scrollLeft) + "px";
				}
			} else {
				for (var j = index; j < progressDayList.length; j++) {
					var progressDayLi = document.createElement("li");
					progressDayLi.setAttribute("id", progressDayList[j].date);
					progressDayLi.setAttribute("class", progressDayList[j].week);
					progressRulers[i].appendChild(progressDayLi);
				}
			}
		}

		if (insertBefore) {
			var progressScrollDiv = document.querySelector("body > section > div.section > ul#gantt > li:last-child > ul > li:last-child > div");
			progressScrollDiv.scrollLeft = progressScrollDiv.scrollLeft + scrollLeft;
		}
	},

	setActivity2TaskValues: function(params, childTaskIdList) {
		if (params == null)  params = {};

		var startdate = "";
		var enddate   = "";
		var progress  = 0;
		var period    = 0;
		var taskUser  = "";
		var userName  = "";

		for (var i = 0; i < childTaskIdList.length; i++) {
			var itemUl = document.querySelector("body > section > div.section > ul#gantt > li:first-child > ul > li:last-child > div > div > label > input[value='" + childTaskIdList[i] + "'] + div > ul");

			if (itemUl.getAttribute("class") != "activity") {
				var periodLi   = itemUl.lastElementChild.firstElementChild.firstElementChild.nextElementSibling;
				var progressLi = periodLi.nextElementSibling;
				var userLi     = progressLi.nextElementSibling;

				var workingStartdate = periodLi.firstElementChild.getAttribute("id");
				var workingEnddate   = periodLi.lastElementChild.getAttribute("id");
				var workingprogress  = parseInt(progressLi.innerHTML.substring(1, 4), 10);
				var workingPeriod    = (dateUtil.parse(workingEnddate).getTime() - dateUtil.parse(workingStartdate).getTime()) / 86400000 + 1;

				if (startdate == "" || startdate > workingStartdate)  startdate = workingStartdate;
				if (enddate   == "" || enddate   < workingEnddate)    enddate = workingEnddate;

				period   += workingPeriod;
				progress += workingPeriod * workingprogress / 5;

				var userId = userLi.getAttribute("id");
				if (taskUser == "") {
					taskUser = userId;
					if ($content$.section.gantt.userMap[userId] == null) {
						userName  = userLi.firstChild.nodeValue;
					}
				} else if ($content$.section.gantt.userMap[userId]) {
					taskUser = userId;
				}
			}
		}

		params.startdate = startdate;
		params.enddate   = enddate;
		params.progress  = Math.round(progress / period) * 5;
		params.user_id   = taskUser;

		if (userName)  params.user_name = userName;

		return params;
	},

	addMovableEvent: function(iconSpan) {
		var moveGanttUl  = document.querySelector("body > section > div.section > ul#gantt");
		var moveAreaDiv  = document.querySelector("body > section > div.section > ul#gantt > li:first-child > ul > li:last-child > div > div");
		var selectedTask = null;
		var movedTask    = null;
		var isWebKit     = (navigator.userAgent.indexOf("Firefox") < 0 && navigator.userAgent.indexOf("Trident") < 0 && !(window.navigator.userAgent.indexOf("Edge") > 0 && window.navigator.vendor == ""));

		function createCloneNode(top, left) {
			moveGanttUl.setAttribute("class", "all_member move");

			var currentTaskId   = selectedTask.parentNode.parentNode.parentNode.previousElementSibling.value;
			var currentTaskType = selectedTask.parentNode.parentNode.getAttribute("class");
			var childTaskIdList = [currentTaskId].concat($content$.section.gantt.getChildTaskList(currentTaskId));

			for (var i = 0; i < childTaskIdList.length; i++) {
				$jnode$.node.addClass(moveAreaDiv.querySelector("div > label > input[value='" + childTaskIdList[i] + "']").parentNode, "current");
			}

			movedTask = selectedTask.cloneNode(true);
			movedTask.setAttribute("id"   , currentTaskId);
			movedTask.setAttribute("class", currentTaskType + " moving");
			movedTask.firstElementChild.innerHTML = "";
			movedTask.style.top  = selectedTask.offsetTop + "px";
			movedTask.style.left = selectedTask.offsetLeft + "px";
			moveAreaDiv.appendChild(movedTask);
		}

		function repositonCloneNode(containerRange, movedX, movedY) {
			var cloneX = movedX;
			var cloneY = moveAreaDiv.scrollTop + movedY;

			if (window.innerWidth < 737) {
				cloneY = movedY;
			}

			// X축 위치 이동 아이콘 이동
			if (movedX < 0) {
				movedTask.style.left = "0px";
			} else if (cloneX > containerRange.right) {
				movedTask.style.left = containerRange.right + "px";
			} else {
				movedTask.style.left = cloneX + "px";
			}

			// Y축 스크롤 이동
			if (window.innerWidth < 737) {
				if (isWebKit) {
					if (movedY > containerRange.height + document.body.scrollTop) {
						document.body.scrollTop = cloneY - containerRange.height;
					} else if (movedY < document.body.scrollTop - 100) {
						document.body.scrollTop = cloneY + 100;
					}
				} else {
					if (movedY > containerRange.height + document.documentElement.scrollTop) {
						document.documentElement.scrollTop = cloneY - containerRange.height;
					} else if (movedY < document.documentElement.scrollTop - 100) {
						document.documentElement.scrollTop = cloneY + 100;
					}
				}
			} else {
				if (movedY > containerRange.height) {
					moveAreaDiv.scrollTop = cloneY - containerRange.height;
				} else if ((movedY < 0) && (moveAreaDiv.scrollTop > 0)) {
					moveAreaDiv.scrollTop = cloneY;
				}
			}

			// Y축 위치 이동 아이콘 이동
			if (window.innerWidth < 737) {
				if (movedY < 0) {
					movedTask.style.top = "0px";
				} else if (cloneY > containerRange.bottom + (document.body.scrollTop || document.documentElement.scrollTop)) {
					movedTask.style.top = (containerRange.bottom + (document.body.scrollTop || document.documentElement.scrollTop)) + "px";
				} else {
					movedTask.style.top = cloneY + "px";
				}
			} else {
				if (movedY < 0) {
					if (moveAreaDiv.scrollTop > 0)  movedTask.style.top = moveAreaDiv.scrollTop + "px";
					else                            movedTask.style.top = "0px";
				} else if (cloneY > containerRange.bottom) {
					movedTask.style.top = containerRange.bottom + "px";
				} else {
					movedTask.style.top = cloneY + "px";
				}
			}

			var movableCursors = moveAreaDiv.querySelectorAll("div > label:not(.current) > input + div > ul > li:first-child > ul > li:first-child > span");
			var outbound = true;

			for (var i = 0; i < movableCursors.length; i++) {
				var cursorContainer = movableCursors[i];

				if ((cloneY > cursorContainer.offsetTop - 1) && (cloneY < cursorContainer.offsetTop + 27)) {
					if ((cloneX > cursorContainer.offsetLeft - 12) && (cloneX < cursorContainer.offsetLeft + 13)) {
						movableCursors[i].firstElementChild.checked = true;
						outbound = false;
						break;
					} else if ((cloneX > cursorContainer.offsetLeft + 12) && (cloneX < cursorContainer.offsetLeft + 37)) {
						movableCursors[i].firstElementChild.nextElementSibling.nextElementSibling.checked = true;
						outbound = false;
						break;
					}
				} else if ((i == 0) && (cloneY < cursorContainer.offsetTop)) {
					if ((cloneX > cursorContainer.offsetLeft - 12) && (cloneX < cursorContainer.offsetLeft + 13)) {
						movableCursors[i].lastElementChild.previousElementSibling.checked = true;
						outbound = false;
						break;
					}
				}
			}

			if (outbound) {
				var hoverCursor = moveAreaDiv.querySelector("div > label > input + div > ul > li:first-child > ul > li:first-child > span > input:checked");
				if (hoverCursor)  hoverCursor.checked = false;
			}
		}

		function applyMovableEvent() {
			var currentTaskId  = 0;
			var currentTaskIds = [];
			var currentTaskLabels = moveAreaDiv.querySelectorAll("div > label.current");

			for (var i = 0; i < currentTaskLabels.length; i++) {
				currentTaskIds.push(currentTaskLabels[i].firstElementChild.value);
				$jnode$.node.removeClass(currentTaskLabels[i], "current");
			}

			if (movedTask) {
				currentTaskId = movedTask.getAttribute("id");
				moveAreaDiv.removeChild(movedTask);
			}

			var hoverCursor = moveAreaDiv.querySelector("div > label > input + div > ul > li:first-child > ul > li:first-child > span > input:checked");
			if (hoverCursor) {
				hoverCursor.checked = false;
				var cursorTasks     = hoverCursor.value.split("_");
				var cursor          = cursorTasks[0];
				var targetTaskId    = cursorTasks[1];
				var currentIndex    = $content$.section.gantt.getTaskIndex(currentTaskId);
				var currentIndent   = null;
				var targetIndex     = null;
				var targetIndent    = null;
				var taskParent      = null;
				var taskSibling     = null;

				if (cursor == "previous") {
					targetIndex   = 0;
					taskParent    = "0";
					taskSibling   = targetTaskId;
					currentIndent = 0;
					targetIndent  = 0;
				} else {
					var targetPureIndex      = $content$.section.gantt.getTaskIndex(targetTaskId);
					var targetChildTaskList  = $content$.section.gantt.getChildTaskList(targetTaskId);
					var targetChildTaskCount = targetChildTaskList.length;

					currentIndent = parseInt(moveAreaDiv.querySelector("div > label > input[value='" + currentTaskId + "'] + div").getAttribute("class"), 10)

					if (cursor == "child") {
						targetIndex = targetPureIndex + 1;
					} else if (cursor == "next") {
						targetIndex = targetPureIndex + 1 + targetChildTaskCount;
					}

					// cursor를 child와 previous만으로 표현되게 수정
					if (cursor == "child") {
						targetIndent = parseInt(moveAreaDiv.querySelector("div > label > input[value='" + targetTaskId + "'] + div").getAttribute("class"), 10) + 1;
						taskParent = targetTaskId;

						if (targetChildTaskCount == 0) {
							var nextTaskInput = moveAreaDiv.querySelector("div > label:nth-child(" + (targetIndex + 1) + ") > input");
							if (nextTaskInput) {
								taskSibling = nextTaskInput.value;

								// 이동될 부모 일감 다음 일감이 이동하는 일감과 일치할 경우 이동하는 일감 다음 일감을 이웃 일감으로 다시 설정해야 한다.
								// currentTaskLabels에 이미 자기 자신이 포함되어 있기 때문에 1만 더 해준다.
								if (taskSibling == currentTaskId) {
									nextTaskInput = moveAreaDiv.querySelector("div > label:nth-child(" + (currentIndex + currentTaskLabels.length + 1) + ") > input");
									if (nextTaskInput) {
										taskSibling = nextTaskInput.value;
									} else {
										taskSibling = null;
									}
								}
							}
						} else {
							taskSibling = targetChildTaskList[0];
							cursor      = "previous";
						}
					} else if (cursor == "next") {
						targetIndex = targetPureIndex + 1 + targetChildTaskCount;
						targetIndent = parseInt(moveAreaDiv.querySelector("div > label > input[value='" + targetTaskId + "'] + div").getAttribute("class"), 10);
						taskParent  = moveAreaDiv.querySelector("div > label > input[value='" + targetTaskId + "']").parentNode.getAttribute("class");
						cursor      = "child";

						var nextTaskInput = moveAreaDiv.querySelector("div > label:nth-child(" + (targetIndex + 1) + ") > input");
						if (nextTaskInput) {
							taskSibling = nextTaskInput.value;

							// 커서 위치 다음 일감의 indent가 커서 위치 일감의 indent가 같으면 같은 레벨의 일감이 있는 것이므로 그 일감 이전으로 옮기고,
							// 없으면 마지막 일감 다음으로 옮기는 것이므로 부모 일감의 자식으로 맨 마지막에 옮긴다.
							if (parseInt(nextTaskInput.nextElementSibling.getAttribute("class"), 10) == targetIndent) {
								cursor = "previous";
							}
						}
					}
				}

				if (currentIndex != targetIndex || currentIndent != targetIndent) {
					$controller$.loading.show();

					var taskRemainder = moveAreaDiv.querySelector("div > label > input[value='" + currentTaskId + "']").parentNode.getAttribute("class");

					var params = {
						command:             "moveTask",
						project_id:          $content$.section.gantt.dataset.projectInfo.project_id,
						task_id:             currentTaskId,
						task_parent:         taskParent,
						task_sibling:        taskSibling,
						task_remainder:      taskRemainder,
						cursor:              cursor,
						changeTask2Activity: false,
						changeActivity2Task: false
					}

					if (taskParent != "0") {
						var taskType = moveAreaDiv.querySelector("div > label > input[value='" + taskParent + "'] + div > ul").getAttribute("class");
						if (taskType != "activity") {
							params.changeTask2Activity = true;
							$content$.section.gantt.changeTask2Activity(taskParent);
						}
					}

					if (!(taskRemainder == "0" || taskRemainder == taskParent)) {
						if (document.querySelectorAll("body > section > div.section > ul#gantt > li:first-child > ul > li:last-child > div > div > label[class='" + taskRemainder + "']").length == 1) {
							params.changeActivity2Task = true;
							params = $content$.section.gantt.setActivity2TaskValues(params, currentTaskIds);
							$content$.section.gantt.updateTaskValues(taskRemainder, params);
						}
					}

					$jnode$.ajax.service({
						"url":      "/ajax/gantt.json",
						"method":   "POST",
						"datatype": "json",
						"headers": {
							"Content-Type": "application/json",
							"Accept":       "application/json"
						},
						"params":  params,
						"success": function(response) {
							var diffIndent = 0;
							var nextItemTaskNode     = null;
							var nextProgressTaskNode = null;
							var progressAreaDiv      = document.querySelector("body > section > div.section > ul#gantt > li:last-child > ul > li:last-child > div");

							if (taskSibling) {
								nextItemTaskNode     = moveAreaDiv.querySelector("div > label > input[value='" + taskSibling + "']").parentNode;
								nextProgressTaskNode = progressAreaDiv.querySelector("div > label > input[value='" + taskSibling + "']").parentNode;
							}

							for (var i = 0; i < currentTaskLabels.length; i++) {
								var itemInput = currentTaskLabels[i].firstElementChild;
								var itemDiv   = itemInput.nextElementSibling;
								var oldIndent = parseInt(itemDiv.getAttribute("class"), 10);

								if (i == 0) {
									currentTaskLabels[i].setAttribute("class", taskParent);
									diffIndent = oldIndent - targetIndent;
								}

								itemDiv.setAttribute("class", oldIndent - diffIndent);
								itemDiv.firstElementChild.firstElementChild.style.paddingLeft = (16 * (oldIndent - diffIndent)) + "px";

								var currentProgressLabel = progressAreaDiv.querySelector("div > label > input[value='" + itemInput.value + "']").parentNode;

								if (taskSibling) {
									moveAreaDiv.insertBefore(currentTaskLabels[i], nextItemTaskNode);
									progressAreaDiv.insertBefore(currentProgressLabel, nextProgressTaskNode);
								} else {
									moveAreaDiv.appendChild(currentTaskLabels[i]);
									progressAreaDiv.appendChild(currentProgressLabel);
								}
							}

							$controller$.loading.hide();
						},
						"error": function(error) {
							$jnode$.ajax.alertError(error);
							$controller$.loading.hide();
						}
					});
				}
			}
		}

		// Touch Event
		function handleTouchMovableEvent(iconNode, event) {
			selectedTask = iconNode.parentNode.parentNode;

			var startX = event.touches[0].pageX;
			var startY = event.touches[0].pageY;

			var containerRange = {
				right:  moveAreaDiv.parentNode.offsetWidth - 24,
				bottom: moveAreaDiv.scrollHeight - 13,
				width:  moveAreaDiv.parentNode.offsetWidth - 24,
				height: moveAreaDiv.offsetHeight - 24
			};

			// 모바일 환경에서는 전체 화면이 스크롤
			if (window.innerWidth < 737) {
				containerRange.bottom = document.querySelector("body > section > div.section > footer").offsetTop - 124;
				containerRange.height = document.querySelector("body > section > div.section > footer").offsetTop - 124;
			}

			function reposition(event) {
				var movedX = event.touches[0].pageX - 12;
				var movedY = event.touches[0].pageY - 12  - moveAreaDiv.offsetTop;

				if (window.innerWidth < 737) {
					movedY = event.touches[0].pageY - 112;
				}

				repositonCloneNode(containerRange, movedX, movedY);
			}

			function moveCloneNode(event) {
				createCloneNode();
				document.addEventListener("touchmove", reposition, false);
			}

			function detectMovableEvent(event) {
				if ((Math.abs(event.touches[0].pageX - startX) > 3) || (Math.abs(event.touches[0].pageY - startY) > 3)) {
					selectedTask.removeEventListener("touchmove", detectMovableEvent, false);
					moveCloneNode(event);
				}
			}

			function clearMovableEvent(event) {
				moveGanttUl.setAttribute("class", "all_member");
				selectedTask.removeEventListener("touchmove", detectMovableEvent, false);
				selectedTask.removeEventListener("touchend", clearMovableEvent, false);
				document.removeEventListener("touchmove", reposition, false);

				applyMovableEvent();
			}

			selectedTask.addEventListener("touchmove", detectMovableEvent, false);
			selectedTask.addEventListener("touchend", clearMovableEvent, false);
			event.preventDefault();
		}

		// Mouse Event
		function handleMouseMovableEvent(iconNode, event) {
			selectedTask = iconNode.parentNode.parentNode;

			var startX = event.pageX;
			var startY = event.pageY;

			var containerRange = {
				right:  moveAreaDiv.parentNode.offsetWidth - 24,
				bottom: moveAreaDiv.scrollHeight - 13,
				width:  moveAreaDiv.parentNode.offsetWidth - 24,
				height: moveAreaDiv.offsetHeight - 24
			};

			// 모바일 환경에서는 전체 화면이 스크롤
			if (window.innerWidth < 737) {
				containerRange.bottom = document.querySelector("body > section > div.section > footer").offsetTop - 124;
				containerRange.height = document.querySelector("body > section > div.section > footer").offsetTop - 124;
			}

			function reposition(event) {
				var movedX = event.pageX - 12;
				var movedY = event.pageY - 12 - moveAreaDiv.offsetTop;

				if (window.innerWidth < 737) {
					movedY = event.pageY - 112;
				}

				repositonCloneNode(containerRange, movedX, movedY);
			}

			function moveCloneNode(event) {
				createCloneNode();
				document.addEventListener("mousemove", reposition, false);
			}

			function detectMovableEvent(event) {
				if ((Math.abs(event.pageX - startX) > 3) || (Math.abs(event.pageY - startY) > 3)) {
					selectedTask.removeEventListener("mousemove", detectMovableEvent, false);
					moveCloneNode(event);
				}
			}

			function clearMovableEvent(event) {
				moveGanttUl.setAttribute("class", "all_member");
				selectedTask.removeEventListener("mousemove", detectMovableEvent, false);
				document.removeEventListener("mousemove", reposition, false);
				document.removeEventListener("mouseup", clearMovableEvent, false);

				applyMovableEvent();
			}

			selectedTask.addEventListener("mousemove", detectMovableEvent, false);
			document.addEventListener("mouseup", clearMovableEvent, false);
			event.preventDefault();
		}

		iconSpan.addEventListener("touchstart", function(event) {
			handleTouchMovableEvent(this, event);
		}, false);

		iconSpan.addEventListener("mousedown", function(event) {
			handleMouseMovableEvent(this, event);
		}, false);
	},

	appendTask: function(taskInfo, index) {
		var projectInfo      = $content$.section.gantt.dataset.projectInfo;
		var progressStatus   = getProgressStatus(taskInfo.progress, taskInfo.startdate, taskInfo.enddate);
		var outboundProgress = isOutboundProgress(projectInfo.startdate, projectInfo.enddate, taskInfo.startdate, taskInfo.enddate);

		// Item Task
		itemTaskContainer = document.querySelector("body > section > div.section > ul#gantt > li:first-child > ul > li:last-child > div > div");

		var itemLabel = document.createElement("label");
		itemLabel.setAttribute("class", taskInfo.task_parent);  // 부모 ID

		if (index == null || index < 0) {
			itemTaskContainer.appendChild(itemLabel);
		} else {
			var nextItemLabel = document.querySelector("body > section > div.section > ul#gantt > li:first-child > ul > li:last-child > div > div > label:nth-child(" + (index + 1) + ")");
			itemTaskContainer.insertBefore(itemLabel, nextItemLabel);
		}

		var itemInput = document.createElement("input");
		itemInput.setAttribute("type" , "radio");
		itemInput.setAttribute("name" , "item_taskid");
		itemInput.setAttribute("value", taskInfo.task_id);
		itemLabel.appendChild(itemInput);

		var itemDiv = document.createElement("div");
		itemDiv.setAttribute("class", taskInfo.indent);
		itemLabel.appendChild(itemDiv);

		var itemUl = document.createElement("ul");
		itemDiv.appendChild(itemUl);

		var itemLi = document.createElement("li");
		itemLi.setAttribute("title", taskInfo.task_name);
		itemLi.style.paddingLeft = (16 * taskInfo.indent) + "px";
		itemUl.appendChild(itemLi);

		var nameUl = document.createElement("ul");
		itemLi.appendChild(nameUl);

		var iconLi = document.createElement("li");
		nameUl.appendChild(iconLi);

		var iconSpan = document.createElement("span");
		iconLi.appendChild(iconSpan);

		var nameLi = document.createElement("li");
		nameLi.appendChild(document.createTextNode(taskInfo.task_name));
		nameUl.appendChild(nameLi);

		/* position cursor */
		var nextCursor = document.createElement("input");
		nextCursor.setAttribute("type",  "radio");
		nextCursor.setAttribute("name",  "moved_cursor");
		nextCursor.setAttribute("value", "next_" + taskInfo.task_id);
		iconSpan.appendChild(nextCursor);
		iconSpan.appendChild(document.createElement("div"));

		var childCursor = document.createElement("input");
		childCursor.setAttribute("type",  "radio");
		childCursor.setAttribute("name",  "moved_cursor");
		childCursor.setAttribute("value", "child_" + taskInfo.task_id);
		iconSpan.appendChild(childCursor);
		iconSpan.appendChild(document.createElement("div"));

		var prevCursor = document.createElement("input");
		prevCursor.setAttribute("type",  "radio");
		prevCursor.setAttribute("name",  "moved_cursor");
		prevCursor.setAttribute("value", "previous_" + taskInfo.task_id);
		iconSpan.appendChild(prevCursor);
		iconSpan.appendChild(document.createElement("div"));

		var optionLi = document.createElement("li");
		itemUl.appendChild(optionLi);

		var optionUl = document.createElement("ul");
		optionLi.appendChild(optionUl);

		var noteLi = document.createElement("li");
		optionUl.appendChild(noteLi);

		var issueDiv = document.createElement("div");
		noteLi.appendChild(issueDiv);

		if (taskInfo.issue_id) {
			issueDiv.setAttribute("id", taskInfo.issue_id);
			if (taskInfo.issue_completion)  issueDiv.setAttribute("class", "completion");
		}

		var memoDiv = document.createElement("div");
		noteLi.appendChild(memoDiv);

		if (taskInfo.memo_id) {
			memoDiv.setAttribute("id", taskInfo.memo_id);
		}

		// 이슈 팝업
		issueDiv.addEventListener("click", function(event) {
			var noteId = this.getAttribute("id");
			var nameLi = this.parentNode.parentNode.parentNode.previousSibling;

			$jnode$.requireContent("winup", "/gantt/issue", {
				useLoading: true,
				icon:       true,
				title:      i18n.label_issue,
				width:      572,
				height:     401,
				project_id: projectInfo.project_id,
				task_id:    taskInfo.task_id,
				task_name:  nameLi.getAttribute("title"),
				note_id:    noteId
			});
		}, false);

		// 메모 팝업
		memoDiv.addEventListener("click", function(event) {
			var noteId = this.getAttribute("id");
			var nameLi = this.parentNode.parentNode.parentNode.previousSibling;

			$jnode$.requireContent("winup", "/gantt/memo", {
				useLoading: true,
				icon:       true,
				title:      i18n.label_memo,
				width:      572,
				height:     246,
				project_id: projectInfo.project_id,
				task_id:    taskInfo.task_id,
				task_name:  nameLi.getAttribute("title"),
				note_id:    noteId
			});
		}, false);

		var periodLi = document.createElement("li");
		optionUl.appendChild(periodLi);

		var startdateDiv = document.createElement("div");
		periodLi.appendChild(startdateDiv);

		var enddateDiv = document.createElement("div");
		periodLi.appendChild(enddateDiv);

		var progressLi = document.createElement("li");
		optionUl.appendChild(progressLi);

		if (taskInfo.startdate) {
			itemUl.setAttribute("class", progressStatus);
			if (outboundProgress)  $jnode$.node.addClass(itemUl, "outbound");

			if (taskInfo.startdate == taskInfo.enddate) {
				startdateDiv.setAttribute("class", "oneday");
				startdateDiv.innerHTML = dateFormatter.format(dateUtil.parse(taskInfo.startdate), dateFormatter.DateStyle.MEDIUM);
			} else {
				startdateDiv.innerHTML = dateFormatter.format(dateUtil.parse(taskInfo.startdate), dateFormatter.DateStyle.MEDIUM) + " ~";
			}

			startdateDiv.setAttribute("id", taskInfo.startdate);
			enddateDiv.setAttribute("id", taskInfo.enddate);
			enddateDiv.innerHTML = dateFormatter.format(dateUtil.parse(taskInfo.enddate), dateFormatter.DateStyle.MEDIUM);
			progressLi.innerHTML = "(" + taskInfo.progress + "%)";
		} else {
			itemUl.setAttribute("class", "activity");
		}

		var userLi = document.createElement("li");
		optionUl.appendChild(userLi);

		if (taskInfo.user_id) {
			userLi.setAttribute("id", taskInfo.user_id);

			if ($content$.section.gantt.userMap[taskInfo.user_id] == null) {
				userLi.setAttribute("class", "excluded");
			}

			if (taskInfo.user_id.search(/^[$][{].+[}]$/) == 0) {
				$jnode$.node.addClass(userLi, "retiree");

				var userSpan = document.createElement("span");
				userSpan.appendChild(document.createTextNode(taskInfo.user_name));
				userLi.appendChild(userSpan);
			} else {
				userLi.appendChild(document.createTextNode(taskInfo.user_name));
			}
		} else {
			userLi.setAttribute("id", "");
			userLi.appendChild(document.createTextNode(""));
		}

		// Progress Task
		var progressDayList = $content$.section.gantt.progressDayList;
		var progressTaskContainer = document.querySelector("body > section > div.section > ul#gantt > li:last-child > ul > li:last-child > div");

		var progressLabel = document.createElement("label");

		if (index == null || index < 0) {
			progressTaskContainer.appendChild(progressLabel);
		} else {
			var nextProgressLabel = document.querySelector("body > section > div.section > ul#gantt > li:last-child > ul > li:last-child > div > label:nth-child(" + (index + 1) + ")");
			progressTaskContainer.insertBefore(progressLabel, nextProgressLabel);
		}

		var progressInput = document.createElement("input");
		progressInput.setAttribute("type" , "radio");
		progressInput.setAttribute("name" , "progress_taskid");
		progressInput.setAttribute("value", taskInfo.task_id);
		progressLabel.appendChild(progressInput);

		var progressDiv = document.createElement("div");
		progressLabel.appendChild(progressDiv);

		var progressUl = document.createElement("ul");
		progressDiv.appendChild(progressUl);

		for (var i = 0; i < progressDayList.length; i++) {
			var progressDayLi = document.createElement("li");
			progressDayLi.setAttribute("id", progressDayList[i].date);
			progressDayLi.setAttribute("class", progressDayList[i].week);
			progressUl.appendChild(progressDayLi);
		}

		var progressBar = document.createElement("div");
		progressDiv.appendChild(progressBar);

		var progressPercent = document.createElement("div");
		progressBar.appendChild(progressPercent);

		if (taskInfo.startdate) {
			if      (progressStatus.search(/^delayed/) == 0)  progressBar.setAttribute("class", "delayed");
			else if (outboundProgress)                        progressBar.setAttribute("class", "outbound");

			var startIntervals    = (dateUtil.parse(taskInfo.startdate).getTime() - $content$.section.gantt.progressStartDate.getTime()) / 86400000;
			var progressIntervals = (dateUtil.parse(taskInfo.enddate).getTime() - dateUtil.parse(taskInfo.startdate).getTime()) / 86400000 + 1;

			progressBar.style.left  = (startIntervals * 20 - 1) + "px";
			progressBar.style.width = (progressIntervals * 20 - 1) + "px";

			progressPercent.style.width = taskInfo.progress + "%";
		} else {
			progressBar.setAttribute("class", "activity");
		}

		// Mark selected Task
		var addButton1  = document.querySelector("body > section > div.section > ul#gantt > li:first-child > ul > li:first-child > ul > li:last-child > ul > li:first-child");
		var editButton1 = addButton1.nextElementSibling;
		var addButton2  = document.querySelector("body > section > div.section > footer > ul > li > ul > li:nth-child(2) > button:nth-child(2)");
		var editButton2 = addButton2.nextElementSibling;

		itemInput.addEventListener("click", function(event) {
			progressInput.checked = true;
			addButton1.removeAttribute("class");
			editButton1.removeAttribute("class");
			addButton2.disabled = false;
			editButton2.disabled = false;
		}, false);

		progressInput.addEventListener("click", function(event) {
			itemInput.checked = true;
			addButton1.removeAttribute("class");
			editButton1.removeAttribute("class");
			addButton2.disabled = false;
			editButton2.disabled = false;
		}, false);

		// 작업자를 지정한 경우에는 Activity의 일감이 모두 이동했는지 여부를 알 수 없기 때문에 모든 프로젝트 멤버에 대해서만 처리
		if (this.conf.task_user == null || this.conf.task_user == "") {
			$content$.section.gantt.addMovableEvent(iconSpan);
		}
	},

	appendEmptyTask: function() {
		document.querySelector("body > section > div.section > ul#gantt > li:first-child > ul > li:last-child > div > div").innerHTML = "";

		var progressTaskContainer = document.querySelector("body > section > div.section > ul#gantt > li:last-child > ul > li:last-child > div");
		progressTaskContainer.innerHTML = "";

		var emptyTaskDiv = document.createElement("div");
		emptyTaskDiv.setAttribute("class", "empty");
		emptyTaskDiv.style.width = ($content$.section.gantt.progressDayList.length * 20) + "px";
		progressTaskContainer.appendChild(emptyTaskDiv);

		document.querySelector("body > section > div.section > ul#gantt > li:first-child > ul > li:first-child > ul > li:last-child > ul > li:first-child").removeAttribute("class");
		document.querySelector("body > section > div.section > footer > ul > li > ul > li:nth-child(2) > button:nth-child(2)").disabled = false;
	},

	changeTask2Activity: function(taskId) {
		var itemUl = document.querySelector("body > section > div.section > ul#gantt > li:first-child > ul > li:last-child > div > div > label > input[value='" + taskId + "'] + div > ul");
		itemUl.setAttribute("class", "activity");

		var periodLi = itemUl.lastElementChild.firstElementChild.firstElementChild.nextElementSibling;

		var startdateDiv = periodLi.firstElementChild;
		startdateDiv.removeAttribute("id");
		startdateDiv.removeAttribute("class");
		startdateDiv.innerHTML = "";

		var enddateDiv = periodLi.lastElementChild;
		enddateDiv.removeAttribute("id");
		enddateDiv.innerHTML = "";

		var progressLi = periodLi.nextElementSibling;
		progressLi.innerHTML = "";

		var userLi = progressLi.nextElementSibling;
		userLi.setAttribute("id", "");
		userLi.firstChild.nodeValue = "";

		var progressBar = document.querySelector("body > section > div.section > ul#gantt > li:last-child > ul > li:last-child > div > label > input[value='" + taskId + "'] + div > div");
		progressBar.removeAttribute("style");
		progressBar.setAttribute("class", "activity");
		progressBar.firstElementChild.removeAttribute("style");
	},

	updateTaskValues: function(taskId, taskInfo) {
		var progressStatus   = getProgressStatus(taskInfo.progress, taskInfo.startdate, taskInfo.enddate);
		var outboundProgress = isOutboundProgress($content$.section.gantt.dataset.projectInfo.startdate, $content$.section.gantt.dataset.projectInfo.enddate, taskInfo.startdate, taskInfo.enddate);

		var itemUl = document.querySelector("body > section > div.section > ul#gantt > li:first-child > ul > li:last-child > div > div > label > input[value='" + taskId + "'] + div > ul");
		itemUl.setAttribute("class", progressStatus);
		if (outboundProgress)  $jnode$.node.addClass(itemUl, "outbound");

		var periodLi   = itemUl.lastElementChild.firstElementChild.firstElementChild.nextElementSibling;
		var progressLi = periodLi.nextElementSibling;
		var userLi     = progressLi.nextElementSibling;

		var startdateDiv = periodLi.firstElementChild;
		var enddateDiv   = periodLi.lastElementChild;

		startdateDiv.setAttribute("id", taskInfo.startdate);
		enddateDiv.setAttribute("id", taskInfo.enddate);

		if (taskInfo.startdate == taskInfo.enddate) {
			startdateDiv.setAttribute("class", "oneday");
			startdateDiv.innerHTML = dateFormatter.format(dateUtil.parse(taskInfo.startdate), dateFormatter.DateStyle.MEDIUM);
		} else {
			startdateDiv.removeAttribute("class");
			startdateDiv.innerHTML = dateFormatter.format(dateUtil.parse(taskInfo.startdate), dateFormatter.DateStyle.MEDIUM) + " ~";
		}

		enddateDiv.innerHTML = dateFormatter.format(dateUtil.parse(taskInfo.enddate), dateFormatter.DateStyle.MEDIUM);
		progressLi.innerHTML = "(" + taskInfo.progress + "%)";

		if (taskInfo.user_id) {
			userLi.setAttribute("id", taskInfo.user_id);

			var userName = "";

			if ($content$.section.gantt.userMap[taskInfo.user_id]) {
				userName = $content$.section.gantt.userMap[taskInfo.user_id].user_name;
				$jnode$.node.removeClass(userLi, "excluded");
			} else {
				if      (taskInfo.user_name)                        userName = taskInfo.user_name;
				else if ($jnode$.node.hasClass(userLi, "retiree"))  userName = userLi.firstElementChild.firstChild.nodeValue;
				else                                                userName = userLi.firstChild.nodeValue;

				$jnode$.node.addClass(userLi, "excluded");
			}

			if (taskInfo.user_id.search(/^[$][{].+[}]$/) == 0) {
				$jnode$.node.addClass(userLi, "retiree");
				userLi.innerHTML = "<SPAN>" + $jnode$.escapeXML(userName) + "</SPAN>";
			} else {
				$jnode$.node.removeClass(userLi, "retiree");
				userLi.innerHTML = $jnode$.escapeXML(userName);
			}
		}

		var progressBar = document.querySelector("body > section > div.section > ul#gantt > li:last-child > ul > li:last-child > div > label > input[value='" + taskId + "'] + div > div");
		if (progressStatus.search(/^delayed/) == 0) {
			progressBar.setAttribute("class", "delayed");
		} else {
			if (outboundProgress)  progressBar.setAttribute("class", "outbound");
			else                   progressBar.removeAttribute("class");
		}

		var startIntervals    = (dateUtil.parse(taskInfo.startdate).getTime() - $content$.section.gantt.progressStartDate.getTime()) / 86400000;
		var progressIntervals = (dateUtil.parse(taskInfo.enddate).getTime() - dateUtil.parse(taskInfo.startdate).getTime()) / 86400000 + 1;

		progressBar.style.left  = (startIntervals * 20 - 1) + "px";
		progressBar.style.width = (progressIntervals * 20 - 1) + "px";

		progressBar.firstElementChild.style.width = taskInfo.progress + "%";
	},

	getChildTaskList: function(taskParentId) {
		var childTaskIdList = [];
		var itemTaskInputs = document.querySelectorAll("body > section > div.section > ul#gantt > li:first-child > ul > li:last-child > div > div > label[class='" + taskParentId + "'] > input");
		for (var i = 0; i < itemTaskInputs.length; i++) {
			childTaskIdList.push(itemTaskInputs[i].value);

			if (itemTaskInputs[i].nextElementSibling.firstElementChild.getAttribute("class") == "activity") {
				childTaskIdList = childTaskIdList.concat($content$.section.gantt.getChildTaskList(itemTaskInputs[i].value));
			}
		}

		return childTaskIdList;
	},

	/**
	 * Task가 비어 있거나, 해당 Task가 없으면 null을 return하고,
	 * relativePosition이 있으면 해당 Task 기준으로 상대적 위치의 index를 return하는데 상대적 위치가 마지막 위치라면
	 * 음수로 return한다.
	 */
	getTaskIndex: function(taskId, relativePosition) {
		var taskIds   = document.querySelectorAll("body > section > div.section > ul#gantt > li:first-child > ul > li:last-child > div > div > label > input");
		var taskCount = taskIds.length;
		var taskIndex = null;

		if (taskCount == 0)  return null;

		for (var i = 0; i < taskCount; i++) {
			if (taskIds[i].value == taskId) {
				taskIndex = i;
				break;
			}
		}

		if (taskIndex != null && relativePosition && relativePosition != "previous") {
			taskIndex += ($content$.section.gantt.getChildTaskList(taskId).length + 1);

			// 다음위치로 이동할 수 없을 때는 음수로 전체 Task 개수를 return.
			if (taskIndex == taskCount) {
				taskIndex = -1 * taskIndex;
			}
		}

		return taskIndex;
	},

	service: function() {
		$jnode$.pushHistory(this.conf);
		this.resizeGantt();
		window.addEventListener("resize", this.resizeGantt, false);
		i18n = this.dataset.i18n;

		if (i18n.alert_precondition_required != "-") {
			alert_precondition_required = i18n.alert_precondition_required;
			startId = "/project/create";
			linkStartId();
			return false;
		}

		var that               = this;
		var currentDate        = new Date();
		var currentdate        = dateUtil.format(currentDate);
		var projectInfo        = this.dataset.projectInfo;
		var taskList           = this.dataset.taskList;
		var projectId          = projectInfo.project_id;
		var projectStartdate   = projectInfo.startdate;
		var projectEnddate     = projectInfo.enddate;
		var projectStartDate   = dateUtil.parse(projectStartdate);
		var projectEndDate     = dateUtil.parse(projectEnddate);
		var addButton1         = document.querySelector("body > section > div.section > ul#gantt > li:first-child > ul > li:first-child > ul > li:last-child > ul > li:first-child");
		var editButton1        = addButton1.nextElementSibling;
		var workerButton1      = editButton1.nextElementSibling;
		var downButton1        = workerButton1.nextElementSibling;
		var addButton2         = document.querySelector("body > section > div.section > footer > ul > li > ul > li:nth-child(2) > button:nth-child(2)");
		var editButton2        = addButton2.nextElementSibling;
		var workerButton2      = editButton2.nextElementSibling;
		var downButton2        = workerButton2.nextElementSibling;
		var projectCloseButton = document.querySelector("body > section > div.section > ul#gantt > li:first-child > ul > li:first-child > ul > li:first-child > div:last-child > ul > li > div > button");
		var historyProjectSelectCallback = null;

		var memberList = that.dataset.memberList;

		for (var i = 0; i < memberList.length; i++) {
			that.userMap[memberList[i].user_id] = memberList[i];
		}

		/* ******************** */
		/* Project Progress bar */
		/* ******************** */
		var projectProgressbarLi = document.querySelector("body > header > ul > li:nth-child(2)");
		projectProgressbarLi.removeAttribute("class");

		var projectProgressbarContainer = document.createElement("div");
		projectProgressbarLi.appendChild(projectProgressbarContainer);

		var projectProgressbarCurrentContainer = document.createElement("div");
		var projectProgressbarStartPort   = document.createElement("div");
		var projectProgressbarEndPort     = document.createElement("div");
		projectProgressbarContainer.appendChild(projectProgressbarCurrentContainer);
		projectProgressbarContainer.appendChild(projectProgressbarStartPort);
		projectProgressbarContainer.appendChild(projectProgressbarEndPort);

		// current date
		var projectProgressbarCurrentPort = document.createElement("div");
		projectProgressbarCurrentContainer.appendChild(projectProgressbarCurrentPort);

		// start date
		var projectProgressbarStartDate = document.createElement("div");
		projectProgressbarStartDate.appendChild(document.createTextNode(dateFormatter.format(projectStartDate, dateFormatter.DateStyle.MEDIUM)));
		projectProgressbarStartPort.appendChild(projectProgressbarStartDate);

		// end date
		var projectProgressbarEndDate   = document.createElement("div");
		projectProgressbarEndDate.appendChild(document.createTextNode(dateFormatter.format(projectEndDate, dateFormatter.DateStyle.MEDIUM)));
		projectProgressbarEndPort.appendChild(projectProgressbarEndDate);

		var projectPeriod  = ((projectEndDate.getTime() - projectStartDate.getTime()) / 86400000) + 1; // 24 * 60 * 60 * 1000
		var workingPercent = 0;

		if (currentdate >= projectStartdate) {
			var projectProgressbarCurrentDate = document.createElement("div");
			projectProgressbarCurrentPort.appendChild(projectProgressbarCurrentDate);

			if (currentdate > projectEnddate) {
				projectProgressbarCurrentContainer.style.width = "100%";
			} else {
				projectProgressbarCurrentDate.appendChild(document.createTextNode(dateFormatter.format(currentDate, dateFormatter.DateStyle.MEDIUM)));
				workingPercent = (((currentDate.getTime() - projectStartDate.getTime()) / 86400000) * 2 + 1) / (projectPeriod * 2) * 100; // 24 * 60 * 60 * 1000
				projectProgressbarCurrentContainer.style.width = workingPercent + "%";

				this.resizeProjectPeriod();
				window.addEventListener("resize", this.resizeProjectPeriod, false);
			}

		}

		// Project Name
		var projectDiv  = document.querySelector("body > section > div.section > ul#gantt > li:first-child > ul > li:first-child > ul > li:first-child > div:first-child");
		var projectSpan = projectDiv.firstElementChild
		projectSpan.setAttribute("class", getProgressStatus((projectInfo.completion ? true : false), projectStartdate, projectEnddate, currentdate));
		projectDiv.appendChild(document.createTextNode(projectInfo.project_name));

		/* ******************** */
		/* Project List         */
		/* ******************** */
		projectDiv.addEventListener("click", function(event) {
			if (this.getAttribute("class") == "show") {
				projectCloseButton.click();
			} else {
				if (isPhone) {
					document.body.style.overflow = "hidden";

					historyProjectSelectCallback = $jnode$.node.pushPseudoHistory(function() {
						projectCloseButton.click();
					});
				}

				this.setAttribute("class", "show");
			}
		}, false);

		projectDiv.nextElementSibling.firstElementChild.addEventListener("click", function(event) {
			projectCloseButton.click();
		}, false);

		projectCloseButton.addEventListener("click", function(event) {
			if (isPhone) {
				document.body.style.removeProperty("overflow");
				if (historyProjectSelectCallback)  historyProjectSelectCallback();
			}

			projectDiv.setAttribute("class", "hide");
		}, false);

		var projectListContainer = document.querySelector("body > section > div.section > ul#gantt > li:first-child > ul > li:first-child > ul > li:first-child > div:last-child > ul > li > div > div > div > div");

		function moveGanttProjectEvent(projectDataDiv) {
			projectDataDiv.addEventListener("click", function(event) {
				if (isPhone) {
					document.body.style.removeProperty("overflow");
					// if (historyProjectSelectCallback)  historyProjectSelectCallback();
				}

				var projectId = this.getAttribute("id");

				$jnode$.requireContent("section", "/gantt", {useLoading:true, project_id:projectId});
				document.querySelector("body > nav > ul > li:last-child > div").innerHTML = i18n.label_gantt;
				window.scrollTo(0, 0);
			}, false);
		}

		for (var i = 0; i < this.dataset.projectList.length; i++) {
			var projectData    = this.dataset.projectList[i];
			var projectDataDiv = document.createElement("div");
			projectDataDiv.setAttribute("id", projectData.project_id);
			projectDataDiv.setAttribute("class", getProgressStatus((projectData.completion ? true : false), projectData.startdate, projectData.enddate, currentdate));
			projectDataDiv.appendChild(document.createTextNode(projectData.project_name));

			var projectDataPeriod = document.createElement("font");
			projectDataPeriod.appendChild(document.createTextNode(dateFormatter.format(dateUtil.parse(projectData.startdate), dateFormatter.DateStyle.MEDIUM) + " ~ " + dateFormatter.format(dateUtil.parse(projectData.enddate), dateFormatter.DateStyle.MEDIUM)));
			projectDataDiv.appendChild(projectDataPeriod);

			var projectDataContainer = document.createElement("div");
			projectDataContainer.appendChild(projectDataDiv);
			projectListContainer.appendChild(projectDataContainer);

			if (projectId == projectData.project_id) {
				projectDataContainer.setAttribute("class", "selected");
			}

			moveGanttProjectEvent(projectDataDiv);
		}

		/* ******************** */
		/* Gantt Chart          */
		/* ******************** */
		this.drawPeriodHeader(this.dataset.startdate, this.dataset.enddate, currentdate);

		var workingTaskId    = this.dataset.workingTaskId;
		var workingTaskIndex = -1;
		var taskCount        = taskList.length;

		if (taskCount == 0) {
			this.appendEmptyTask();
		} else {
			for (var i = 0; i < taskCount; i++) {
				this.appendTask(taskList[i]);

				if (workingTaskId && workingTaskId == taskList[i].task_id) {
					workingTaskIndex = i;
				}
			}
		}

		if (workingTaskIndex < 0) {
			editButton1.setAttribute("class", "disabled");
			editButton2.disabled = true;

			if (taskCount > 0) {
				addButton1.setAttribute("class", "disabled");
				addButton2.disabled = true;
			}
		} else {
			document.querySelector("body > section > div.section > ul#gantt > li:first-child > ul > li:last-child > div > div > label > input[value='" + workingTaskId + "']").checked = true;
			document.querySelector("body > section > div.section > ul#gantt > li:last-child > ul > li:last-child > div > label > input[value='" + workingTaskId + "']").checked = true;
		}

		if (this.dataset.task_user) {
			workerButton1.setAttribute("class", "disabled");
			workerButton2.disabled = true;
		}

		/* ******************** */
		/* Scroll Event         */
		/* ******************** */
		var progressScrollDiv = document.querySelector("body > section > div.section > ul#gantt > li:last-child > ul > li:last-child > div");
		var ganttDateDiv      = document.querySelector("body > section > div.section > ul#gantt > li:last-child > ul > li:first-child > ul > li:first-child > div");
		var itemTaskDiv       = document.querySelector("body > section > div.section > ul#gantt > li:first-child > ul > li:last-child > div > div");

		progressScrollDiv.addEventListener("mousedown", function(event) {
			if (window.innerWidth > 736) {
				this.setAttribute("class", "scrolled");
				itemTaskDiv.removeAttribute("class");
			}
		}, false);

		progressScrollDiv.addEventListener("touchstart", function(event) {
			if (window.innerWidth > 736) {
				this.setAttribute("class", "scrolled");
				itemTaskDiv.removeAttribute("class");
			}
		}, false);

		progressScrollDiv.addEventListener("mouseover", function(event) {
			if (window.innerWidth > 736) {
				this.setAttribute("class", "scrolled");
				itemTaskDiv.removeAttribute("class");
			}
		}, false);

		progressScrollDiv.addEventListener("scroll", function(event) {
			if (window.innerWidth > 736 && this.getAttribute("class") == "scrolled") {
				ganttDateDiv.scrollLeft = this.scrollLeft;
				itemTaskDiv.scrollTop   = this.scrollTop;
			}
		}, false);

		itemTaskDiv.addEventListener("touchstart", function(event) {
			if (window.innerWidth > 736) {
				this.setAttribute("class", "scrolled");
				progressScrollDiv.removeAttribute("class");
			}
		}, false);

		itemTaskDiv.addEventListener("mouseover", function(event) {
			if (window.innerWidth > 736) {
				this.setAttribute("class", "scrolled");
				progressScrollDiv.removeAttribute("class");
			}
		}, false);

		itemTaskDiv.addEventListener("scroll", function(event) {
			if (window.innerWidth > 736 && this.getAttribute("class") == "scrolled") {
				progressScrollDiv.scrollTop = this.scrollTop;
			}
		}, false);

		document.querySelector("body > section > div.section > ul#gantt > li:last-child > ul > li:first-child > ul > li:last-child > div > div > button:first-child").addEventListener("click", function(event) {
			progressScrollDiv.scrollTop = 0;
			itemTaskDiv.scrollTop       = 0;
		}, false);

		document.querySelector("body > section > div.section > ul#gantt > li:last-child > ul > li:first-child > ul > li:last-child > div > div > button:last-child").addEventListener("click", function(event) {
			progressScrollDiv.scrollTop = progressScrollDiv.scrollHeight;
			itemTaskDiv.scrollTop       = progressScrollDiv.scrollTop;
		}, false);

		document.querySelector("body > section > div.section > footer > ul > li > ul > li:last-child > button:first-child").addEventListener("click", function(event) {
			progressScrollDiv.scrollLeft = 0;
			ganttDateDiv.scrollLeft      = 0;
		}, false);

		document.querySelector("body > section > div.section > footer > ul > li > ul > li:last-child > button:last-child").addEventListener("click", function(event) {
			progressScrollDiv.scrollLeft = progressScrollDiv.scrollWidth;
			ganttDateDiv.scrollLeft = progressScrollDiv.scrollLeft;
		}, false);

		// Scrollbar Width가 잘못 적용되는 Web Browser에 대응하기 위해 다시 사이즈 조정.
		this.resizeGantt();

		if (workingTaskIndex > 4) {
			progressScrollDiv.scrollTop = 27 * (workingTaskIndex - 4);
		} else if (currentdate > this.dataset.enddate) {
			progressScrollDiv.scrollTop = progressScrollDiv.scrollHeight;
		}

		progressScrollDiv.scrollLeft = 20 * parseInt(this.dataset.diffdate, 10);

		ganttDateDiv.scrollLeft = progressScrollDiv.scrollLeft;
		itemTaskDiv.scrollTop   = progressScrollDiv.scrollTop;

		// 선택된 일감이 데스크탑 모드에서는 다섯번째에, 모바일 Phone 모드에서는 세번째에 위치하도록 세로 스크롤 이동.
		document.querySelector("body > section > div.section > footer > ul > li > ul > li:nth-child(2) > button:first-child").addEventListener("click", function(event) {
			var selectedInput = document.querySelector("body > section > div.section > ul#gantt > li:first-child > ul > li:last-child > div > div > label > input:checked");

			if (selectedInput) {
				var windowWidth   = window.innerWidth;
				var selectedIndex = that.getTaskIndex(selectedInput.value);

				if (windowWidth > 736) {
					progressScrollDiv.scrollTop = 27 * (selectedIndex - 4);
					itemTaskDiv.scrollTop = progressScrollDiv.scrollTop;
				} else if (windowWidth > 480) {
					window.scrollTo(0, 104 + 27 * (selectedIndex - 2));
				} else {
					window.scrollTo(0, 104 + 53 * (selectedIndex - 2));
				}
			}
		}, false);

		/* ******************** */
		/* Add / Edit Button    */
		/* ******************** */
		function getLastTaskDate(taskParentId) {
			var lastTaskdate = "";

			var itemTaskInputs = document.querySelectorAll("body > section > div.section > ul#gantt > li:first-child > ul > li:last-child > div > div > label[class='" + taskParentId + "'] > input");
			for (var i = 0; i < itemTaskInputs.length; i++) {
				var searcheddate = "";

				if (itemTaskInputs[i].nextElementSibling.firstElementChild.getAttribute("class") == "activity") {
					searcheddate = getLastTaskDate(itemTaskInputs[i].value);
				} else {
					searcheddate = itemTaskInputs[i].nextElementSibling.firstElementChild.lastElementChild.firstElementChild.firstElementChild.nextElementSibling.lastElementChild.getAttribute("id");
				}

				if (searcheddate > lastTaskdate)  lastTaskdate = searcheddate
			}

			return lastTaskdate;
		}

		function getPeriodFromLastTask(lastEnddate, dayoff) {
			var lastDate = null;

			if (lastEnddate)  lastDate = dateUtil.parse(lastEnddate);
			else              lastDate = dateUtil.toDate(-1);

			var weekday  = lastDate.getDay() + 1;
			var period   = [];

			if (weekday == 1) {
				// Case Monday
				period[0] = dateUtil.format(dateUtil.toDate(lastDate, 1));
				period[1] = dateUtil.format(dateUtil.toDate(lastDate, 7 - dayoff));
			} else if (weekday == 6) {
				// Case Saturday
				if (dayoff == 2)  period[0] = dateUtil.format(dateUtil.toDate(lastDate, 3));
				else              period[0] = dateUtil.format(dateUtil.toDate(lastDate, 1));
				period[1] = dateUtil.format(dateUtil.toDate(lastDate, 7));
			} else if (weekday == 7) {
				// Case Sunday
				period[0] = dateUtil.format(dateUtil.toDate(lastDate, 2));
				period[1] = dateUtil.format(dateUtil.toDate(lastDate, 8 - dayoff));
			} else {
				period[0] = dateUtil.format(dateUtil.toDate(lastDate, 1));
				period[1] = dateUtil.format(dateUtil.toDate(lastDate, 7));
			}

			return period;
		}

		function clickAddButton(event) {
			var winupHeight   = 430;
			var selectedInput = document.querySelector("body > section > div.section > ul#gantt > li:first-child > ul > li:last-child > div > div > label > input:checked");
			var taskParentId  = "0";
			var taskTargetId  = "0";
			var taskUser      = "";
			var indent        = -1;
			var position      = "child";
			var lastTaskdate  = "";
			var taskUserClass = "";
			var positionClass = "";

			if (selectedInput) {
				var selectedDiv = selectedInput.nextElementSibling;
				var selectedUl  = selectedDiv.firstElementChild;

				taskParentId = selectedInput.parentNode.getAttribute("class");
				taskTargetId = selectedInput.value;
				indent       = parseInt(selectedDiv.getAttribute("class"), 10);

				if (selectedUl.getAttribute("class") == "activity") {
					lastTaskdate = getLastTaskDate(taskTargetId);
				} else {
					lastTaskdate = selectedUl.lastElementChild.firstElementChild.firstElementChild.nextElementSibling.lastElementChild.getAttribute("id");
					position     = "next";
				}
			} else {
				lastTaskdate  = dateUtil.format(dateUtil.toDate(projectStartDate, -1));
				winupHeight   = 399;
				positionClass = "hidden";
			}

			var taskPeriod = getPeriodFromLastTask(lastTaskdate, projectInfo.dayoff);

			if (that.conf.task_user) {
				taskUser      = that.conf.task_user;
				winupHeight  -= 31;
				taskUserClass = "hidden";
			} else if (position == "next") {
				taskUser = selectedUl.lastElementChild.firstElementChild.lastElementChild.getAttribute("id");
			} else {
				taskUser = that.conf.user_id;
			}

			$jnode$.requireContent("winup", "/gantt/add", {
				useLoading:      true,
				icon:            true,
				title:           i18n.label_add_task,
				width:           572,
				height:          winupHeight,
				project_id:      projectId,
				position:        position,
				task_parent:     taskParentId,
				task_sibling:    taskTargetId,
				indent:          indent,
				startdate:       taskPeriod[0],
				enddate:         taskPeriod[1],
				currentdate:     currentdate,
				task_user:       taskUser,
				task_user_class: taskUserClass,
				position_class:  positionClass,
				renderer:        "-j"
			});
		}

		function clickEditButton(event) {
			var winupHeight   = 461;
			var selectedInput = document.querySelector("body > section > div.section > ul#gantt > li:first-child > ul > li:last-child > div > div > label > input:checked");
			var taskUser      = "";
			var lastTaskdate  = "";
			var taskUserClass = "";
			var selectedDiv   = selectedInput.nextElementSibling;
			var selectedUl    = selectedDiv.firstElementChild;
			var startdate     = "";
			var enddate       = "";
			var progress      = 0;

			if (selectedUl.getAttribute("class") == "activity") {
				winupHeight   = 118;
				taskUserClass = "hidden";
			} else {
				var periodLi   = selectedUl.lastElementChild.firstElementChild.firstElementChild.nextElementSibling;
				var progressLi = periodLi.nextElementSibling;
				var userLi     = progressLi.nextElementSibling;

				startdate = periodLi.firstElementChild.getAttribute("id");
				enddate   = periodLi.lastElementChild.getAttribute("id");
				progress  = parseInt(progressLi.innerHTML.substring(1, 4), 10);

				if (that.conf.task_user) {
					taskUser      = that.conf.task_user;
					winupHeight  -= 31;
					taskUserClass = "hidden";
				} else {
					taskUser = userLi.getAttribute("id");
				}
			}

			$jnode$.requireContent("winup", "/gantt/edit", {
				useLoading:       true,
				icon:             true,
				title:            i18n.label_edit_task,
				width:            572,
				height:           winupHeight,
				project_id:       projectId,
				dayoff:           projectInfo.dayoff,
				task_id:          selectedInput.value,
				task_name:        selectedUl.firstElementChild.getAttribute("title"),
				startdate:        startdate,
				enddate:          enddate,
				progress:         progress,
				currentdate:      currentdate,
				task_user:        taskUser,
				task_user_class:  taskUserClass,
				is_excluded_user: (that.userMap[taskUser] == null)
			});
		}

		function clickWorkerButton(event) {
			$jnode$.requireContent("winup", "/gantt/worker", {
				useLoading: true,
				icon:       true,
				title:      i18n.label_change_assigned_worker,
				width:      700,
				height:     118,
				project_id: projectId
			});
		}

		function clickDownloadButton(event) {
			$jnode$.requireContent("winup", "/gantt/download", {
				useLoading: true,
				icon:       true,
				title:      i18n.label_download_as_image,
				width:      480,
				height:     180,
				renderer:   "-j",
				file_name:  "Gantt chart (" + projectInfo.project_name + ")"
			});
		}

		addButton1.addEventListener("click", function(event) {
			if (this.getAttribute("class") == null) {
				clickAddButton(event);
			}
		}, false);

		editButton1.addEventListener("click", function(event) {
			if (this.getAttribute("class") == null) {
				clickEditButton(event);
			}
		}, false);

		workerButton1.addEventListener("click", function(event) {
			if (this.getAttribute("class") == null) {
				clickWorkerButton(event);
			}
		}, false);

		downButton1.addEventListener("click", clickDownloadButton, false);

		addButton2   .addEventListener("click", clickAddButton, false);
		editButton2  .addEventListener("click", clickEditButton, false);
		workerButton2.addEventListener("click", clickWorkerButton, false);
		downButton2  .addEventListener("click", clickDownloadButton, false);

		// 작업자
		var workerSelect = document.querySelector("body > section > div.section > footer > ul > li > ul > li.select > select");

		workerSelect.addEventListener("change", function(event) {
			var taskUser = this.value;

			$jnode$.requireContent("section", "/gantt", {
				useLoading: true,
				task_user:  taskUser
			});
		}, false);

		if (this.conf.task_user == null || this.conf.task_user == "") {
			document.querySelector("body > section > div.section > ul#gantt").setAttribute("class", "all_member");
		}
	},

	unload: function() {
		var projectProgressbarLi = document.querySelector("body > header > ul > li:nth-child(2)");
		projectProgressbarLi.setAttribute("class", "hidden");
		projectProgressbarLi.innerHTML = "";

		window.removeEventListener("resize", this.resizeProjectPeriod, false);
		window.removeEventListener("resize", this.resizeGantt, false);
	}
};