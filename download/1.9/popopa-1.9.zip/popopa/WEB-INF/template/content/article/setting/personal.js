$content$.article.setting.personal = {
	service: function() {
		var settingInfo = this.dataset.settingInfo;
		var systemInfo  = this.dataset.systemInfo;
		$jnode$.pushHistory(this.conf);

		var okButton = document.querySelector("article > div.article > form > fieldset > button:first-child");

		okButton.addEventListener("click", function(event) {
			$controller$.loading.show();
			var params = $jnode$.toJSON(document.settingForm);
			params.command = "updatePersonalSettings"

			$jnode$.ajax.service({
				"url":      "/ajax/setting.json",
				"method":   "POST",
				"datatype": "json",
				"headers": {
					"Content-Type": "application/json",
					"Accept":       "application/json"
				},
				"params":  params,
				"success": function(response) {
					if (startId.split("/").length == 2) {
						startId = "/" + params.start_page;
					}

					if ($jnode$.node.theme != response.theme) {
						$jnode$.node.setTheme(response.theme);
					}

					if (params.lang == settingInfo.lang) {
						$controller$.loading.hide();
					} else {
						$jnode$.requireContent("section", "/setting", {articleId:"/setting/personal"});
					}
				},
				"error": function(error) {
					$jnode$.ajax.alertError(error);
					$controller$.loading.hide();
				}
			});
		}, false);

		okButton.nextElementSibling.addEventListener("click", function(event) {
			$controller$.loading.show();

			$jnode$.ajax.service({
				"url":      "/ajax/setting.json",
				"method":   "POST",
				"datatype": "json",
				"headers": {
					"Content-Type": "application/json",
					"Accept":       "application/json"
				},
				"params":  {
					command: "initializeSettings"
				},
				"success": function(response) {
					if (startId.split("/").length == 2) {
						startId = "/" + systemInfo.start_page;
					}

					if ($jnode$.node.theme != systemInfo.theme) {
						$jnode$.node.setTheme(systemInfo.theme);
					}

					if (systemInfo.lang == settingInfo.lang) {
						$jnode$.requireContent("article", "/setting/personal");
					} else {
						$jnode$.requireContent("section", "/setting", {articleId:"/setting/personal"});
					}
				},
				"error": function(error) {
					$jnode$.ajax.alertError(error);
					$controller$.loading.hide();
				}
			});
		}, false);
	}
};