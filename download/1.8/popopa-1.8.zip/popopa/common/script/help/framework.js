function handleTerminator(uri) {
	var terminator = uri.split("/$/")[1];

	if (terminator && terminator.indexOf(":") > 0) {
		var separatedTerminators = terminator.split(":");
		var nodeType = separatedTerminators[0];
		var nodeId   = separatedTerminators[1];

		if (nodeId == "" || nodeId == "/") {
			nodeId = "/index";
		} else if (nodeId.indexOf("/") != 0) {
			nodeId = "/" + nodeId;
		}

		// nodeId = "/" + document.langForm.lang.value + nodeId;

		if (nodeType == "helpsection") {
			var menuInput = document.querySelector("body > nav > div > div ul > li > label > input[name='menu'][value='" + nodeId + "']");

			if (menuInput) {
				menuInput.checked = true;
				$jnode$.requireContent("helpsection", nodeId, {useLoading:true, renderer:"-j"});
			}
		}

		return nodeId;
	}
}

function moveLang(event) {
	$controller$.loading.show();

	var action = document.langForm.action;
	var nodeState = window.history.state || event.state;
	if (nodeState && nodeState.nodeId && nodeState.nodeId.indexOf("/introduction") < 0) {
		if (action.lastIndexOf("/") == action.length - 1)  action = action.substring(0, action.length - 1);

		action += "/$/" + nodeState.nodeType + ":/" + this.value + nodeState.nodeId.substring(3);
	}

	document.langForm.action     = action;
	document.langForm.lang.value = this.value;
	document.langForm.submit();
}

function openParentNode(node) {
	var parentNode = node.parentNode.parentNode.previousElementSibling;
	if (parentNode)  parentNode.setAttribute("class", "opened");
	return parentNode;
}

function openSection(sectionId) {
	var lang = document.langForm.lang.value;

	if (sectionId.indexOf("/") != 0)  sectionId = "/" + sectionId;
	if (sectionId.indexOf("/" + lang) != 0)  sectionId = "/" + lang + sectionId;

	var sectionMenu = document.querySelector("body > nav > div > div ul > li > label > input[value='" + sectionId + "']");
	if (sectionMenu) {
		sectionMenu.checked = true;
		$jnode$.requireContent("helpsection", sectionId, {useLoading:true, renderer:"-j"});
	}
}
