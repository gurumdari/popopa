$content$.article.setting.system = {
	service: function() {
		var systemInfo = this.dataset.systemInfo;
		$jnode$.pushHistory(this.conf);

		document.querySelector("article > div.article > form > fieldset > button").addEventListener("click", function(event) {
			$controller$.loading.show();
			var params = $jnode$.toJSON(document.settingForm);
			params.command = "updateSystemSettings"

			$jnode$.ajax.service({
				"url":      "/ajax/setting.json",
				"method":   "POST",
				"datatype": "json",
				"headers": {
					"Content-Type": "application/json",
					"Accept":       "application/json"
				},
				"params":  params,
				"success": function(response) {
					if (startId.split("/").length == 2) {
						startId = "/" + params.start_page;
					}

					if ((params.lang == systemInfo.lang) && (params.sync_setting == systemInfo.sync_setting)) {
						$controller$.loading.hide();
					} else {
						$jnode$.requireContent("section", "/setting", {useLoading:true, articleId:"/setting/system"});
					}
				},
				"error": function(error) {
					$jnode$.ajax.alertError(error);
					$controller$.loading.hide();
				}
			});
		}, false);
	}
};