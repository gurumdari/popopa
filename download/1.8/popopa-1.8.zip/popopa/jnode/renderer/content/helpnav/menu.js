$content$.helpnav.menu = {
	service: function() {
		window.dateFormatter = new $module$.date.Formatter("MEDIUM_DATE", {lang:this.dataset.blang});
		document.langForm4mobile.lang.innerHTML = document.langForm.lang.innerHTML;

		document.langForm4mobile.lang.addEventListener("change", moveLang, false);

		function swapCategory(category) {
			category.addEventListener("click", function(event) {
				if (this.getAttribute("class") == "closed") {
					this.setAttribute("class", "opened");
				} else {
					this.setAttribute("class", "closed");
				}
			}, false);
		}

		function requireSection(menu) {
			menu.addEventListener("click", function(event) {
				$jnode$.requireContent("helpsection", this.value, {useLoading:true, renderer:"-j"});

				var unfoldHeader = document.querySelector("body > header.unfold");
				if (unfoldHeader)  unfoldHeader.setAttribute("class", "fold");
			}, false);
		}

		var categories = document.querySelectorAll("body > nav > div > div ul > li > div");
		var menus = document.querySelectorAll("body > nav > div > div ul > li > label > input");

		for (var i = 0; i < categories.length; i++) {
			swapCategory(categories[i]);
		}

		var startId       = menus[0].value;
		var helpsectionId = null;

		var uri = document.location.pathname;
	
		if (uri.indexOf("/$/helpsection:") > ($jnode$.contextPath.length - 1))  helpsectionId = handleTerminator(uri);  // $jnode$.contextPath + "/$/helpsection:/en/path/to/path"

		for (var i = 0; i < menus.length; i++) {
			requireSection(menus[i]);

			if (menus[i].value == helpsectionId) {
				menus[i].checked = true;
				startId = helpsectionId;
			}
		}

		$jnode$.requireContent("helpsection", startId, {useLoading:true, renderer:"-j"});
	}
};
