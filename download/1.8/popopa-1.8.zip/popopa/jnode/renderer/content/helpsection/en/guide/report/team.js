$content$.helpsection.en.guide.report.team = {
	service: function() {
		var selectedSpan = document.querySelector("body > nav > div > div ul > li > label > input:checked + span");
		menuClassDiv.innerHTML = selectedSpan.innerHTML;
		$jnode$.pushHistory(this.conf);

		openParentNode(selectedSpan.parentNode);
	}
};
