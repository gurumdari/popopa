$content$.helpsection.en.setting.system.user.method = {
	service: function() {
		var selectedSpan = document.querySelector("body > nav > div > div ul > li > label > input:checked + span");
		menuClassDiv.innerHTML = selectedSpan.innerHTML;
		$jnode$.pushHistory(this.conf);

		var parentCategory1 = openParentNode(selectedSpan.parentNode);
		openParentNode(parentCategory1);
	}
};
