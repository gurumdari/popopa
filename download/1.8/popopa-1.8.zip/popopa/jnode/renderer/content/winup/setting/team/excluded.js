$content$.winup.setting.team.excluded = {
	resize: function() {
		var windowWidth  = window.innerWidth;
		var windowHeight = window.innerHeight;
		var controllerHeight = 268;

		if (windowWidth < 737) {
			if (windowHeight < 388) {
				controllerHeight = windowHeight * 0.8 - 42;
			}
		}

		$controller$["grid#excluded"].resize(null, controllerHeight);
	},

	service: function() {
		var that = this;
		$jnode$.requireController("grid#excluded", {caller:that.conf}).on(function() {
			$controller$["grid#excluded"].service({height:268, sortable:true});

			var excludedCountSpan = document.querySelector("div.section > article > div.article > fieldset:last-child > div > div > button:last-child > div > span:last-child");
			var tbody             = document.querySelector("aside.winup article > div.winup > aside.grid#excluded > div > table > tbody");
			var approveButton     = document.querySelector("aside.winup article > div.winup > ul.submit > li:last-child > button:first-child");

			approveButton.disabled = true;

			function appendEngineerRow(engineerInfo) {
				var row    = document.createElement("tr");
				row.setAttribute("id", engineerInfo.engineer_id);
				tbody.appendChild(row);

				var nameCell = row.insertCell(0);
				nameCell.appendChild(document.createTextNode(engineerInfo.engineer_name));

				var idCell = row.insertCell(1);
				idCell.appendChild(document.createTextNode(engineerInfo.engineer_id));

				var positionCell = row.insertCell(2);
				positionCell.setAttribute("id", engineerInfo.position_id);
				positionCell.setAttribute("sid", $content$.article.setting.team.posSortMap[engineerInfo.position_id.toString()]);
				positionCell.appendChild(document.createTextNode(engineerInfo.position_name));

				var cellIndex = 3;

				if (that.dataset.use_org) {
					var orgCell = row.insertCell(cellIndex++);
					orgCell.setAttribute("id", engineerInfo.org_id);
					orgCell.appendChild(document.createTextNode(engineerInfo.org_name));
				}

				var createCell = row.insertCell(cellIndex++);
				createCell.setAttribute("class", engineerInfo.team_createdate);
				createCell.appendChild(document.createTextNode(dateFormatter.format(dateUtil.parse(engineerInfo.team_createdate), dateFormatter.DateStyle.MEDIUM)));

				row.addEventListener("click", function(event) {
					if (this.getAttribute("class") == "selected") {
						this.removeAttribute("class");
						
						if (document.querySelectorAll("aside.winup article > div.winup > aside.grid > div > table > tbody > tr.selected").length == 0) {
							approveButton.disabled = true;
						}
					} else {
						this.setAttribute("class", "selected");

						approveButton.disabled = false;
					}
				}, false);
			}

			var engineerList  = that.dataset.engineerList;
			var engineerCount = engineerList.length;
			excludedCountSpan.innerHTML = engineerCount;

			for (var i = 0; i < engineerCount; i++) {
				appendEngineerRow(engineerList[i]);
			}

			if (engineerCount == 0) {
				excludedCountSpan.parentNode.parentNode.disabled = true;
			}

			function getSelectedEngineers() {
				var engineers = [];
				var selectedRows = tbody.querySelectorAll("tbody > tr.selected");

				for (var i = 0; i < selectedRows.length; i++) {
					var nameCell     = selectedRows[i].firstElementChild;
					var positionCell = nameCell.nextElementSibling.nextElementSibling;
					var createCell   = selectedRows[i].lastElementChild;

					var engineerInfo = {
						engineer_name:   nameCell.firstChild.nodeValue,
						engineer_id:     selectedRows[i].getAttribute("id"),
						position_id:     positionCell.getAttribute("id"),
						position_name:   positionCell.firstChild.nodeValue,
						team_createdate: createCell.getAttribute("class")
					};

					if (that.dataset.use_org) {
						var orgCell = positionCell.nextElementSibling;

						engineerInfo.org_id   = orgCell.getAttribute("id");
						engineerInfo.org_name = orgCell.firstChild.nodeValue;
					}

					engineers.push(engineerInfo);
				}

				return engineers;
			}

			approveButton.addEventListener("click", function(event) {
				$controller$.loading.show();

				var engineers = getSelectedEngineers();
				var teamEngineers = [];
				for (var i = 0; i < engineers.length; i++) {
					teamEngineers.push(engineers[i].engineer_id);
				}

				var params = {
					command:       "changeMemberStatus",
					team_engineer: teamEngineers.join(","),
					member_status: "included"
				};
				
				$jnode$.ajax.service({
					"url":      "/ajax/team.json",
					"method":   "POST",
					"datatype": "json",
					"headers": {
						"Content-Type": "application/json",
						"Accept":       "application/json"
					},
					"params":  params,
					"success": function(response) {
						for (var i = 0; i < engineers.length; i++) {
							$content$.article.setting.team.appendEngineer(engineers[i]);
							tbody.removeChild(tbody.querySelector("tbody > tr[id='" + engineers[i].engineer_id + "']"));
						}

						var reservedCount = tbody.querySelectorAll("tbody > tr").length;
						excludedCountSpan.innerHTML = reservedCount;

						if (reservedCount == 0) {
							excludedCountSpan.parentNode.parentNode.disabled = true;
						}

						approveButton.disabled = true;

						$controller$.loading.hide();
					},
					"error": function(error) {
						$jnode$.ajax.alertError(error);
						$controller$.loading.hide();
					}
				});
			}, false);

			window.addEventListener("resize", that.resize, false);
			that.resize();
		});
	},

	unload: function() {
		window.removeEventListener("resize", this.resize, false);
	}
};