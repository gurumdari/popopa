$content$.winup.setting.user.edit = {
	service: function() {
		var parentNode = this.conf.parentNode;
		var userType   = this.dataset.userType;

		var articleObject  = $content$.article.setting[parentNode];
		var articleDataset = articleObject.dataset;
		var worker         = articleDataset.worker;
		var positionList   = articleDataset.positionList;
		var positionSelect = document.userForm.user_position;
		var userTbody      = document.querySelector("aside.grid > div > table > tbody");
		var userRow        = userTbody.querySelector("tbody > tr.selected");
		var alertNode      = document.userForm.querySelector("form > ul.submit > li.alert");

		for (var i = 0; i < positionList.length; i++) {
			positionSelect.options.add(new Option(positionList[i].position_name, positionList[i].position_id));
		}

		var userNameCell = userRow.firstElementChild;
		var userIdCell   = userNameCell.nextElementSibling;
		var positionCell = userIdCell.nextElementSibling;

		var userId = userIdCell.firstChild.nodeValue;

		positionSelect.value = positionCell.getAttribute("id");
		document.userForm.user_name.value = userNameCell.firstChild.nodeValue;
		document.userForm.querySelector("form > table.form > tbody > tr:nth-child(3) > td").innerHTML = $jnode$.escapeHTML(userId);

		document.userForm.querySelector("form > ul.submit > li > button:first-child").addEventListener("click", function(event) {
			var params = {
				command:       "updateUser",
				user_name:     document.userForm.user_name.value.trim(),
				user_id:       userId,
				position_id:   positionSelect.value,
				position_name: positionSelect.options[positionSelect.selectedIndex].text
			};

			var alertMessage    = null;

			if (params.user_name == "") {
				alertMessage = i18n["alert_input_" + userType + "_name"];
				document.userForm.user_name.select();
			}
			
			if (alertMessage) {
				alertNode.innerHTML = alertMessage;
			} else {
				$controller$.loading.show();

				$jnode$.ajax.service({
					"url":      "/ajax/user.json",
					"method":   "POST",
					"datatype": "json",
					"headers": {
						"Content-Type": "application/json",
						"Accept":       "application/json"
					},
					"params":  params,
					"success": function(response) {
						userNameCell.firstChild.nodeValue = params.user_name;
						positionCell.firstChild.nodeValue = params.position_name;
						positionCell.setAttribute("id", params.position_id);
						positionCell.setAttribute("sid", articleObject.posSortMap[params.position_id]);

						$controller$.grid.clear("thead");

						if (worker == userId) {
							document.querySelector("body > header > ul > li:last-child > ul > li.account").innerHTML = $jnode$.escapeHTML(params.user_name);
						}

						$controller$.winup.close();
						$controller$.loading.hide();
					},
					"error": function(error) {
						$jnode$.ajax.alertError(error);
						$controller$.loading.hide();
					}
				});
			}
		}, false);

		var deleteButton = document.userForm.querySelector("form > ul.submit > li > button:last-child");
		if (worker == userId)  deleteButton.disabled = true;

		deleteButton.addEventListener("click", function(event) {
			$controller$.prompt.confirm(i18n["confirm_delete_" + userType], function(close) {
				$controller$.loading.show();

				$jnode$.ajax.service({
					"url":      "/ajax/user.json",
					"method":   "POST",
					"datatype": "json",
					"headers": {
						"Content-Type": "application/json",
						"Accept":       "application/json"
					},
					"params":  {
						command:     "deleteUser",
						user_id:     userId,
						ckeck_count: ((parentNode == "admin") || (userTbody.children.length > 1)) ? "false" : "true"
					},
					"success": function(response) {
						userTbody.removeChild(userRow);

						var userEditButton = document.querySelector("div.section > article > div.article > fieldset > ul > li:last-child > button:nth-child(2)");
						userEditButton.disabled = true;
						userEditButton.nextElementSibling.disabled = true;

						if (response.start_id) {
							startId = response.start_id;
							alert_precondition_required = i18n.alert_precondition_required;
							$controller$.grid.clear("thead");
						}

						$controller$.winup.close();
						$controller$.loading.hide();
					},
					"error": function(error) {
						$jnode$.ajax.alertError(error);
						$controller$.loading.hide();
					}
				});

				close();
			}, null, 2);
		}, false);
	}
};