CREATE TABLESPACE popopa LOCATION '${tablespace_dir_for_popopa}';

CREATE DATABASE popopa TABLESPACE popopa;