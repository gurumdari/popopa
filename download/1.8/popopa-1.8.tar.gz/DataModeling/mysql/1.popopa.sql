/*
DROP TABLE setting;
DROP TABLE code;
DROP TABLE usr;
DROP TABLE pos;
DROP TABLE org;
DROP TABLE project;
DROP TABLE team;
DROP TABLE member;
DROP TABLE task;
DROP TABLE note;
DROP TABLE history;
DROP TABLE version;
*/

-- -----------------------------------------------------
-- Table: setting
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS setting (
  user_id        VARCHAR(30) NOT NULL DEFAULT '-',
  setting_key    VARCHAR(30) NOT NULL,
  setting_value  VARCHAR(30) NOT NULL,
  CONSTRAINT pk_setting PRIMARY KEY (user_id, setting_key)
)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8
COLLATE = utf8_general_ci;

-- -----------------------------------------------------
-- Table: code
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS code (
  code_group  VARCHAR(30) NOT NULL DEFAULT '-',
  code_id     VARCHAR(30) NOT NULL,
  code_name   VARCHAR(50) NOT NULL,
  code_sort   INT         NOT NULL DEFAULT 0,
  CONSTRAINT pk_code PRIMARY KEY (code_group, code_id),
  INDEX idx_code (code_sort ASC)
)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8
COLLATE = utf8_general_ci;

-- -----------------------------------------------------
-- Table: usr
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS usr (
  user_id        VARCHAR(45) NOT NULL,
  user_name      VARCHAR(50) NOT NULL,
  user_password  VARCHAR(50) NOT NULL,
  user_level     VARCHAR(3)  NOT NULL,
  user_changed   VARCHAR(20) NOT NULL,  /* YYYY-MM-ddTHH:mm:ss */
  user_retired   VARCHAR(20)     NULL,
  position_id    INT             NULL,
  org_id         INT             NULL,
  CONSTRAINT pk_usr PRIMARY KEY (user_id),
  INDEX idx_usr (user_name ASC, user_retired ASC, position_id ASC, org_id ASC)
)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8
COLLATE = utf8_general_ci;

-- -----------------------------------------------------
-- Table: pos
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS pos (
  position_id    INT         NOT NULL AUTO_INCREMENT,
  position_name  VARCHAR(50) NOT NULL,
  position_sort  INT         NOT NULL DEFAULT 0,
  CONSTRAINT pk_pos PRIMARY KEY (position_id),
  INDEX idx_pos (position_sort ASC)
)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8
COLLATE = utf8_general_ci;

-- -----------------------------------------------------
-- Table: org
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS org (
  org_id      INT         NOT NULL AUTO_INCREMENT,
  org_name    VARCHAR(50) NOT NULL,
  org_parent  INT         NOT NULL DEFAULT 0,
  org_sort    INT         NOT NULL DEFAULT 0,
  CONSTRAINT pk_org PRIMARY KEY (org_id),
  INDEX idx_org (org_sort DESC)
)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8
COLLATE = utf8_general_ci;

-- -----------------------------------------------------
-- Table: team
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS team (
  team_manager     VARCHAR(45) NOT NULL,
  team_engineer    VARCHAR(45) NOT NULL,
  team_createdate  VARCHAR(20) NOT NULL,
  member_status    VARCHAR(10) NOT NULL DEFAULT 'reserved',
  CONSTRAINT pk_team PRIMARY KEY (team_manager, team_engineer),
  INDEX idx_team (member_status ASC)
)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8
COLLATE = utf8_general_ci;

-- -----------------------------------------------------
-- Table: project
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS project (
  project_id    INT          NOT NULL AUTO_INCREMENT,
  project_name  VARCHAR(100) NOT NULL,
  dayoff        INT          NOT NULL DEFAULT 2,
  startdate     VARCHAR( 20) NOT NULL,
  enddate       VARCHAR( 20) NOT NULL,
  project_desc  TEXT             NULL,
  completion    VARCHAR(20)      NULL,
  project_sort  INT          NOT NULL DEFAULT 0,
  CONSTRAINT pk_project PRIMARY KEY (project_id),
  INDEX idx_project (project_sort DESC, project_name ASC)
)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8
COLLATE = utf8_general_ci;

-- -----------------------------------------------------
-- Table: member
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS member (
  group_type   VARCHAR(10) NOT NULL,
  group_id     INT         NOT NULL,
  user_id      VARCHAR(45) NOT NULL,
  member_type  VARCHAR(30) NOT NULL,
  member_sort  INT         NOT NULL DEFAULT 0,
  group_sort   INT         NOT NULL DEFAULT 0,
  CONSTRAINT pk_member PRIMARY KEY (group_type, group_id, user_id),
  INDEX idx_member (member_sort DESC, group_sort DESC)
)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8
COLLATE = utf8_general_ci;

-- -----------------------------------------------------
-- Table: task
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS task (
  project_id   INT          NOT NULL,
  task_id      INT          NOT NULL AUTO_INCREMENT,
  task_name    VARCHAR(100) NOT NULL,
  user_id      VARCHAR( 45)     NULL,
  startdate    VARCHAR( 20)     NULL,
  enddate      VARCHAR( 20)     NULL,
  progress     INT              NULL,
  task_parent  INT          NOT NULL DEFAULT 0,
  task_sort    INT          NOT NULL DEFAULT 0,
  ref_task     INT              NULL,
  CONSTRAINT pk_task PRIMARY KEY (task_id),
  INDEX idx_task (project_id ASC, user_id ASC, startdate ASC, enddate ASC, task_parent ASC, task_sort DESC),
  INDEX idx_ref_task (project_id ASC, task_parent ASC, task_id ASC)
)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8
COLLATE = utf8_general_ci;

-- -----------------------------------------------------
-- Table: note
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS note (
  project_id  INT          NOT NULL,
  task_id     INT          NOT NULL,
  note_id     INT          NOT NULL AUTO_INCREMENT,
  note_name   VARCHAR(100) NOT NULL,
  note_type   VARCHAR( 10) NOT NULL,
  note_desc   TEXT         NOT NULL,
  action      TEXT             NULL,
  completion  VARCHAR(20)      NULL,
  CONSTRAINT pk_note PRIMARY KEY (note_id),
  INDEX idx_note (project_id ASC, task_id ASC)
)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8
COLLATE = utf8_general_ci;

-- -----------------------------------------------------
-- Table: history
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS history (
  history_id    INT         NOT NULL AUTO_INCREMENT,
  project_id    INT         NOT NULL,
  user_id       VARCHAR(45) NOT NULL,
  history_date  TIMESTAMP   NOT NULL DEFAULT NOW(),
  history_type  VARCHAR(30) NOT NULL,
  target_id     VARCHAR(30) NOT NULL,
  target_name   VARCHAR(50) NOT NULL,
  target_crud   VARCHAR(1)  NOT NULL,
  CONSTRAINT pk_history PRIMARY KEY (history_id),
  INDEX idx_history (project_id ASC, history_type ASC)
)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8
COLLATE = utf8_general_ci;

-- -----------------------------------------------------
-- Table: version
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS version (
  version_id    INT         NOT NULL AUTO_INCREMENT,
  version_name  VARCHAR(20) NOT NULL,
  user_id       VARCHAR(45) NOT NULL,
  released      VARCHAR(20) NOT NULL,
  updated       VARCHAR(20) NOT NULL DEFAULT '0',  /* 0: start upgrade, 1: continue after rebooting, YYYY-MM-ddTHH:mm:ss: upgraded date */
  CONSTRAINT pk_version PRIMARY KEY (version_id)
)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8
COLLATE = utf8_general_ci;

/**********************************/
/* auth_level                     */
/**********************************/
INSERT INTO code
       (code_group  , code_id     , code_name   , code_sort)
VALUES ('-'         , 'auth_level', 'Auth level', 0)
     , ('auth_level', 'high'      , 'High'      , 0)  /* Do not notify invalid field. */
     , ('auth_level', 'low'       , 'Low'       , 1); /* Notify invalid field. (ID/Password) */

/**********************************/
/* user_level                     */
/**********************************/
INSERT INTO code
       (code_group  , code_id     , code_name         , code_sort)
VALUES ('-'         , 'user_level', 'User level'      , 0)
     , ('user_level', '9'         , 'PoPoPa Admin'    , 0)  /* admin */
     , ('user_level', '1'         , 'Project Engineer', 2)  /* pe     */
     , ('user_level', '0'         , 'Admin Creator'   , 3); /* admin_creator */

/**********************************/
/* group_type                     */
/**********************************/
INSERT INTO code
       (code_group  , code_id     , code_name      , code_sort)
VALUES ('-'         , 'group_type', 'Group type'   , 0)
     , ('group_type', 'project'   , 'Project group', 0)
     , ('group_type', 'team'      , 'Team group'   , 1);

/**********************************/
/* member_type                    */
/**********************************/
INSERT INTO code
       (code_group   , code_id      , code_name    , code_sort)
VALUES ('-'          , 'member_type', 'Member type', 0)
     , ('member_type', 'manager'    , 'Manager'    , 0)
     , ('member_type', 'engineer'   , 'Engineer'   , 1);

/**********************************/
/* team_status                    */
/**********************************/
INSERT INTO code
       (code_group     , code_id        , code_name      , code_sort)
VALUES ('-'            , 'member_status', 'Member status', 0)
     , ('member_status', 'reserved'     , 'Reserved'     , 0)
     , ('member_status', 'included'     , 'Included'     , 1)
     , ('member_status', 'excluded'     , 'Excluded'     , 2);

/**********************************/
/* note_type                      */
/**********************************/
INSERT INTO code
       (code_group , code_id    , code_name  , code_sort)
VALUES ('-'        , 'note_type', 'Note type', 0)
     , ('note_type', 'memo'     , 'Memo'     , 0)
     , ('note_type', 'issue'    , 'Issue'    , 1);

/**********************************/
/* anchor_week                    */
/**********************************/
INSERT INTO code
       (code_group   , code_id      , code_name      , code_sort)
VALUES ('-'          , 'anchor_week', 'Base week'    , 0)
     , ('anchor_week', 'prev'       , 'Previous week', 0)
     , ('anchor_week', 'curr'       , 'Current week' , 1)
     , ('anchor_week', 'auto'       , 'Auto'         , 2);

/**********************************/
/* anchor_month                   */
/**********************************/
INSERT INTO code
       (code_group    , code_id       , code_name       , code_sort)
VALUES ('-'           , 'anchor_month', 'Base month'    , 0)
     , ('anchor_month', 'prev'        , 'Previous month', 0)
     , ('anchor_month', 'curr'        , 'Current month' , 1)
     , ('anchor_month', 'auto'        , 'Auto'          , 2);

/**********************************/
/* report_user                   */
/**********************************/
INSERT INTO code 
       (code_group   , code_id      , code_name                     , code_sort)
VALUES ('-'          , 'report_user', 'Task of team members'        , 0)
     , ('report_user', 'member'     , 'Include task of team members', 0)
     , ('report_user', 'alone'      , 'Exclude task of team members', 1);

/**********************************/
/* history_type                   */
/**********************************/
INSERT INTO code 
       (code_group    , code_id       , code_name     , code_sort)
VALUES ('-'           , 'history_type', 'History type', 0)
     , ('history_type', 'user'        , 'User'        , 0)
     , ('history_type', 'project'     , 'Project'     , 1)
     , ('history_type', 'task'        , 'Task'        , 2)
     , ('history_type', 'weekly'      , 'weekly'      , 3)
     , ('history_type', 'monthly'     , 'Monthly'     , 4);

/**********************************/
/* Initial Setting Value          */
/**********************************/
INSERT INTO setting
       (user_id, setting_key                    , setting_value)
VALUES ('-'    , 'lang'                         , 'auto'   )
     , ('-'    , 'use_init_admin'               , 'true'   )
     , ('-'    , 'update_account'               , 'false'  )
     , ('-'    , 'sync_setting'                 , 'false'  )
     , ('-'    , 'dayoff'                       , '2'      )
     , ('-'    , 'use_org'                      , 'false'  )
     , ('-'    , 'exclude_admin'                , 'true'   )
     , ('-'    , 'auth_level'                   , 'high'   )
     , ('-'    , 'anchor_week'                  , 'auto'   )
     , ('-'    , 'anchor_month'                 , 'auto'   )
     , ('-'    , 'report_user'                  , 'member' )
     , ('-'    , 'display_user'                 , 'false'  )
     , ('-'    , 'start_page'                   , 'gantt'  )
     , ('-'    , 'next_step_of_creating_project', 'project');

/****************************************************************************/
/* The initial account information for createing administrator only         */
/* -- Important: DO NOT EDIT THIS ACCOUNT --                                */
/****************************************************************************/
INSERT INTO usr
       (user_id   , user_name        , user_password, user_level, user_changed                    , user_retired, position_id, org_id)
values ('${admin}', 'PoPoPa Customer', '${admin}'   , '0'       , DATE_FORMAT(NOW(),'%Y-%m-%dT%T'), NULL        , NULL       , NULL);
