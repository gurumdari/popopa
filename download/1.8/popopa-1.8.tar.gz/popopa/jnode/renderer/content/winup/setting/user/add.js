$content$.winup.setting.user.add = {
	service: function() {
		var that       = this;
		var parentNode = this.conf.parentNode;
		var userType   = this.dataset.userType;
		var regist     = this.dataset.regist;

		var positionList   = $content$.article.setting[parentNode].dataset.positionList;
		var positionSelect = document.userForm.user_position;
		var userTbody      = document.querySelector("aside.grid > div > table > tbody");
		var alertNode      = document.userForm.querySelector("form > ul.submit > li.alert");

		for (var i = 0; i < positionList.length; i++) {
			positionSelect.options.add(new Option(positionList[i].position_name, positionList[i].position_id));
		}

		positionSelect.options[positionList.length - 1].selected = true;

		document.userForm.querySelector("form > ul.submit > li > button").addEventListener("click", function(event) {
			var syndicationUrl = "/ajax/user.json";

			var params = {
				command:       "addUser",
				user_name:     document.userForm.user_name.value.trim(),
				user_id:       document.userForm.user_id.value.trim(),
				user_password: document.userForm.user_password.value,
				position_id:   positionSelect.value,
				position_name: positionSelect.options[positionSelect.selectedIndex].text
			};

			if (regist) {
				params.command       = "registAdmin";
				params.exclude_admin = "true";

				syndicationUrl = "/ajax/regist.json";
			} else {
				params.command = "addUser";
			}

			if (parentNode == "admin")  params.user_level = "9";
			else                        params.user_level = "1";

			if (that.conf.org_id)  params.org_id = that.conf.org_id;

			var confirmPassword = document.userForm.confirm_password.value;
			var alertMessage    = null;

			if (params.user_name == "") {
				alertMessage = i18n["alert_input_" + userType + "_name"];
				document.userForm.user_name.select();
			} else if (params.user_id == "") {
				alertMessage = i18n["alert_input_" + userType + "_id"];
				document.userForm.user_id.select();
			} else if (params.user_id == "-") {
				alertMessage = i18n["alert_invalid_" + userType + "_char"];
				document.userForm.user_id.select();
			} else if (!/^[\w|\.|\-]+$/g.test(params.user_id)) {
				alertMessage = i18n["alert_invalid_" + userType + "_id"];
				document.userForm.user_id.select();
			} else if (params.user_id.length > 30) {
				alertMessage = i18n["alert_maxlength_" + userType + "_id"];
				document.userForm.user_id.select();
			} else if (params.user_password == "") {
				alertMessage = i18n.alert_input_password;
				document.userForm.user_password.focus();
			} else if (params.user_password != confirmPassword) {
				alertMessage = i18n.alert_different_password;
				document.userForm.confirm_password.select();
			}

			if (alertMessage) {
				alertNode.innerHTML = alertMessage;
			} else {
				$controller$.loading.show();

				$jnode$.ajax.service({
					"url":      syndicationUrl,
					"method":   "POST",
					"datatype": "json",
					"headers": {
						"Content-Type": "application/json",
						"Accept":       "application/json"
					},
					"params":  params,
					"success": function(response) {
						if (regist) {
							document.location.href = $jnode$.contextPath + "/auth/relogin.html";
						} else {
							$content$.article.setting[parentNode].appendUserRow(userTbody, params);
							$controller$.grid.clear("thead");
							$controller$.grid.moveBottom();
							userTbody.lastElementChild.click();

							startId = response.start_id;
							if (response.alert_precondition_required)  alert_precondition_required = response.alert_precondition_required;

							$controller$.winup.close();
							$controller$.loading.hide();
						}
					},
					"error": function(error) {
						$jnode$.ajax.alertError(error, [
							{"code":"409", "message":"-" , "callback":function() { alertNode.innerHTML = i18n["alert_already_" + userType + "_id"]; document.userForm.user_id.select(); }}
						]);

						$controller$.loading.hide();
					}
				});
			}
		}, false);

		document.userForm.user_name.focus();
	}
};