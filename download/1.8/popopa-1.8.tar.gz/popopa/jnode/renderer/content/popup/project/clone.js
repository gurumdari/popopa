$content$.popup.project.clone = {
	resize: function() {
		var windowWidth = window.innerWidth;

		if (windowWidth > 687) {
			$controller$.popup.resize(648);
		} else {
			$controller$.popup.widthP(100);
		}
	},

	service: function() {
		window.addEventListener("resize", this.resize, false);
		this.resize();

		var workerInfo        = this.dataset.workerInfo;
		var cloneMemberSelect = document.cloneForm.clone_member;
		var memberButton      = cloneMemberSelect.parentNode.nextElementSibling.firstElementChild;
		var nextStep          = this.dataset.next_step_of_creating_project;

		var memberRow   = document.querySelector("aside.popup article > div.popup > form > table.form > tbody > tr.member");
		var memberTable = memberRow.querySelector("tr.member > td > table");
		var memberTbody = memberTable.lastElementChild;
		var leaderCell  = memberTable.querySelector("table > thead > tr > td:last-child");
		var okButton    = document.querySelector("aside.popup article > div.popup > form > ul.submit > li:last-child > button");

		leaderCell.style.width = (leaderCell.offsetWidth - 4) + "px";
		memberTable.style.tableLayout = "fixed";

		// worker
		var workerRow          = memberRow.nextElementSibling;
		var workerTbody        = workerRow.querySelector("td > table > tbody");
		var includedMemberList = this.dataset.includedMemberList;
		var excludedMemberList = this.dataset.excludedMemberList;
		var memberList         = this.dataset.memberList;
		var useOrg             = this.dataset.use_org;

		function appendWorker(workerInfo) {
			var userId    = workerInfo.user_id;
			var isRetiree = (userId.search(/^[$][{].+[}]$/) == 0);
			var userInfo  = (isRetiree ? i18n.label_retiree + ": " : "") + workerInfo.user_name + " (" + (isRetiree ? userId.substring(13, userId.length - 1) : userId) + " / " + workerInfo.position_name + ")";
			if (useOrg)  userInfo += " @ " + workerInfo.org_name;

			var tr = document.createElement("tr");
			workerTbody.appendChild(tr);

			var th = document.createElement("th");
			th.appendChild(document.createTextNode(userInfo));
			tr.appendChild(th);

			if (isRetiree)  th.setAttribute("class", "retiree");

			var td = document.createElement("td");
			td.setAttribute("class", "select");
			tr.appendChild(td);

			var select = document.createElement("select");
			select.setAttribute("name", userId);
			td.appendChild(select);
		}

		for (var i = 0; i < includedMemberList.length; i++) {
			appendWorker(includedMemberList[i]);
		}

		for (var i = 0; i < excludedMemberList.length; i++) {
			appendWorker(excludedMemberList[i]);
		}

		var workerSelects = workerTbody.querySelectorAll("tbody > tr > td > select");

		var firstOldWorkerTh = workerTbody.querySelector("tbody > tr > th");
		if (firstOldWorkerTh) {
			if (firstOldWorkerTh.offsetWidth > 259) {
				workerTbody.parentNode.setAttribute("class", "block");
			}
		}

		memberButton.disabled     = true;
		memberTable.style.display = "none";
		workerRow.style.display   = "none";

		cloneMemberSelect.addEventListener("change", function(event) {
			if (this.value == "equally") {
				memberButton.disabled         = true;
				memberTable.style.display     = "none";
				workerRow.style.display       = "none";
			} else {
				memberButton.disabled         = false;
				memberTable.style.removeProperty("display");

				if (workerTbody.children.length)  workerRow.removeAttribute("style");
			}
		}, false);

		var projectInfo = $content$.article.project.edit.dataset.projectInfo;
		var taskPeriod  = $content$.article.project.edit.dataset.taskPeriod;
		var startdate   = null;
		var enddate     = null;

		if (taskPeriod && taskPeriod.min_startdate) {
			startdate = taskPeriod.min_startdate;
			enddate   = taskPeriod.max_enddate;
		} else {
			startdate = projectInfo.startdate;
			enddate   = projectInfo.enddate;
		}

		var startDate = dateUtil.parse(startdate);
		var endDate   = dateUtil.parse(enddate);
		var todaydate = dateUtil.format(new Date());
		var todayDate = dateUtil.parse(todaydate);
		var startTime = startDate.getTime() / 86400000;  // 24 * 60 * 60 * 1000
		var endTime   = endDate.getTime() / 86400000;

		var period    = endTime - startTime;
		var lastDate  = dateUtil.toDate(todayDate, period);
		var lastdate  = dateUtil.format(lastDate);

		var startdateSpan     = document.querySelector("aside.popup article > div.popup > form > table.form > tbody > tr:nth-child(3) > td > div > span:first-of-type");
		var enddateSpan       = startdateSpan.nextElementSibling;
		var periodSpan        = enddateSpan.nextElementSibling;
		var calendarPeriodUl  = startdateSpan.parentNode.nextElementSibling.firstElementChild;
		var startdateCalendar = calendarPeriodUl.querySelector("ul.calendar_period > li:first-child > div > ul > li > div > div.calendar");
		var enddateCalendar   = calendarPeriodUl.querySelector("ul.calendar_period > li:last-child > div > ul > li > div > div.calendar");
		var historyCalendarCallback = null;

		periodSpan.innerHTML = (period + 1);

		startdateSpan.innerHTML = dateFormatter.format(todayDate, dateFormatter.DateStyle.LONG) + "<FONT>" + todaydate + "</FONT>";
		enddateSpan.innerHTML   = dateFormatter.format(lastDate, dateFormatter.DateStyle.LONG) + "<FONT>" + lastdate + "</FONT>";

		function setStartdate() {
			startdateCalendar.nextElementSibling.click();

			var mindate = startdateSpan.firstElementChild.innerHTML;
			var maxDate = dateUtil.toDate(dateUtil.parse(mindate), period);
			var maxdate = dateUtil.format(maxDate);
			enddateSpan.innerHTML = dateFormatter.format(maxDate, dateFormatter.DateStyle.LONG) + "<FONT>" + maxdate + "</FONT>";

			displayCalendar(maxDate, "date", enddateSpan, enddateCalendar, maxdate, setEnddate);
		}

		function setEnddate() {
			enddateCalendar.nextElementSibling.click();

			var maxdate = enddateSpan.firstElementChild.innerHTML;
			var minDate = dateUtil.toDate(dateUtil.parse(maxdate), period * -1);
			var mindate = dateUtil.format(minDate);
			startdateSpan.innerHTML = dateFormatter.format(minDate, dateFormatter.DateStyle.LONG) + "<FONT>" + mindate + "</FONT>";

			displayCalendar(minDate, "date", startdateSpan, startdateCalendar, mindate, setStartdate);
		}

		displayCalendar(todayDate, "date", startdateSpan, startdateCalendar, todaydate, setStartdate);
		displayCalendar(lastDate, "date", enddateSpan, enddateCalendar, lastdate, setEnddate);

		startdateSpan.addEventListener("click", function(event) {
			if (window.innerWidth < 737) {
				enddateCalendar.nextElementSibling.click();
				startdateCalendar.parentNode.parentNode.parentNode.parentNode.setAttribute("class", "popup");

				if (isPhone) {
					document.body.style.overflow = "hidden";

					historyCalendarCallback = $jnode$.node.pushPseudoHistory(function() {
						startdateCalendar.nextElementSibling.click();
					});
				}
			}
		}, false);

		enddateSpan.addEventListener("click", function(event) {
			if (window.innerWidth < 737) {
				startdateCalendar.nextElementSibling.click();
				enddateCalendar.parentNode.parentNode.parentNode.parentNode.setAttribute("class", "popup");

				if (isPhone) {
					document.body.style.overflow = "hidden";

					historyCalendarCallback = $jnode$.node.pushPseudoHistory(function() {
						enddateCalendar.nextElementSibling.click();
					});
				}
			}
		}, false);

		startdateCalendar.nextElementSibling.addEventListener("click", function(event) {
			this.parentNode.parentNode.parentNode.parentNode.removeAttribute("class");
			if (isPhone)  document.body.style.removeProperty("overflow");
			if (historyCalendarCallback)  historyCalendarCallback();
		}, false);

		enddateCalendar.nextElementSibling.addEventListener("click", function(event) {
			this.parentNode.parentNode.parentNode.parentNode.removeAttribute("class");
			if (isPhone)  document.body.style.removeProperty("overflow");
			if (historyCalendarCallback)  historyCalendarCallback();
		}, false);

		memberButton.addEventListener("click", function(event) {
			var winupContentId = "/member/user";
			if (useOrg)  winupContentId = "/member/org";

			$jnode$.requireContent("winup", winupContentId, {
				useLoading: true,
				icon:       true,
				title:      i18n.label_select_member,
				width:      705,
				height:     360,
				unload:     true
			});
		}, false);

		$jnode$.storage.eventhandler4import = {
			open: function() {
				var memberList  = [];
				var memberCells = memberTbody.querySelectorAll("tbody > tr > td:first-child");

				for (var i = 0; i < memberCells.length; i++) {
					var memberData = {
						user_id:       memberCells[i].parentNode.getAttribute("id"),
						user_name:     memberCells[i].querySelector("td > span:first-of-type").firstChild.nodeValue,
						position_name: memberCells[i].querySelector("td > span:nth-of-type(3)").firstChild.nodeValue,
						position_id:   memberCells[i].querySelector("td > font:first-of-type").firstChild.nodeValue
					};

					if (useOrg) {
						memberData.org_name = memberCells[i].querySelector("td > span:last-of-type").firstChild.nodeValue;
						memberData.org_id   = memberCells[i].querySelector("td > font:last-of-type").firstChild.nodeValue;
					}

					memberList.push(memberData);
				}

				if (memberList.length == 0) {
					if (workerInfo)  memberList.push(workerInfo);
				}

				return memberList;
			},

			ok: function(datas, close) {
				var checkedValue = null;
				var checkedInput = memberTbody.querySelector("tbody > tr > td > input:checked");
				var dataCount    = datas.length;

				if (checkedInput) {
					checkedValue = checkedInput.value;
				}

				memberTbody.innerHTML = "";

				for (var j = 0; j < workerSelects.length; j++) {
					workerSelects[j].innerHTML = "";
					workerSelects[j].options.add(new Option(i18n.label_specify_worker, "", false, false));
				}

				for (var i = 0; i < datas.length; i++) {
					var userId = datas[i].user_id;
					var isRetiree = (userId.search(/^[$][{].+[}]$/) == 0);
					var row = document.createElement("tr");
					row.setAttribute("id", userId);
					memberTbody.appendChild(row);

					var orgInfo    = "";
					var orgOptInfo = "";

					if (useOrg) {
						orgInfo    = " @ <SPAN>" + $jnode$.escapeXML(datas[i].org_name) + "</SPAN><FONT>" + datas[i].org_id + "</FONT>";
						orgOptInfo = " @ " + $jnode$.escapeXML(datas[i].org_name);
					}

					var memberCell = row.insertCell(0);
					memberCell.innerHTML = (isRetiree ? i18n.label_retiree + ": " : "") + "<SPAN>" + $jnode$.escapeXML(datas[i].user_name) + "</SPAN> (<SPAN>" + $jnode$.escapeXML(isRetiree ? userId.substring(13, userId.length - 1) : userId) + "</SPAN> / <SPAN>" + $jnode$.escapeXML(datas[i].position_name) + "</SPAN><FONT>" + datas[i].position_id + "</FONT>)" + orgInfo;

					if (isRetiree)  memberCell.setAttribute("class", "retiree");

					var managerInput = document.createElement("input");
					managerInput.setAttribute("type", "radio");
					managerInput.setAttribute("name", "manager");
					managerInput.value = userId;

					if (datas[i].member_type == "manager")  managerInput.checked = true;

					var managerCell = row.insertCell(1);
					managerCell.appendChild(managerInput);

					for (var j = 0; j < workerSelects.length; j++) {
						workerSelects[j].options.add(new Option((isRetiree ? i18n.label_retiree + ": " : "") + $jnode$.escapeXML(datas[i].user_name) + " (" + $jnode$.escapeXML(isRetiree ? userId.substring(13, userId.length - 1) : userId) + " / " + $jnode$.escapeXML(datas[i].position_name) + ")" + orgOptInfo, userId, false, false));
					}
				}

				if (checkedValue) {
					var checkedMember = memberTbody.querySelector("tbody > tr > td > input[value='" + checkedValue + "']");
					if (checkedMember)  checkedMember.checked = true;
				}

				if (close)  close();
			}
		};

		$jnode$.storage.eventhandler4import.ok([]);
		document.cloneForm.project_name.select();

		okButton.addEventListener("click", function(event) {
			var alertMessage = null;

			var params = {
				command:      "createProject",
				source_id:    projectInfo.project_id,
				project_name: document.cloneForm.project_name.value,
				clone_range:  document.cloneForm.clone_range.value,
				dayoff:       projectInfo.dayoff,
				startdate:    startdateSpan.firstElementChild.innerHTML,
				enddate:      enddateSpan.firstElementChild.innerHTML,
				clone_member: cloneMemberSelect.value
			};

			if (params.project_name == "") {
				alertMessage = i18n.alert_input_project_name;
				document.cloneForm.project_name.focus();
			} else if (params.clone_member == "newly") {
				var memberIds  = [];
				var memberRows = memberTbody.querySelectorAll("tbody > tr");

				for (var i = 0; i < memberRows.length; i++) {
					memberIds.push(memberRows[i].getAttribute("id"));
				}

				if (memberIds.length == 0) {
					alertMessage = i18n.alert_select_project_member;
					memberButton.focus();
				} else {
					params.user_id = JSON.stringify(memberIds);

					if (memberIds.length == 1) {
						params.manager = memberIds[0];
					} else {
						var checkedInput = memberTbody.querySelector("tbody > tr > td > input:checked");
						if (checkedInput)  params.manager = checkedInput.value;
						else               alertMessage = i18n.alert_select_project_manager;
					}
				}

				if (alertMessage == null) {
					var replacedUsers = [];

					for (var i = 0; i < workerSelects.length; i++) {
						var userId    = workerSelects[i].getAttribute("name");
						var newUserId = workerSelects[i].value;

						if (newUserId) {
							if (userId != newUserId) {
								replacedUsers.push({
									user_id:     userId,
									new_user_id: newUserId
								});
							}
						} else {
							alertMessage = "지정 안된 일감 작업자가 있습니다.";
							workerSelects[i].focus();
							break;
						}
					}

					params.replacedUsers = JSON.stringify(replacedUsers);
				}
			} else {
				var memberIds  = [];

				for (var i = 0; i < memberList.length; i++) {
					memberIds.push(memberList[i].user_id);

					if (memberList[i].member_type == "manager") {
						params.manager = memberList[i].user_id;
					}
				}

				params.user_id = JSON.stringify(memberIds);
			}

			if (alertMessage) {
				this.parentNode.previousElementSibling.innerHTML = alertMessage;
			} else {
				$controller$.loading.show();

				var newStartDate = dateUtil.parse(params.startdate);
				var diffPeriod   = newStartDate.getTime() / 86400000 - startTime;
				var dayoff       = parseInt(params.dayoff);

				if ((diffPeriod == 0) || (Math.abs(diffPeriod) % 7 == 0)) {
					params.task_dayoff = "0";
				} else {
					params.task_dayoff = params.dayoff;
					params.old_enddate = startdate;

					diffPeriod = getDiffPeriod(startDate, newStartDate, dayoff);
				}

				params.diff_period = diffPeriod;

				$jnode$.ajax.service({
					"url":      "/ajax/project.json",
					"method":   "POST",
					"datatype": "json",
					"headers": {
						"Content-Type": "application/json",
						"Accept":       "application/json"
					},
					"params":  params,
					"success": function(response) {
						$controller$.popup.close();
						var projectId = response.project_id;

						if (projectId == 0) {
							// 다시 생성하는 화면으로...
							document.querySelector("body > section > div.section > nav > fieldset > ul > li > div > ul > li:first-child > ul > li:first-child > button:first-child").click();
						} else {
							startId = response.start_id;
							alert_precondition_required = null;

							params.project_id = projectId;
							
							if (nextStep == "project") {
								$content$.section.project.appendProject(params, null, true);
							} else {
								document.querySelector("body > nav > ul > li > label > input[name='section_menu'][value='/gantt']").click();
							}
						}
					},
					"error": function(error) {
						$jnode$.ajax.alertError(error);
						$controller$.loading.hide();
					}
				});
			}
		}, false);
	},

	unload: function() {
		delete $jnode$.storage.eventhandler4import;
		window.removeEventListener("resize", this.resize, false);
	}
}