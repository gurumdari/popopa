$content$.helpsection.en.setting.menu = {
	service: function() {
		menuClassDiv.innerHTML = document.querySelector("body > nav > div > div ul > li > label > input:checked + span").innerHTML;
		$jnode$.pushHistory(this.conf);
	}
};
