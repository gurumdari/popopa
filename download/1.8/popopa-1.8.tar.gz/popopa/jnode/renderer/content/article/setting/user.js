$content$.article.setting.user = {
	posSortMap: {},

	appendUserRow: function(userTbody, userData) {
		var row = document.createElement("tr");
		userTbody.appendChild(row);

		var nameCell = row.insertCell(0);
		nameCell.appendChild(document.createTextNode(userData.user_name));

		var idCell = row.insertCell(1);
		idCell.appendChild(document.createTextNode(userData.user_id));

		var positionCell = row.insertCell(2);
		positionCell.appendChild(document.createTextNode(userData.position_name));
		positionCell.setAttribute("id", userData.position_id);
		positionCell.setAttribute("sid", $content$.article.setting.user.posSortMap[userData.position_id.toString()]);

		row.addEventListener("click", function(event) {
			var selectedRow = userTbody.querySelector("tbody > tr.selected");
			if (selectedRow)  selectedRow.removeAttribute("class");

			this.setAttribute("class", "selected");
			document.querySelector("div.section > article > div.article > fieldset > ul > li:last-child > button:nth-child(2)").disabled = false;
			document.querySelector("div.section > article > div.article > fieldset > ul > li:last-child > button:last-child").disabled = false;
		}, false);
	},

	resize: function() {
		var windowWidth  = window.innerWidth;
		var windowHeight = window.innerHeight;

		if (windowWidth > 736) {
			$controller$.grid.resize(null, windowHeight - 143);  // 43 + 30 + 10 + 37 + 10 + 10 + 18
		} else {
			$controller$.grid.removeHeight();
		}

		$controller$.grid.resizeScrollButtons();
	},

	service: function() {
		$controller$.loading.show();
		var that = this;
		$jnode$.pushHistory(that.conf);

		var positionList = this.dataset.positionList;

		function lpad(sortIndex) {
			if (sortIndex < 10) {
				return "0" + sortIndex.toString();
			} else {
				return sortIndex.toString();
			}
		}

		for (var i = 0; i < positionList.length; i++) {
			this.posSortMap[positionList[i].position_id.toString()] = lpad(i);
		}

		$jnode$.requireController("grid", {caller:that.conf}).on(function() {
			$controller$.grid.service({sortable:true});
			window.addEventListener("resize", that.resize, false);
			that.resize();

			var useOrgSelect   = document.querySelector("div.section > article > div.article > fieldset > ul > li:first-child > select");
			var addButton      = document.querySelector("div.section > article > div.article > fieldset > ul > li:last-child > button:first-child");
			var editButton     = document.querySelector("div.section > article > div.article > fieldset > ul > li:last-child > button:nth-child(2)");
			var passwordButton = document.querySelector("div.section > article > div.article > fieldset > ul > li:last-child > button:last-child");
			var userTbody      = document.querySelector("aside.grid > div > table > tbody");
			var userList       = that.dataset.userList;

			editButton.disabled     = true;
			passwordButton.disabled = true;

			for (var i = 0; i < userList.length; i++) {
				that.appendUserRow(userTbody, userList[i]);
			}

			$controller$.loading.hide();

			useOrgSelect.addEventListener("change", function(event) {
				if (that.dataset.emptyCompanyInfo) {
					$jnode$.requireContent("winup", "/setting/org/company", {
						useLoading: true,
						icon:       true,
						title:      i18n.label_set_company_name,
						width:      420,
						height:     119,
						open:       true,
						renderer:   "-j"
					});

					$controller$.winup.open(null, function(close) {
						useOrgSelect.value = "false";
						close();
					});
				} else {
					$controller$.loading.show();

					$jnode$.ajax.service({
						"url":      "/ajax/org.json",
						"method":   "POST",
						"datatype": "json",
						"headers": {
							"Content-Type": "application/json",
							"Accept":       "application/json"
						},
						"params":  {
							command: "changeUsingOrg",
							use_org: "true"
						},
						"success": function(response) {
							setUserSettingMenu(true);
							document.querySelector("body > section > div.section > nav > div:last-child > fieldset > div > ul > li > label > input[name='article_menu'][value='/setting/org']").click();
						},
						"error": function(error) {
							$jnode$.ajax.alertError(error);
							$controller$.loading.hide();
						}
					});
				}
			}, false);

			addButton.addEventListener("click", function(event) {
				$jnode$.requireContent("winup", "/setting/user/add", {
					useLoading: true,
					icon:       true,
					title:      i18n.label_add_user,
					width:      420,
					height:     310,
					renderer:   "-j",
					parentNode: "user"
				});
			}, false);

			editButton.addEventListener("click", function(event) {
				$jnode$.requireContent("winup", "/setting/user/edit", {
					useLoading: true,
					icon:       true,
					title:      i18n.label_edit_user,
					width:      420,
					height:     248,
					renderer:   "-j",
					parentNode: "user"
				});
			}, false);

			passwordButton.addEventListener("click", function(event) {
				$jnode$.requireContent("winup", "/setting/user/password_reset", {
					useLoading: true,
					icon:       true,
					title:      i18n.label_reset_password,
					width:      420,
					height:     150,
					renderer:   "-j"
				});
			}, false);
		});
	},

	unload: function() {
		window.removeEventListener("resize", this.resize, false);
	}
};