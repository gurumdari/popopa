if (window.history.pushState && (document.location.pathname == $jnode$.contextPath + "/auth/relogin.html")) {
	window.history.pushState(null, null, $jnode$.contextPath + "/");
}

var alertDiv = document.querySelector("article > div.article > form > div");

alertI18n = JSON.parse($module$.base64.decode(alertI18n));

function callLogin() {
	var alertMessage = null;

	var params = {
		command:  "login",
		user_id:  document.loginForm.user_id.value.trim(),
		password: document.loginForm.password.value,
		stateful: (document.loginForm.stateful.checked ? "Y" : "N")
	};

	if (params.user_id == "") {
		alertMessage = alertI18n.alert_input_user_id;
		document.loginForm.user_id.select();
	} else if (params.password == "") {
		alertMessage = alertI18n.alert_input_password;
		document.loginForm.password.focus();
	}

	if (alertMessage) {
		alertDiv.innerHTML = alertMessage;
	} else {
		$controller$.loading.show();

		$jnode$.ajax.service({
			"url":      "/ajax/auth.json",
			"method":   "POST",
			"datatype": "json",
			"headers": {
				"Content-Type": "application/json",
				"Accept":       "application/json"
			},
			"params":  params,
			"success": function(response) {
				document.location.reload();
			},
			"error": function(error) {
				$jnode$.ajax.alertError(error, [
					{"code":"401", "message":"-", "callback":function() {
						alertDiv.innerHTML = error.error_message;

						if (error.debug_message == "Wrong password")  document.loginForm.password.select();
						else                                          document.loginForm.user_id.select();
					}}
				]);

				$controller$.loading.hide();
			}
		});
	}
}

document.loginForm.user_id.addEventListener("keydown", function(event) {
	var keyCode = event.keyCode || event.which;

	if(keyCode == 13) {
		if (document.loginForm.user_id.value.trim() == "") {
			alertDiv.innerHTML = alertI18n.alert_input_user_id;
			document.loginForm.user_id.select();
		} else {
			alertDiv.innerHTML = "";
			event.preventDefault();
			document.loginForm.password.focus();
		}
	}
}, false);

document.loginForm.password.addEventListener("keydown", function(event) {
	var keyCode = event.keyCode || event.which;

	if(keyCode == 13) {
		event.preventDefault();
		callLogin();
	}
}, false);

document.querySelector("article > div.article > form > table > tbody > tr > td:nth-child(3) > button").addEventListener("click", function(event) {
	callLogin();
}, false);

document.loginForm.user_id.focus();