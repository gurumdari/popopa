function moveLang(lang) {
	$controller$.loading.show();
	document.langForm.lang.value = lang;
	document.langForm.submit();
}

document.langForm.lang.addEventListener("change", function(event) {
	$controller$.loading.show();
	document.langForm.submit();
}, false);