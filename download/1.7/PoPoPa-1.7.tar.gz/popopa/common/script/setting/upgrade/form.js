if (window.parent.stopRefresh300)  window.parent.stopRefresh300();

if (resultMessage) {
	resultMessage = $module$.base64.decode(resultMessage);
	window.parent.$controller$.winup.close();

	if (resultMessage == "SUCCESS") {
		window.parent.handleHash("#article:/setting/about");
	} else {
		window.parent.$controller$.prompt.alert(resultMessage, null, true);
		window.parent.$controller$.loading.hide();
	}
} else {
	window.parent.$controller$.loading.hide();
}

alertSelectPuzFile = $module$.base64.decode(alertSelectPuzFile);
window.parent.alertOvertime = $module$.base64.decode(alertOvertime);

document.querySelector("body > form > ul > li:last-child > button").addEventListener("click", function(event) {
	var puzValue = document.upgradeForm.puz.value;

	if (puzValue.search(/\.puz$/i) < 0) {
		this.parentNode.previousElementSibling.innerHTML = alertSelectPuzFile;
	} else {
		window.parent.refresh300();  // 5분이 지나도 로딩중이면 강제로 종료
		window.parent.$controller$.loading.show();
		window.parent.document.querySelector("body > aside.winup.open").setAttribute("class", "winup");
		document.upgradeForm.submit();
	}
}, false);