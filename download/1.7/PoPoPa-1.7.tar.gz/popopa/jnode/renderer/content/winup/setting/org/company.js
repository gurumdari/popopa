$content$.winup.setting.org.company = {
	service: function() {
		document.companyForm.querySelector("form > ul.submit > li > button").addEventListener("click", function(event) {
			var alertMessage = "";
			var alertNode = this.parentNode.previousElementSibling;

			if (document.companyForm.org_name.value == "") {
				alertMessage = i18n.alert_input_company_name;
				document.companyForm.org_name.focus();
			}

			if (alertMessage) {
				alertNode.innerHTML = alertMessage;
			} else {
				$controller$.loading.show();

				$jnode$.ajax.service({
					"url":      "/ajax/org.json",
					"method":   "POST",
					"datatype": "json",
					"headers": {
						"Content-Type": "application/json",
						"Accept":       "application/json"
					},
					"params":  {
						command:  "addCompany",
						org_name: document.companyForm.org_name.value
					},
					"success": function(response) {
						$controller$.winup.close();
						setUserSettingMenu(true);
						$content$.article.setting.user.dataset.emptyCompanyInfo = false;
						document.querySelector("body > section > div.section > nav > div:last-child > fieldset > div > ul > li > label > input[name='article_menu'][value='/setting/org']").click();
					},
					"error": function(error) {
						$jnode$.ajax.alertError(error);
						$controller$.loading.hide();
					}
				});
			}
		}, false);

		document.companyForm.org_name.focus();
	}
};