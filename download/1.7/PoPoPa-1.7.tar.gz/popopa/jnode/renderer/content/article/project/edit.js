$content$.article.project.edit = {
	service: function() {
		var that = this;
		$jnode$.pushHistory(that.conf);

		var memberTable = document.querySelector("article > div.article > form > table.form > tbody > tr.member > td > table");
		var leaderCell  = memberTable.querySelector("table > thead > tr > td:last-child");
		leaderCell.style.width = (leaderCell.offsetWidth - 4) + "px";
		memberTable.style.tableLayout = "fixed";

		var matchTaskPeriodDiv = document.querySelector("article > div.article > form > table.form > tbody > tr > td.period > div:last-child");
		var projectInfo  = that.dataset.projectInfo;
		var taskPeriod   = that.dataset.taskPeriod;
		var startdate    = projectInfo.startdate;
		var enddate      = projectInfo.enddate;
		var startDate    = dateUtil.parse(startdate);
		var endDate      = dateUtil.parse(enddate);
		var minStartdate = "";
		var maxEnddate   = "";

		if (taskPeriod) {
			minStartdate = taskPeriod.min_startdate;
			maxEnddate   = taskPeriod.max_enddate;

			var minStartdateSpan = matchTaskPeriodDiv.firstElementChild.firstElementChild;
			var maxEnddateSpan   = minStartdateSpan.nextElementSibling;

			minStartdateSpan.innerHTML = $jnode$.escapeXML(dateFormatter.format(dateUtil.parse(minStartdate), dateFormatter.DateStyle.MEDIUM));
			maxEnddateSpan.innerHTML   = $jnode$.escapeXML(dateFormatter.format(dateUtil.parse(maxEnddate), dateFormatter.DateStyle.MEDIUM));
		}

		function showMatchTaskPeriod(mindate, maxdate) {
			if (minStartdate && (minStartdate < mindate || maxEnddate > maxdate)){
				matchTaskPeriodDiv.setAttribute("class", "show");
			} else {
				matchTaskPeriodDiv.setAttribute("class", "hide");
			}
		}

		if (minStartdate && (minStartdate < startdate || maxEnddate > enddate)){
			matchTaskPeriodDiv.setAttribute("class", "show");
		}

		var projectContainer  = document.querySelector("body > section > div.section > nav > fieldset > ul > li > div > ul > li:last-child > div");
		var startdateSpan     = document.querySelector("article > div.article > form > table.form > tbody > tr:nth-child(2) > td > div > span:first-of-type");
		var enddateSpan       = document.querySelector("article > div.article > form > table.form > tbody > tr:nth-child(2) > td > div > span:nth-of-type(2)");
		var startdateCalendar = document.querySelector("ul.calendar_period > li:first-child > div > ul > li > div > div.calendar");
		var enddateCalendar   = document.querySelector("ul.calendar_period > li:last-child > div > ul > li > div > div.calendar");
		var memberTbody       = memberTable.lastElementChild;
		var memberButton      = document.querySelector("article > div.article > form > table.form > tbody > tr.member > th > button");
		var okButton          = document.querySelector("article > div.article > form > ul.submit > li > button:first-child");
		var deleteButton      = document.querySelector("article > div.article > form > ul.submit > li > button:last-child");
		var historyCalendarCallback = null;
		var useOrg = that.dataset.use_org;

		startdateSpan.innerHTML = dateFormatter.format(startDate, dateFormatter.DateStyle.LONG) + "<FONT>" + startdate + "</FONT>";
		enddateSpan.innerHTML   = dateFormatter.format(endDate, dateFormatter.DateStyle.LONG) + "<FONT>" + enddate + "</FONT>";

		function setStartdate() {
			startdateCalendar.nextElementSibling.click();

			var completionInput = document.projectForm.completion;
			var mindate = startdateSpan.firstElementChild.innerHTML;
			var maxdate = enddateSpan.firstElementChild.innerHTML;

			if (mindate > maxdate) {
				var tempdate = mindate;
				mindate = maxdate;
				maxdate = tempdate;
			}

			showMatchTaskPeriod(mindate, maxdate);
			completionInput.parentNode.setAttribute("class", getProgressStatus(completionInput.checked, mindate, maxdate));
		}

		function setEnddate() {
			enddateCalendar.nextElementSibling.click();

			var completionInput = document.projectForm.completion;
			var mindate = startdateSpan.firstElementChild.innerHTML;
			var maxdate = enddateSpan.firstElementChild.innerHTML;

			if (mindate > maxdate) {
				var tempdate = mindate;
				mindate = maxdate;
				maxdate = tempdate;
			}

			showMatchTaskPeriod(mindate, maxdate);
			completionInput.parentNode.setAttribute("class", getProgressStatus(completionInput.checked, mindate, maxdate));
		}

		displayCalendar(startDate, "date", startdateSpan, startdateCalendar, startdate, setStartdate);
		displayCalendar(endDate, "date", enddateSpan, enddateCalendar, enddate, setEnddate);

		startdateSpan.addEventListener("click", function(event) {
			if (window.innerWidth < 898) {
				enddateCalendar.nextElementSibling.click();
				startdateCalendar.parentNode.parentNode.parentNode.parentNode.setAttribute("class", "popup");

				if (isPhone) {
					document.body.style.overflow = "hidden";

					historyCalendarCallback = $jnode$.node.pushPseudoHistory(function() {
						startdateCalendar.nextElementSibling.click();
					});
				}
			}
		}, false);

		enddateSpan.addEventListener("click", function(event) {
			if (window.innerWidth < 898) {
				startdateCalendar.nextElementSibling.click();
				enddateCalendar.parentNode.parentNode.parentNode.parentNode.setAttribute("class", "popup");

				if (isPhone) {
					document.body.style.overflow = "hidden";

					historyCalendarCallback = $jnode$.node.pushPseudoHistory(function() {
						enddateCalendar.nextElementSibling.click();
					});
				}
			}
		}, false);

		startdateCalendar.nextElementSibling.addEventListener("click", function(event) {
			this.parentNode.parentNode.parentNode.parentNode.removeAttribute("class");
			if (isPhone)  document.body.style.removeProperty("overflow");
			if (historyCalendarCallback)  historyCalendarCallback();
		}, false);

		enddateCalendar.nextElementSibling.addEventListener("click", function(event) {
			this.parentNode.parentNode.parentNode.parentNode.removeAttribute("class");
			if (isPhone)  document.body.style.removeProperty("overflow");
			if (historyCalendarCallback)  historyCalendarCallback();
		}, false);

		matchTaskPeriodDiv.firstElementChild.addEventListener("click", function(event) {
			var minStartDate = dateUtil.parse(minStartdate);
			var maxEndDate   = dateUtil.parse(maxEnddate);
			
			startdateSpan.innerHTML = dateFormatter.format(minStartDate, dateFormatter.DateStyle.LONG) + "<FONT>" + minStartdate + "</FONT>";
			enddateSpan.innerHTML   = dateFormatter.format(maxEndDate, dateFormatter.DateStyle.LONG) + "<FONT>" + maxEnddate + "</FONT>";

			displayCalendar(minStartDate, "date", startdateSpan, startdateCalendar, minStartdate, setStartdate);
			displayCalendar(maxEndDate, "date", enddateSpan, enddateCalendar, maxEnddate, setEnddate);

			matchTaskPeriodDiv.setAttribute("class", "hide");
		});

		memberButton.addEventListener("click", function(event) {
			var winupContentId = "/member/user";
			if (useOrg)  winupContentId = "/member/org";

			$jnode$.requireContent("winup", winupContentId, {
				useLoading: true,
				icon:       true,
				title:      i18n.label_select_member,
				width:      705,
				height:     360,
				unload:     true
			});
		}, false);

		$jnode$.storage.eventhandler4member = {
			open: function() {
				var memberList  = [];
				var memberCells = memberTbody.querySelectorAll("tbody > tr > td:first-child");

				for (var i = 0; i < memberCells.length; i++) {
					var memberData = {
						user_id:       memberCells[i].parentNode.getAttribute("id"),
						user_name:     memberCells[i].querySelector("td > span:first-of-type").firstChild.nodeValue,
						position_name: memberCells[i].querySelector("td > span:nth-of-type(3)").firstChild.nodeValue,
						position_id:   memberCells[i].querySelector("td > font:first-of-type").firstChild.nodeValue
					};

					if (useOrg) {
						memberData.org_name = memberCells[i].querySelector("td > span:last-of-type").firstChild.nodeValue;
						memberData.org_id   = memberCells[i].querySelector("td > font:last-of-type").firstChild.nodeValue;
					}

					memberList.push(memberData);
				}

				return memberList;
			},

			ok: function(datas, close) {
				var checkedValue = null;
				var checkedInput = memberTbody.querySelector("tbody > tr > td > input:checked");
				var dataCount    = datas.length;

				if (checkedInput) {
					checkedValue = checkedInput.value;
				}

				memberTbody.innerHTML = "";

				for (var i = 0; i < datas.length; i++) {
					var userId = datas[i].user_id;
					var isRetiree = (userId.search(/^[$][{].+[}]$/) == 0);
					var row = document.createElement("tr");
					row.setAttribute("id", userId);
					memberTbody.appendChild(row);

					var orgInfo = "";
					if (useOrg)  orgInfo = " @ <SPAN>" + $jnode$.escapeXML(datas[i].org_name) + "</SPAN><FONT>" + datas[i].org_id + "</FONT>";

					var memberCell = row.insertCell(0);
					memberCell.innerHTML = (isRetiree ? i18n.label_retiree + ": " : "") + "<SPAN>" + $jnode$.escapeXML(datas[i].user_name) + "</SPAN> (<SPAN>" + $jnode$.escapeXML(isRetiree ? userId.substring(13, userId.length - 1) : userId) + "</SPAN> / <SPAN>" + $jnode$.escapeXML(datas[i].position_name) + "</SPAN><FONT>" + datas[i].position_id + "</FONT>)" + orgInfo;

					if (isRetiree)  memberCell.setAttribute("class", "retiree");

					var managerInput = document.createElement("input");
					managerInput.setAttribute("type", "radio");
					managerInput.setAttribute("name", "manager");
					managerInput.value = userId;

					if (datas[i].member_type == "manager")  managerInput.checked = true;

					var managerCell = row.insertCell(1);
					managerCell.appendChild(managerInput);
				}

				if (checkedValue) {
					var checkedMember = memberTbody.querySelector("tbody > tr > td > input[value='" + checkedValue + "']");
					if (checkedMember)  checkedMember.checked = true;
				}

				if (close)  close();
			}
		};

		$jnode$.storage.eventhandler4member.ok(that.dataset.memberList);

		document.projectForm.completion.addEventListener("click", function(event) {
			var mindate = startdateSpan.firstElementChild.innerHTML;
			var maxdate = enddateSpan.firstElementChild.innerHTML;

			if (mindate > maxdate) {
				var tempdate = mindate;
				mindate = maxdate;
				maxdate = tempdate;
			}

			this.parentNode.setAttribute("class", getProgressStatus(this.checked, mindate, maxdate));
		}, false);

		okButton.addEventListener("click", function(event) {
			var alertMessage = null;

			var params = {
				command:      "updateProject",
				project_id:   projectInfo.project_id,
				project_name: document.projectForm.project_name.value,
				startdate:    startdateSpan.firstElementChild.innerHTML,
				enddate:      enddateSpan.firstElementChild.innerHTML
			};

			if (params.project_name == "") {
				alertMessage = i18n.alert_input_project_name;
				document.projectForm.project_name.focus();
			} else {
				var memberIds  = [];
				var memberRows = memberTbody.querySelectorAll("tbody > tr");

				for (var i = 0; i < memberRows.length; i++) {
					memberIds.push(memberRows[i].getAttribute("id"));
				}

				if (memberIds.length == 0) {
					alertMessage = i18n.alert_select_project_member;
					memberButton.focus();
				} else {
					params.user_id = JSON.stringify(memberIds);

					if (memberIds.length == 1) {
						params.manager = memberIds[0];
					} else {
						var checkedInput = memberTbody.querySelector("tbody > tr > td > input:checked");
						if (checkedInput)  params.manager = checkedInput.value;
						else               alertMessage = i18n.alert_select_project_manager;
					}
				}
			}

			if (alertMessage) {
				this.parentNode.previousElementSibling.innerHTML = alertMessage;
			} else {
				$controller$.loading.show();

				if (document.projectForm.completion.checked) {
					if (projectInfo.completion)  params.completion = projectInfo.completion;
					else                         params.completion = dateFormatter.format(new Date(), "yyyy-MM-dd");
				}

				if (params.startdate > params.enddate) {
					var tempEnddate = params.startdate;
					params.startdate = params.enddate;
					params.enddate   = tempEnddate;
				}

				$jnode$.ajax.service({
					"url":      "/ajax/project.json",
					"method":   "POST",
					"datatype": "json",
					"headers": {
						"Content-Type": "application/json",
						"Accept":       "application/json"
					},
					"params":  params,
					"success": function(response) {
						if (response.deleled_worker) {
							projectContainer.removeChild(projectContainer.querySelector("div > label > input[value='" + params.project_id + "']").parentNode);

							var firstProject = projectContainer.querySelector("div > label:first-child > input");
							if (firstProject) {
								firstProject.click();
							} else {
								startId = "/project/create";
								alert_precondition_required = i18n.alert_precondition_required;
								document.querySelector("body > section > div.section > nav > fieldset > ul > li > div > ul > li:first-child > ul > li:first-child > button:first-child").click();
							}
						} else {
							var projectInput = projectContainer.querySelector("div > label > input[value='" + params.project_id + "']");
							var projectFont  = projectInput.nextElementSibling.firstElementChild;
							projectFont.setAttribute("class", getProgressStatus((params.completion ? true : false), params.startdate, params.enddate));
							projectFont.innerHTML = $jnode$.escapeXML(params.project_name);

							projectInput.click();
						}
					},
					"error": function(error) {
						$jnode$.ajax.alertError(error);
						$controller$.loading.hide();
					}
				});
			}
		}, false);

		deleteButton.addEventListener("click", function(event) {
			$controller$.prompt.confirm(i18n.confirm_delete_project, function(close) {
				$jnode$.ajax.service({
					"url":      "/ajax/project.json",
					"method":   "POST",
					"datatype": "json",
					"headers": {
						"Content-Type": "application/json",
						"Accept":       "application/json"
					},
					"params":  {
						command:    "deleteProject",
						project_id: projectInfo.project_id,
					},
					"success": function(response) {
						projectContainer.removeChild(projectContainer.querySelector("div > label > input[value='" + projectInfo.project_id + "']").parentNode);

						var firstProject = projectContainer.querySelector("div > label:first-child > input");
						if (firstProject) {
							firstProject.click();
						} else {
							startId = "/project/create";
							alert_precondition_required = i18n.alert_precondition_required;
							document.querySelector("body > section > div.section > nav > fieldset > ul > li > div > ul > li:first-child > ul > li:first-child > button:first-child").click();
						}
					},
					"error": function(error) {
						$jnode$.ajax.alertError(error);
						$controller$.loading.hide();
					}
				});

				close();
			}, null, 2);
		}, false);
	},

	unload: function() {
		delete $jnode$.storage.eventhandler4member;
	}
};