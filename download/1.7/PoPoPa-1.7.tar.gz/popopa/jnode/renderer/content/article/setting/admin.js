$content$.article.setting.admin = {
	posSortMap: {},
	appendUserRow: function(userTbody, userData) {
		var row = document.createElement("tr");
		userTbody.appendChild(row);

		var nameCell = row.insertCell(0);
		nameCell.appendChild(document.createTextNode(userData.user_name));

		var idCell = row.insertCell(1);
		idCell.appendChild(document.createTextNode(userData.user_id));

		var positionCell = row.insertCell(2);
		positionCell.appendChild(document.createTextNode(userData.position_name));
		positionCell.setAttribute("id", userData.position_id);
		positionCell.setAttribute("sid", $content$.article.setting.admin.posSortMap[userData.position_id.toString()]);

		if (!this.dataset.exclude_admin && useOrg) {
			var orgCell = row.insertCell(3);
			orgCell.appendChild(document.createTextNode(userData.org_name));
			orgCell.setAttribute("id", userData.org_id);
		}

		row.addEventListener("click", function(event) {
			var selectedRow = userTbody.querySelector("tbody > tr.selected");
			if (selectedRow)  selectedRow.removeAttribute("class");

			this.setAttribute("class", "selected");
			document.querySelector("div.section > article > div.article > fieldset > ul > li:last-child > button:nth-child(2)").disabled = false;
			document.querySelector("div.section > article > div.article > fieldset > ul > li:last-child > button:last-child").disabled = false;
		}, false);
	},

	resize: function() {
		var windowWidth  = window.innerWidth;
		var windowHeight = window.innerHeight;

		if (windowWidth > 736) {
			$controller$.grid.resize(null, windowHeight - 143);  // 43 + 30 + 10 + 37 + 10 + 10 + 18
		} else {
			$controller$.grid.removeHeight();
		}

		$controller$.grid.resizeScrollButtons();
	},

	service: function() {
		$controller$.loading.show();
		var that = this;
		$jnode$.pushHistory(that.conf);

		var positionList = this.dataset.positionList;

		function lpad(sortIndex) {
			if (sortIndex < 10) {
				return "0" + sortIndex.toString();
			} else {
				return sortIndex.toString();
			}
		}

		for (var i = 0; i < positionList.length; i++) {
			this.posSortMap[positionList[i].position_id.toString()] = lpad(i);
		}

		$jnode$.requireController("grid", {caller:that.conf}).on(function() {
			$controller$.grid.service({sortable:true});
			window.addEventListener("resize", that.resize, false);
			that.resize();

			var excludeAdminSelect = document.querySelector("div.section > article > div.article > fieldset > ul > li:first-child > select");
			var addButton          = document.querySelector("div.section > article > div.article > fieldset > ul > li:last-child > button:first-child");
			var editButton         = document.querySelector("div.section > article > div.article > fieldset > ul > li:last-child > button:nth-child(2)");
			var passwordButton     = document.querySelector("div.section > article > div.article > fieldset > ul > li:last-child > button:last-child");
			var userTbody          = document.querySelector("aside.grid > div > table > tbody");
			var userList           = that.dataset.userList;

			editButton.disabled     = true;
			passwordButton.disabled = true;

			for (var i = 0; i < userList.length; i++) {
				that.appendUserRow(userTbody, userList[i]);
			}

			$controller$.loading.hide();

			$jnode$.storage.eventhandler4member = {
				open: function() {
					var memberList = [];
					var memberRows = userTbody.querySelectorAll("tbody > tr");

					for (var i = 0; i < memberRows.length; i++) {
						var memberData = {
							user_id:       memberRows[i].querySelector("tr > td:nth-child(2)").firstChild.nodeValue,
							user_name:     memberRows[i].querySelector("tr > td:first-child").firstChild.nodeValue,
							position_name: memberRows[i].querySelector("tr > td:nth-child(3)").firstChild.nodeValue,
							position_id:   memberRows[i].querySelector("tr > td:nth-child(3)").getAttribute("id")
						};

						if (!that.dataset.exclude_admin && useOrg) {
							memberData.org_name = memberRows[i].querySelector("tr > td:last-child").firstChild.nodeValue;
							memberData.org_id   = memberRows[i].querySelector("tr > td:last-child").getAttribute("id");
						}

						memberList.push(memberData);
					}

					return memberList;
				},

				ok: function(datas, close) {
					var oldDatas    = this.open();
					var removedAdminIds = [];
					var addedAdminIds   = [];

					for (var i = 0; i < oldDatas.length; i++) {
						removedAdminIds.push(oldDatas[i].user_id);
					}

					editButton.disabled     = true;
					passwordButton.disabled = true;

					userTbody.innerHTML = "";

					for (var i = 0; i < datas.length; i++) {
						var checkIndex = removedAdminIds.indexOf(datas[i].user_id);

						if (checkIndex < 0) {
							addedAdminIds.push(datas[i].user_id);
						} else {
							delete removedAdminIds.splice(checkIndex, 1);
						}

						that.appendUserRow(userTbody, datas[i]);
					}

					if ((addedAdminIds.length + removedAdminIds.length) > 0) {
						$controller$.loading.show();

						$jnode$.ajax.service({
							"url":      "/ajax/user.json",
							"method":   "POST",
							"datatype": "json",
							"headers": {
								"Content-Type": "application/json",
								"Accept":       "application/json"
							},
							"params":  {
								command:        "selectAdmin",
								added_admins:   addedAdminIds.join(","),
								removed_admins: removedAdminIds.join(",")
							},
							"success": function(response) {
								$controller$.loading.hide();
							},
							"error": function(error) {
								$jnode$.ajax.alertError(error);
								$controller$.loading.hide();
							}
						});
					}

					if (close)  close();
				},

				disableWorker: true
			};

			// IE 9는 select의 콤보 아이콘을 수정하면 2개가 나옴.
			if (navigator.userAgent.indexOf(" MSIE 9.") > -1) {
				excludeAdminSelect.parentNode.setAttribute("class", "ie9");
			}

			excludeAdminSelect.addEventListener("change", function(event) {
				var adminSelect = this;

				$controller$.prompt.confirm((adminSelect.value == "true" ? i18n.confirm_new_account_for_admin_role_only : i18n.alert_change_admin_role_member), function(close) {
					if (adminSelect.value == "true") {
						$jnode$.requireContent("winup", "/setting/user/add", {
							useLoading: true,
							icon:       true,
							title:      i18n.label_create_admin,
							width:      420,
							height:     310,
							renderer:   "-j",
							parentNode: "admin",
							open:       false
						});

						$controller$.winup.open(null, function(close) {
							adminSelect.value = "false";
							close();
						});
					} else {
						$controller$.loading.show();

						$jnode$.ajax.service({
							"url":      "/ajax/setting.json",
							"method":   "POST",
							"datatype": "json",
							"headers": {
								"Content-Type": "application/json",
								"Accept":       "application/json"
							},
							"params":  {
								command: "includeAdminAtMember"
							},
							"success": function(response) {
								startId = "/project/create";
								alert_precondition_required = response.alert_precondition_required;
								$jnode$.requireContent("section", "/setting", {useLoading:true, articleId:"/setting/admin"});
							},
							"error": function(error) {
								adminSelect.value = (adminSelect.value == "true" ? "false" : "true");
								$jnode$.ajax.alertError(error);
								$controller$.loading.hide();
							}
						});
					}

					close();
				}, function(close) {
					adminSelect.value = (adminSelect.value == "true" ? "false" : "true");
					close();
				}, 2);
			}, false);

			addButton.addEventListener("click", function(event) {
				var winupContentId = "/setting/user/add";

				var winupOptions = {
					useLoading: true,
					icon:       true
				};

				if (excludeAdminSelect.value == "true") {
					winupOptions.title      = i18n.label_add_admin;
					winupOptions.width      = 420;
					winupOptions.height     = 310;
					winupOptions.renderer   = "-j";
					winupOptions.parentNode = "admin";
				} else {
					if (useOrg)  winupContentId = "/member/org";
					else         winupContentId = "/member/user";

					winupOptions.title  = i18n.label_select_admin;
					winupOptions.width  = 705;
					winupOptions.height = 360;
					winupOptions.unload = true;
				}

				$jnode$.requireContent("winup", winupContentId, winupOptions);
			}, false);

			editButton.addEventListener("click", function(event) {
				$jnode$.requireContent("winup", "/setting/user/edit", {
					useLoading: true,
					icon:       true,
					title:      i18n.label_edit_admin,
					width:      420,
					height:     248,
					renderer:   "-j",
					parentNode: "admin"
				});
			}, false);

			passwordButton.addEventListener("click", function(event) {
				$jnode$.requireContent("winup", "/setting/user/password_reset", {
					useLoading: true,
					icon:       true,
					title:      i18n.label_reset_password,
					width:      420,
					height:     150,
					renderer:   "-j"
				});
			}, false);
		});
	},

	unload: function() {
		window.removeEventListener("resize", this.resize, false);
	}
};