$content$.article.setting.position = {
	resize: function() {
		var windowWidth  = window.innerWidth;
		var windowHeight = window.innerHeight;
		var positionDiv = document.querySelector("div.section > article > div.article > ul > li:first-child > div");

		if (windowWidth > 736) {
			positionDiv.style.height = (windowHeight - 160) + "px";  // 43 + 30 + 10 + 37 + 10 + 10 + 18
		} else {
			positionDiv.style.removeProperty("height");
		}
	},

	service: function() {
		var that = this;
		$jnode$.pushHistory(that.conf);
		window.addEventListener("resize", that.resize, false);
		that.resize();

		var induceDiv         = document.querySelector("div.section > article > div.article > ul > li:last-child > div:last-child");
		var addButton         = document.querySelector("div.section > article > div.article > fieldset > ul > li:first-child > button");
		var editButton        = document.querySelector("div.section > article > div.article > fieldset > ul > li:nth-child(2) > button");
		var deleteButton      = document.querySelector("div.section > article > div.article > fieldset > ul > li:nth-child(3) > button");
		var sortButton        = document.querySelector("div.section > article > div.article > fieldset > ul > li:last-child > button");
		var positionContainer = document.querySelector("div.section > article > div.article > ul > li:first-child > div");
		var positionFormDiv   = document.querySelector("div.section > article > div.article > ul > li:last-child > div:first-child");
		var formLegend        = positionFormDiv.querySelector("div > ul > li > form > div:first-of-type > fieldset > legend");
		var inputRow          = positionFormDiv.querySelector("div > ul > li > form > div:first-of-type > fieldset > table > tbody > tr:first-child");
		var positionRow       = positionFormDiv.querySelector("div > ul > li > form > div:first-of-type > fieldset > table > tbody > tr:nth-child(2)");
		var nameRow           = positionFormDiv.querySelector("div > ul > li > form > div:first-of-type > fieldset > table > tbody > tr:nth-child(3)");
		var replaceRow        = positionFormDiv.querySelector("div > ul > li > form > div:first-of-type > fieldset > table > tbody > tr:last-child");
		var formAlert         = positionFormDiv.querySelector("div > ul > li > form > div:first-of-type > fieldset > ul > li.alert");
		var closeButton       = document.querySelector("div.section > article > div.article > ul > li:last-child > div:first-child > ul > li > form > button");
		var historyPositionCallback = null;

		var shiftableEventHandler = null;

		if (isMobile) {
			positionContainer.parentNode.setAttribute("class", "mobile");
		}

		function disableButtons(disabled) {
			addButton.disabled    = disabled;
			editButton.disabled   = disabled;
			deleteButton.disabled = disabled;

			if (!disabled) {
				induceDiv.style.display = "none";

				// 삭제 버튼과 정렬 버튼은 2개이상의 직급이 있어야 활성화
				if (positionContainer.querySelectorAll("div > label > input").length < 2) {
					deleteButton.disabled = true;
					sortButton.disabled = true;

					if (positionContainer.getAttribute("class") == "shiftable") {
						positionContainer.removeAttribute("class");
						sortButton.setAttribute("class", "led off");
						shiftableEventHandler.removeShiftableEvent();
					}
				} else {
					sortButton.disabled = false;
				}
			}
		}

		window.setTimeout(function() {
			induceDiv.style.display = "none";
		}, 30000);

		disableButtons(true);

		function appendPosition(positionData, selectedLabel) {
			var label = document.createElement("label");

			var input = document.createElement("input");
			input.setAttribute("type", "radio");
			input.setAttribute("name", "position_id");
			input.setAttribute("value", positionData.position_id);

			var span = document.createElement("span");
			span.appendChild(document.createTextNode(positionData.position_name));

			label.appendChild(input);
			label.appendChild(span);

			input.addEventListener("click", function(event) {
				disableButtons(false);

				var checkedInput = positionContainer.querySelector("div > label > input:checked");

				if (checkedInput && !isPhone) {
					if      (document.positionForm.command.value == "addPosition"   )  addButton.click();
					else if (document.positionForm.command.value == "updatePosition")  editButton.click();
					else if (document.positionForm.command.value == "deletePosition") {
						if (deleteButton.disabled)  positionFormDiv.style.display = "none";
						else                        deleteButton.click();
					}
				}
			}, false);

			if (selectedLabel) {
				if (positionData.position == "previous") {
					positionContainer.insertBefore(label, selectedLabel);
				} else {
					positionContainer.insertBefore(label, selectedLabel.nextElementSibling);
				}
			} else {
				positionContainer.appendChild(label);
			}
		}

		var positionList = that.dataset.positionList;

		if (positionList.length < 2) {
			sortButton.disabled = true;
		}

		for (var i = 0; i < positionList.length; i++) {
			appendPosition(positionList[i]);
		}

		addButton.addEventListener("click", function(event) {
			if (isPhone) {
				document.body.style.overflow = "hidden";

				historyPositionCallback = $jnode$.node.pushPseudoHistory(function() {
					closeButton.click();
				});
			}

			document.positionForm.command.value       = "addPosition";
			document.positionForm.position_name.value = "";
			document.positionForm.position.value      = "next";

			formAlert.innerHTML           = "";
			formLegend.innerHTML          = i18n.label_add;
			positionFormDiv.style.display = "block";
			inputRow.style.display        = "table-row";
			positionRow.style.display     = "table-row";
			nameRow.style.display         = "none";
			replaceRow.style.display      = "none";

			document.positionForm.position_name.focus();
		}, false);

		editButton.addEventListener("click", function(event) {
			if (isPhone) {
				document.body.style.overflow = "hidden";

				historyPositionCallback = $jnode$.node.pushPseudoHistory(function() {
					closeButton.click();
				});
			}

			document.positionForm.command.value       = "updatePosition";
			document.positionForm.position_name.value = positionContainer.querySelector("div > label > input:checked + span").firstChild.nodeValue;

			formAlert.innerHTML           = "";
			formLegend.innerHTML          = i18n.label_edit;
			positionFormDiv.style.display = "block";
			inputRow.style.display        = "table-row";
			positionRow.style.display     = "none";
			nameRow.style.display         = "none";
			replaceRow.style.display      = "none";
		}, false);

		deleteButton.addEventListener("click", function(event) {
			if (isPhone) {
				document.body.style.overflow = "hidden";

				historyPositionCallback = $jnode$.node.pushPseudoHistory(function() {
					closeButton.click();
				});
			}

			document.positionForm.command.value = "deletePosition";
			nameRow.lastElementChild.innerHTML = positionContainer.querySelector("div > label > input:checked + span").innerHTML;

			var newIdSelect      = document.positionForm.new_id;
			var positions        = positionContainer.querySelectorAll("div > label > input");
			var positionCount    = positions.length;
			var selectedPosition = positions[0].value;

			newIdSelect.innerHTML = "";

			for (var i = 0; i < positionCount; i++) {
				if (positions[i].checked) {
					if (i == positionCount - 1)  selectedPosition = positions[i - 1].value
					else                         selectedPosition = positions[i + 1].value
				} else {
					newIdSelect.options.add(new Option(positions[i].nextElementSibling.firstChild.nodeValue, positions[i].value, false, false));
				}
			}

			newIdSelect.value = selectedPosition;

			formAlert.innerHTML           = "";
			formLegend.innerHTML          = i18n.label_delete;
			positionFormDiv.style.display = "block";
			inputRow.style.display        = "none";
			positionRow.style.display     = "none";
			nameRow.style.display         = "table-row";
			replaceRow.style.display      = "table-row";
		}, false);

		closeButton.addEventListener("click", function(event) {
			if (isMobile) {
				document.body.style.removeProperty("overflow");
				if (historyPositionCallback)  historyPositionCallback();
			}

			positionFormDiv.style.display = "none";
		}, false);

		positionFormDiv.querySelector("div > ul > li > form > div:first-of-type > fieldset > ul > li > button").addEventListener("click", function(event) {
			var command       = document.positionForm.command.value;
			var selectedInput = positionContainer.querySelector("div > label > input:checked");
			var selectedId    = selectedInput.value;

			if (command == "deletePosition") {
				var newId   = document.positionForm.new_id.value;
				var newName = document.positionForm.new_id.options[document.positionForm.new_id.selectedIndex].text;

				$controller$.prompt.confirm(i18n.confirm_delete_position, function(close) {
					$controller$.loading.show();

					$jnode$.ajax.service({
						"url":      "/ajax/position.json",
						"method":   "POST",
						"datatype": "json",
						"headers": {
							"Content-Type": "application/json",
							"Accept":       "application/json"
						},
						"params": {
							"command":     "deletePosition",
							"position_id": selectedId,
							"new_id":      newId,
							"new_name":    newName
						},
						"success": function(response) {
							var selectedLabel = selectedInput.parentNode;
							selectedLabel.parentNode.removeChild(selectedLabel);
							positionContainer.querySelector("div > label > input[value='" + newId + "']").click();

							$controller$.loading.hide();

							closeButton.click();
						},
						"error": function(error) {
							$jnode$.ajax.alertError(error);
							$controller$.loading.hide();
						}
					});

					close();
				}, null, 2);
			} else {
				var positionName = document.positionForm.position_name.value;

				if (positionName == "") {
					formAlert.innerHTML = i18n.alert_input_position_name;
					document.positionForm.position_name.focus();
				} else {
					$controller$.loading.show();

					var params = {
						command:       document.positionForm.command.value,
						position_name: document.positionForm.position_name.value
					};

					if (params.command == "addPosition") {
						params.position_sibling = selectedId;
						params.position         = document.positionForm.position.value;
					} else {
						params.position_id = selectedId;
					}

					$jnode$.ajax.service({
						"url":      "/ajax/position.json",
						"method":   "POST",
						"datatype": "json",
						"headers": {
							"Content-Type": "application/json",
							"Accept":       "application/json"
						},
						"params": params,
						"success": function(response) {
							if (params.command == "addPosition") {
								params.position_id = response.position_id;
								appendPosition(params, selectedInput.parentNode);

								positionContainer.querySelector("div > label > input[value='" + params.position_id + "']").click();
							} else {
								var selectedSpan = selectedInput.nextElementSibling;
								selectedSpan.firstChild.nodeValue = params.position_name;
							}

							$controller$.loading.hide();
							closeButton.click();
						},
						"error": function(error) {
							$jnode$.ajax.alertError(error);
							$controller$.loading.hide();
						}
					});
				}
			}
		}, false);

		$jnode$.requireModule("tap", that.conf).on(function() {
			var checkedValue = null;

			shiftableEventHandler = new $jnode$.module.tap.ShiftableEventHandler(positionContainer, "div > label", function(prevIndex, currIndex) {
				if (isPhone)  document.body.style.removeProperty("overflow");

				if (checkedValue)  positionContainer.querySelector("div > label > input[value='" + checkedValue + "']").checked = true;

				if (prevIndex > -1 && currIndex > -1 && prevIndex != currIndex) {
					$controller$.loading.show();

					var positionIds = [];
					var positionInputs = positionContainer.querySelectorAll("div > label > input");
					for (var i = 0; i < positionInputs.length; i++) {
						positionIds.push(parseInt(positionInputs[i].value, 10));
					}

					$jnode$.ajax.service({
						"url":      "/ajax/position.json",
						"method":   "POST",
						"datatype": "json",
						"headers": {
							"Content-Type": "application/json",
							"Accept":       "application/json"
						},
						"params":   {
							"command":     "sortPosition",
							"position_id": JSON.stringify(positionIds)
						},
						"success": function(response) {
							$controller$.loading.hide();
						},
						"error": function(error) {
							$jnode$.ajax.alertError(error);
							$controller$.loading.hide();
						}
					});
				}
			}, function() {
				if (isPhone)  document.body.style.overflow = "hidden";

				checkedValue = null;
				var checkedInput = positionContainer.querySelector("div > label > input:checked");
				if (checkedInput)  checkedValue = checkedInput.value;
			},
			{
				style: "background-color: #FEEFB9;",
				scrollableNode: positionContainer
			});

			if (isMobile) {
				sortButton.addEventListener("click", function(event) {
					if (positionContainer.getAttribute("class") == "shiftable") {
						positionContainer.removeAttribute("class");
						this.setAttribute("class", "led off");
						shiftableEventHandler.removeShiftableEvent();
					} else {
						positionContainer.setAttribute("class", "shiftable");
						this.setAttribute("class", "led green");
						shiftableEventHandler.addShiftableEvent();
					}
				}, false);
			} else {
				sortButton.parentNode.style.display = "none";
				shiftableEventHandler.addShiftableEvent();
			}
		});
	},

	unload: function() {
		window.removeEventListener("resize", this.resize, false);
	}
};