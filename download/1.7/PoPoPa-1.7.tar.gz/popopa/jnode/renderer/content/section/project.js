$content$.section.project = {
	appendProject: function(projectInfo, today, first) {
		var projectContainer = document.querySelector("body > section > div.section > nav > fieldset > ul > li > div > ul > li:last-child > div");

		var projectLabel = document.createElement("label");
		if (first)  projectContainer.insertBefore(projectLabel, projectContainer.firstElementChild);
		else        projectContainer.appendChild(projectLabel);

		var projectInput = document.createElement("input");
		projectInput.setAttribute("type", "radio");
		projectInput.setAttribute("name", "project_id");
		projectInput.value = projectInfo.project_id;
		projectLabel.appendChild(projectInput);

		var projectSpan = document.createElement("span");
		projectLabel.appendChild(projectSpan);

		var projectFont = document.createElement("font");
		projectFont.appendChild(document.createTextNode(projectInfo.project_name));
		projectFont.setAttribute("class", getProgressStatus((projectInfo.completion ? true : false), projectInfo.startdate, projectInfo.enddate, today));
		projectSpan.appendChild(projectFont);

		projectInput.addEventListener("click", function(event) {
			document.querySelector("body > section > div.section > nav > div:first-child").innerHTML = $jnode$.escapeXML(projectInfo.project_name);
			$jnode$.requireContent("article", "/project/edit", {project_id: projectInfo.project_id, useLoading: true});

			var tumbtrackButton    = document.querySelector("body > section > div.section > nav > fieldset > ul > li > div > ul > li:first-child > ul > li:last-child > button:first-child");
			var projectCloseButton = tumbtrackButton.nextElementSibling;
			if (tumbtrackButton.getAttribute("class") == null)  projectCloseButton.click();
		}, false);

		if (first)  projectInput.click();
	},

	resize: function() {
		var windowWidth      = window.innerWidth;
		var windowHeight     = window.innerHeight;
		var projectContainer = document.querySelector("body > section > div.section > nav > fieldset > ul > li > div > ul > li:last-child > div");
		var articleNode      = document.querySelector("section > div.section > article");
		var errorUl          = articleNode.querySelector("article > div.article > ul > li > ul.error");

		if (windowWidth > 736) {
			if (errorUl)  errorUl.parentNode.style.height = (windowHeight - 111) + "px";

			articleNode.style.height = (windowHeight - 91) + "px";  // 73 + 18
			projectContainer.style.height = (windowHeight - 145) + "px";
		} else {
			if (errorUl)  errorUl.parentNode.removeAttribute("style");

			articleNode.removeAttribute("style");
			projectContainer.style.height = (windowHeight - 56) + "px";
		}
	},

	service: function() {
		var nodeConf = this.conf;
		window.addEventListener("resize", this.resize, false);
		this.resize();

		i18n = this.dataset.i18n;

		setSectionTitle(nodeConf.nodeId);

		var projectList = this.dataset.projectList;
		var today       = dateFormatter.format(new Date(), "yyyy-MM-dd");
		for (var i = 0; i < projectList.length; i++) {
			this.appendProject(projectList[i], today);
		}

		var projectContainer       = document.querySelector("body > section > div.section > nav > fieldset > ul > li > div > ul > li:last-child > div");
		var projectAddButton       = document.querySelector("body > section > div.section > nav > fieldset > ul > li > div > ul > li:first-child > ul > li:first-child > button");
		var tumbtrackButton        = document.querySelector("body > section > div.section > nav > fieldset > ul > li > div > ul > li:first-child > ul > li:last-child > button:first-child");
		var projectCloseButton     = document.querySelector("body > section > div.section > nav > fieldset > ul > li > div > ul > li:first-child > ul > li:last-child > button:last-child");
		var historyProjectCallback = null;

		projectAddButton.addEventListener("click", function(event) {
			if (document.querySelector("body > section > div.section > nav > fieldset.popup"))  projectCloseButton.click();

			// 생성화면에선 선택된 프로젝트가 없게 할지 여부
			// var checkedProject = document.querySelector("section > div.section > nav > fieldset > ul > li > div > ul > li:last-child > div > label > input:checked");
			// if (checkedProject)  checkedProject.checked = false;

			$jnode$.requireContent("article", "/project/create", {useLoading:true});
		}, false);

		// 폰에서 프로젝트 선택 팝업창을 띄우는 작업
		document.querySelector("body > section > div.section > nav > div:first-child").addEventListener("click", function(event) {
			if (isPhone) {
				document.body.style.overflow = "hidden";

				historyProjectCallback = $jnode$.node.pushPseudoHistory(function() {
					orgCloseButton.click();
				});
			}

			this.nextElementSibling.setAttribute("class", "popup");
		}, false);

		projectCloseButton.addEventListener("click", function(event) {
			if (isPhone) {
				document.body.style.removeProperty("overflow");
				if (historyProjectCallback)  historyProjectCallback();
			}

			this.parentNode.parentNode.parentNode.parentNode.parentNode.parentNode.parentNode.parentNode.removeAttribute("class");
		}, false);

		tumbtrackButton.addEventListener("click", function(event) {
			if (this.getAttribute("class") == "on")  this.removeAttribute("class");
			else                                     this.setAttribute("class", "on");
		}, false);

		if (startId == "/project/create") {
			alert_precondition_required = i18n.alert_precondition_required;
			projectAddButton.click();
		} else {
			projectContainer.querySelector("div > label > input[value='" + this.dataset.lastProject + "']").click();
		}

		$jnode$.requireModule("tap", nodeConf).on(function() {
			var checkedValue = null;

			shiftableEventHandler = new $jnode$.module.tap.ShiftableEventHandler(projectContainer, "div > label", function(prevIndex, currIndex) {
				if (checkedValue)  projectContainer.querySelector("div > label > input[value='" + checkedValue + "']").checked = true;

				if (prevIndex > -1 && currIndex > -1 && prevIndex != currIndex) {
					$controller$.loading.show();

					var projectIds = [];
					var projectInputs = projectContainer.querySelectorAll("div > label > input");
					for (var i = 0; i < projectInputs.length; i++) {
						projectIds.push(projectInputs[i].value);
					}

					$jnode$.ajax.service({
						"url":      "/ajax/project.json",
						"method":   "POST",
						"datatype": "json",
						"headers": {
							"Content-Type": "application/json",
							"Accept":       "application/json"
						},
						"params":   {
							"command":    "sortProject",
							"project_id": JSON.stringify(projectIds)
						},
						"success": function(response) {
							$controller$.loading.hide();
						},
						"error": function(error) {
							$jnode$.ajax.alertError(error);
							$controller$.loading.hide();
						}
					});
				}
			}, function() {
				checkedValue = null;
				var checkedInput = projectContainer.querySelector("div > label > input:checked");
				if (checkedInput)  checkedValue = checkedInput.value;
			},
			{
				style: "background-color: #FEEFB9;",
				scrollableNode: projectContainer
			});

			shiftableEventHandler.addShiftableEvent();
		});
	},

	unload: function() {
		window.removeEventListener("resize", this.resize, false);
	}
};