$content$.helpsection.ko.introduction = {
	service: function() {
		menuClassDiv.innerHTML = "PoPoPa " + this.dataset.version_info.name;
		$jnode$.pushHistory(this.conf);
	}
};