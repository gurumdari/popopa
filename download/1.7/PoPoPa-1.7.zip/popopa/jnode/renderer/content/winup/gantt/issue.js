$content$.winup.gantt.issue = {
	resize: function() {
		var windowWidth  = window.innerWidth;
		var windowHeight = window.innerHeight;
		var descHeight = 120;

		if (windowWidth < 737) {
			if (windowWidth > 479) {
				if (windowHeight < 453) {
					descHeight = Math.floor((windowHeight * 0.8 - 122) / 2);
				}
			} else {
				if (windowHeight < 567) {
					descHeight = Math.floor((windowHeight * 0.8 - 213) / 2);
				}
			}

			if (descHeight < 30)  descHeight = 30;
		}

		document.issueForm.note_desc.style.height = descHeight + "px";
		document.issueForm.action.style.height    = descHeight + "px";
	},

	service: function() {
		var that = this;
		window.addEventListener("resize", this.resize, false);
		this.resize();

		var taskId          = this.conf.task_id;
		var noteId          = this.conf.note_id;
		var okButton        = document.querySelector("aside.winup article > div.winup > form > ul.submit > li:last-child > button:first-child");
		var deleteButton    = document.querySelector("aside.winup article > div.winup > form > ul.submit > li:last-child > button:last-child");
		var issueDiv        = document.querySelector("body > section > div > ul > li:first-child > ul > li:last-child > div > div > label > input[value='" + taskId + "'] + div > ul > li:last-child > ul > li:first-child > div:first-child");
		var completionValue = null;

		if (noteId) {
			var issueInfo = this.dataset.issueInfo;

			document.issueForm.note_name.value  = issueInfo.note_name;
			document.issueForm.note_desc.value  = issueInfo.note_desc;
			document.issueForm.action.value     = issueInfo.action;

			if (issueInfo.completion) {
				document.issueForm.completion.checked = true;
				completionValue = issueInfo.completion;
			}
		} else {
			document.issueForm.note_name.value = that.conf.task_name;
			document.issueForm.note_desc.focus();
		}

		if (completionValue == null)  completionValue = dateUtil.format(new Date());

		okButton.addEventListener("click", function(event) {
			var params = {
				command:    "addNote",
				project_id: that.conf.project_id,
				task_id:    taskId,
				note_name:  document.issueForm.note_name.value.trim(),
				note_type:  "issue",
				note_desc:  document.issueForm.note_desc.value,
				action:     document.issueForm.action.value,
				completion: (document.issueForm.completion.checked ? completionValue : "")
			}

			if (noteId) {
				params.command = "updateNote";
				params.note_id = noteId;
			} else {
				params.command = "addNote";
			}

			var alertMessage = "";

			if (params.note_name == "") {
				alertMessage = i18n.alert_input_issue_name;
				document.issueForm.note_name.focus();
			} else if (params.note_desc.trim() == "") {
				alertMessage = i18n.alert_input_issue_desc;
				document.issueForm.note_desc.focus();
			}

			if (alertMessage) {
				this.parentNode.previousElementSibling.innerHTML = alertMessage;
			} else {
				$controller$.loading.show();

				$jnode$.ajax.service({
					"url":      "/ajax/gantt.json",
					"method":   "POST",
					"datatype": "json",
					"headers": {
						"Content-Type": "application/json",
						"Accept":       "application/json"
					},
					"params":  params,
					"success": function(response) {
						if (noteId) {
							if (params.completion)  issueDiv.setAttribute("class", "completion");
							else                    issueDiv.removeAttribute("class");
						} else {
							issueDiv.setAttribute("id", response.note_id);
							if (params.completion)  issueDiv.setAttribute("class", "completion");
						}

						$controller$.winup.close();
						$controller$.loading.hide();
					},
					"error": function(error) {
						$jnode$.ajax.alertError(error);
						$controller$.loading.hide();
					}
				});
			}
		}, false);

		deleteButton.addEventListener("click", function(event) {
			$controller$.prompt.confirm(i18n.confirm_delete_issue, function(close) {
				$controller$.loading.show();

				$jnode$.ajax.service({
					"url":      "/ajax/gantt.json",
					"method":   "POST",
					"datatype": "json",
					"headers": {
						"Content-Type": "application/json",
						"Accept":       "application/json"
					},
					"params":  {
						command: "deleteNote",
						note_id: noteId,
					},
					"success": function(response) {
						issueDiv.removeAttribute("id");
						issueDiv.removeAttribute("class");

						$controller$.winup.close();
						$controller$.loading.hide();
					},
					"error": function(error) {
						$jnode$.ajax.alertError(error);
						$controller$.loading.hide();
					}
				});

				close();
			}, null, 2);
		}, false);
	},

	unload: function() {
		window.removeEventListener("resize", this.resize, false);
	}
};