$content$.winup.member.user = {
	resize: function() {
		var windowWidth  = window.innerWidth;
		var windowHeight = window.innerHeight;
		var selectorHeight = 278;

		if ((windowWidth < 737) && (windowHeight < 452)) {
			selectorHeight = windowHeight * 0.8 - 104;
		} else {
			selectorHeight = 278;
		}

		$controller$["grid#source"].resize(null, selectorHeight);
		document.querySelector("aside.winup article > div.winup > ul:nth-child(2) > li:last-child > div#target").style.height = selectorHeight + "px";
	},

	service: function() {
		$controller$.loading.show();
		var that = this;

		var targetUserUl  = document.querySelector("aside.winup article > div.winup > ul:nth-child(2) > li:last-child > div#target > ul");
		var addButton1    = document.querySelector("aside.winup article > div.winup > ul:nth-child(2) > li:nth-child(2) > button:first-child");
		var removeButton1 = document.querySelector("aside.winup article > div.winup > ul:nth-child(2) > li:nth-child(2) > button:last-child");
		var addButton2    = document.querySelector("aside.winup article > div.winup > ul:last-child > li > button:first-child");
		var removeButton2 = document.querySelector("aside.winup article > div.winup > ul:last-child > li > button:nth-child(2)");
		var okButton      = document.querySelector("aside.winup article > div.winup > ul:last-child > li > button:last-child");

		addButton1.disabled    = true;
		addButton2.disabled    = true;
		removeButton1.disabled = true;
		removeButton2.disabled = true;

		var posSortMap = {};

		var positionList = this.dataset.positionList;

		function lpad(sortIndex) {
			if (sortIndex < 10) {
				return "0" + sortIndex.toString();
			} else {
				return sortIndex.toString();
			}
		}

		for (var i = 0; i < positionList.length; i++) {
			posSortMap[positionList[i].position_id.toString()] = lpad(i);
		}

		function appendUserList(userData, disabled) {
			var userId = userData.user_id;
			var isRetiree = (userId.search(/^[$][{].+[}]$/) == 0);
			var targetUserLi = document.createElement("li");
			targetUserLi.setAttribute("id", userId);
			targetUserLi.innerHTML = (isRetiree ? i18n.label_retiree + ": " : "") + "<SPAN>" + $jnode$.escapeXML(userData.user_name) + "</SPAN> (<SPAN>" + $jnode$.escapeXML(isRetiree ? userId.substring(13, userId.length - 1) : userId) + "</SPAN> / <SPAN>" + $jnode$.escapeXML(userData.position_name) + "</SPAN><FONT>" + userData.position_id + "</FONT>)";
			targetUserUl.appendChild(targetUserLi);

			if (disabled) {
				targetUserLi.setAttribute("class", "disabled");
			} else {
				targetUserLi.addEventListener("click", function(event) {
					if ($jnode$.node.hasClass(this, "checked")) {
						$jnode$.node.removeClass(this, "checked");

						if (targetUserUl.querySelectorAll("ul > li.checked").length == 0) {
							removeButton1.disabled = true;
							removeButton2.disabled = true;
						}
					} else {
						$jnode$.node.addClass(this, "checked");

						removeButton1.disabled = false;
						removeButton2.disabled = false;
					}
				}, false);
			}

			if (isRetiree) {
				$jnode$.node.addClass(targetUserLi, "retiree");
			}
		}

		$jnode$.requireController("grid#source", {caller:that.conf}).on(function() {
			function appendUserRow(userTbody, userData) {
				var row = document.createElement("tr");
				userTbody.appendChild(row);

				var nameCell = row.insertCell(0);
				nameCell.appendChild(document.createTextNode(userData.user_name));

				var idCell = row.insertCell(1);
				idCell.appendChild(document.createTextNode(userData.user_id));

				var positionCell = row.insertCell(2);
				positionCell.appendChild(document.createTextNode(userData.position_name));
				positionCell.setAttribute("id", userData.position_id);
				positionCell.setAttribute("sid", posSortMap[userData.position_id.toString()]);

				row.addEventListener("click", function(event) {
					if (this.getAttribute("class") == "selected") {
						this.removeAttribute("class");

						if (userTbody.querySelectorAll("tbody > tr.selected").length == 0) {
							addButton1.disabled = true;
							addButton2.disabled = true;
						}
					} else {
						this.setAttribute("class", "selected");

						addButton1.disabled = false;
						addButton2.disabled = false;
					}
				}, false);
			}

			$controller$["grid#source"].service({height:278, sortable:true});

			var sourceUserList  = that.dataset.userList;
			var sourceUserTbody = document.querySelector("aside.grid#source > div > table > tbody");

			for (var i = 0; i < sourceUserList.length; i++) {
				appendUserRow(sourceUserTbody, sourceUserList[i]);
			}

			function appendTargetUserList(targetUserList) {
				var addedUserIds = [];
				var addedUserLis = targetUserUl.querySelectorAll("ul > li");

				for (var i = 0; i < addedUserLis.length; i++) {
					addedUserIds.push(addedUserLis[i].getAttribute("id"));
				}

				for (var i = 0; i < targetUserList.length; i++) {
					if (addedUserIds.indexOf(targetUserList[i].user_id) < 0) {
						appendUserList(targetUserList[i]);
					}
				}
			}

			function addButtonHandler(event) {
				var addedUserList    = [];
				var selectedUserRows = sourceUserTbody.querySelectorAll("tbody > tr.selected");

				for (var i = 0; i < selectedUserRows.length; i++) {
					addedUserList.push({
						user_name:     selectedUserRows[i].querySelector("tr > td:first-child").firstChild.nodeValue,
						user_id:       selectedUserRows[i].querySelector("tr > td:nth-child(2)").firstChild.nodeValue,
						position_name: selectedUserRows[i].querySelector("tr > td:last-child").firstChild.nodeValue,
						position_id:   selectedUserRows[i].querySelector("tr > td:last-child").getAttribute("id")
					});

					selectedUserRows[i].removeAttribute("class");
				}

				addButton1.disabled = true;
				addButton2.disabled = true;
				appendTargetUserList(addedUserList);
			}

			addButton1.addEventListener("click", addButtonHandler, false);
			addButton2.addEventListener("click", addButtonHandler, false);

			function removeButtonHandler(event) {
				var selectedUserLi = targetUserUl.querySelectorAll("ul > li.checked");

				for (var i = selectedUserLi.length - 1; i >= 0; i--) {
					targetUserUl.removeChild(selectedUserLi[i]);
				}

				removeButton1.disabled = true;
				removeButton2.disabled = true;
			}

			removeButton1.addEventListener("click", removeButtonHandler, false);
			removeButton2.addEventListener("click", removeButtonHandler, false);

			okButton.addEventListener("click", function(event) {
				var targetUserList = [];
				var targetUserLi   = targetUserUl.querySelectorAll("ul > li");

				for (var i = 0; i < targetUserLi.length; i++) {
					targetUserList.push({
						user_id:       targetUserLi[i].getAttribute("id"),
						user_name:     targetUserLi[i].querySelector("li > span:first-of-type").firstChild.nodeValue,
						position_name: targetUserLi[i].querySelector("li > span:last-of-type").firstChild.nodeValue,
						position_id:   targetUserLi[i].querySelector("li > font:first-of-type").firstChild.nodeValue
					});
				}

				$jnode$.storage.eventhandler4member.ok(targetUserList, $controller$.winup.close);
			}, false);

			var tabInputs = document.querySelectorAll("aside.winup article > div.winup > ul:first-child > li > label > input");

			for (var i = 0; i < tabInputs.length; i++) {
				tabInputs[i].addEventListener("click", function(event) {
					var sourceTab = document.querySelector("aside.winup article > div.winup > ul:nth-child(2) > li:first-child");
					var targetTab = document.querySelector("aside.winup article > div.winup > ul:nth-child(2) > li:last-child");

					if (this.value == "source") {
						sourceTab.removeAttribute("class");
						targetTab.setAttribute("class", "hidden");

						addButton2.removeAttribute("class");
						removeButton2.setAttribute("class", "hidden");
					} else {
						sourceTab.setAttribute("class", "hidden");
						targetTab.removeAttribute("class");

						addButton2.setAttribute("class", "hidden");
						removeButton2.removeAttribute("class");
					}

					that.resize();
				}, false);
			}

			tabInputs[0].click();

			var targetUserList = $jnode$.storage.eventhandler4member.open();
			var workerInfo     = that.dataset.workerInfo;
			var disabledUserId = null;

			if ($jnode$.storage.eventhandler4member.disableWorker) {
				appendUserList(workerInfo, true);
				disabledUserId = workerInfo.user_id;
			}

			for (var i = 0; i < targetUserList.length; i++) {
				if (targetUserList[i].user_id != disabledUserId) {
					appendUserList(targetUserList[i]);
				}
			}

			$controller$.loading.hide();

			window.addEventListener("resize", that.resize, false);
		});

		// 프로젝트 대상 멤버들간의 정렬 이벤트
		if ($jnode$.storage.eventhandler4member.disableWorker == null || $jnode$.storage.eventhandler4member.disableWorker == false) {
			$jnode$.requireModule("tap", that.conf).on(function() {
				shiftableEventHandler = new $jnode$.module.tap.ShiftableEventHandler(targetUserUl, "ul > li", null, null,
				{
					style: "background-color: #FEEFB9;",
					scrollableNode: targetUserUl.parentNode
				});

				shiftableEventHandler.addShiftableEvent();
			});
		}
	},

	unload: function() {
		window.removeEventListener("resize", this.resize, false);
	}
};