$content$.article.setting.about = {
	service: function() {
		$jnode$.pushHistory(this.conf);

		var infoCellWidth = document.querySelector("div.section > article > div.article > fieldset > div:nth-child(2) > ul > li:last-child > table.form.nogroup > tbody > tr:first-child > th").clientWidth - 4;
		document.querySelector("div.section > article > div.article > fieldset > div:nth-child(2) > ul > li:first-child > table.form.nogroup > tbody > tr:first-child > th").style.minWidth = infoCellWidth + "px";

		if (this.dataset.is_admin) {
			var versionName = this.dataset.version_info.name;

			if (versionName != "-") {
				document.title = "PoPoPa " + versionName;
				$jnode$.cachePreventVersion = versionName;
			}

			var upgraderContainer = document.querySelector("div.section > article > div.article > fieldset > div:last-child");
			upgraderContainer.style.display = "block";

			upgraderContainer.querySelector("div > a").addEventListener("click", function(event) {
				$controller$.loading.show();

				$jnode$.requireContent("winup", "/setting/upgrade/frame", {
					icon:     true,
					title:    i18n.label_upgrade_version,
					width:    420,
					height:   114,
					renderer: "c-"
				});
			}, false);
		}
	}
};