$content$.helpsection.en.setting.system.user.with_org = {
	service: function() {
		var selectedSpan = document.querySelector("body > nav > div > div ul > li > label > input:checked + span");
		menuClassDiv.innerHTML = selectedSpan.innerHTML;
		$jnode$.pushHistory(this.conf);

		var parentCategory = openParentNode(selectedSpan.parentNode);
		openParentNode(parentCategory);
	}
};
