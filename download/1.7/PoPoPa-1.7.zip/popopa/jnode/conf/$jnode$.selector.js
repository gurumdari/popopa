$jnode$.selector = {
	path: {
		/* context:  "/popopa", */
		template: $jnode$.jnodeBasePath + "/template",
		renderer: $jnode$.jnodeBasePath + "/renderer",
		collapse: "none" /* none | content | template */
	},
	content: {
		nav:         "body > nav",
		section:     "body > section",
		article:     "body > section > div.section > article",
		helpnav:     "body > nav",
		helpsection: "body > section"
	},
	controller: {
		contentframe: {
			method:   "dom",  // "template",
			domain:   "aside.contentframe"
		},
		dataframe: {
			method:   "dom",  // "template",
			domain:   "aside.dataframe"
		},
		datasheet: {
			method:   "dom",  // "template",
			domain:   "aside.datasheet"
		},
		loading: {
			method:   "dom",  // "template",
			domain:   "aside.loading"
		},
		prompt: {
			method:   "dom",  // "template",
			domain:   "aside.prompt",
			message:  "aside > ul > li > div > table > tbody > tr:first-child > td > div > ul > li > div",
			ok:       "aside > ul > li > div > table > tbody > tr:last-child > td > button:first-child",
			cancel:   "aside > ul > li > div > table > tbody > tr:last-child > td > button:last-child"
		},
		popup: {
			method:   "dom",  // "template",
			domain:   "aside.popup",
			content:  "aside > ul > li > div > article",
			close:    "aside > ul > li > div > button"
		},
		textframe: {
			method:   "dom",  // "template",
			domain:   "aside.textframe"
		},
		win: {
			method:   "dom",  // "template",
			domain:   "aside.win",
			title:    "aside > div:last-child > ul > li:first-child > div > span",
			close:    "aside > div:last-child > ul > li:first-child > div > button",
			content:  "aside > div:last-child > ul > li:last-child > article"
		},
		winup: {
			method:   "dom",  // "template",
			domain:   "aside.winup",
			title:    "aside > div:last-child > ul > li:first-child > div > span",
			close:    "aside > div:last-child > ul > li:last-child > div > ul > li > div > button",
			content:  "aside > div:last-child > ul > li:last-child > div > ul > li > div > article"
		},
		monav: {
			method:   "dom",  // "template",
			domain:   "aside.monav",
			title:    "aside > div:first-child > div:first-child",
			top:      "aside > div:first-child > ul > li:nth-child(2) > div",
			prev:     "aside > div:first-child > ul > li:first-child > div",
			next:     "aside > div:first-child > ul > li:last-child > div"
		},
		tree: {
			method:   "dom",
			domain:   "aside.tree"
		},
		editor: {
			method:   "transform",
			nodename: "aside",
			source:   "textarea.editor"
		},
		grid: {
			method:   "transform",
			nodename: "aside",
			source:   "table.grid"
		},
		slider: {
			method:   "transform",
			nodename: "aside",
			source:   "ul.slider"
		}
	},
	lang: {
		label: ["en", "ja", "ko"],
		template: ["en", "ja", "ko"]
	},
	template: {
		engine: ["jade", "ejs"],
		extension: {
			"jade": "jade",
			"ejs":  "ejs"
		},
		alias: {
			"pug": "jade"
		},
		frontInclude: false
	}
};